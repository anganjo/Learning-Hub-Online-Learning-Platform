using Npgsql;
using WebSiteAAA.Core;

namespace WebSiteAAA.Providers.Postgres;

public sealed class NpgsqlCourseFeedbackRepository(NpgsqlDataSource db) : ICourseFeedbackRepository
{
    public async Task<List<CourseFeedbackRecord>> GetForStudentAsync(string studentUsername)
    {
        await using var cmd = db.CreateCommand(
            @"SELECT id, student_username::text, course_id, rating, comments, submitted_at
              FROM course_feedback
              WHERE student_username = $1::citext
              ORDER BY submitted_at DESC");
        cmd.Parameters.AddWithValue(studentUsername);
        var records = new List<CourseFeedbackRecord>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            records.Add(new CourseFeedbackRecord(
                reader.GetInt64(0),
                reader.GetString(1),
                reader.GetInt64(2),
                reader.GetInt32(3),
                reader.GetString(4),
                reader.GetFieldValue<DateTimeOffset>(5)));
        }
        return records;
    }

    public async Task<bool> SubmitAsync(string studentUsername, long courseId, int rating, string comments)
    {
        await using var cmd = db.CreateCommand(
            @"INSERT INTO course_feedback (student_username, course_id, rating, comments)
              VALUES ($1::citext, $2, $3, $4)
              ON CONFLICT (student_username, course_id) DO NOTHING");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        cmd.Parameters.AddWithValue(rating);
        cmd.Parameters.AddWithValue(comments);
        return await cmd.ExecuteNonQueryAsync() > 0;
    }
}
