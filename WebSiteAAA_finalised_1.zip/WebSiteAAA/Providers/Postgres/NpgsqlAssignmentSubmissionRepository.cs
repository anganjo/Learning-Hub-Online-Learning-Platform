using Npgsql;
using WebSiteAAA.Services;

namespace WebSiteAAA.Providers.Postgres;

public sealed class NpgsqlAssignmentSubmissionRepository(NpgsqlDataSource db) : IAssignmentSubmissionRepository
{
    public async Task<int> SubmitAsync(long courseId, int resourceId, string taskName, string student, string fileName, string storedName)
    {
        await using var cmd = db.CreateCommand(
            @"INSERT INTO assignment_submissions
                (course_id, resource_id, task_name, student_username, file_name, stored_name)
              VALUES ($1, $2, $3, $4, $5, $6)
              RETURNING id");
        cmd.Parameters.AddWithValue(courseId);
        cmd.Parameters.AddWithValue(resourceId);
        cmd.Parameters.AddWithValue(taskName);
        cmd.Parameters.AddWithValue(student);
        cmd.Parameters.AddWithValue(fileName);
        cmd.Parameters.AddWithValue(storedName);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync());
    }

    public Task<List<Submission>> GetForStudentAsync(string student, long courseId) =>
        ReadAsync(
            @"SELECT id, course_id, resource_id, task_name, student_username::text,
                     file_name, stored_name, submitted_at, score, feedback
              FROM assignment_submissions
              WHERE student_username = $1::citext AND course_id = $2
              ORDER BY submitted_at DESC",
            student, courseId);

    public Task<List<Submission>> GetAllAsync() =>
        ReadAsync(
            @"SELECT id, course_id, resource_id, task_name, student_username::text,
                     file_name, stored_name, submitted_at, score, feedback
              FROM assignment_submissions
              ORDER BY submitted_at DESC");

    public async Task<Submission?> GetAsync(int id)
    {
        var submissions = await ReadAsync(
            @"SELECT id, course_id, resource_id, task_name, student_username::text,
                     file_name, stored_name, submitted_at, score, feedback
              FROM assignment_submissions
              WHERE id = $1",
            id);
        return submissions.FirstOrDefault();
    }

    public async Task<bool> GradeAsync(int id, int score, string feedback)
    {
        await using var cmd = db.CreateCommand(
            "UPDATE assignment_submissions SET score = $2, feedback = $3 WHERE id = $1");
        cmd.Parameters.AddWithValue(id);
        cmd.Parameters.AddWithValue(score);
        cmd.Parameters.AddWithValue(feedback);
        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    private async Task<List<Submission>> ReadAsync(string sql, params object[] parameters)
    {
        await using var cmd = db.CreateCommand(sql);
        foreach (var parameter in parameters) cmd.Parameters.AddWithValue(parameter);
        var submissions = new List<Submission>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            submissions.Add(new Submission
            {
                Id = reader.GetInt32(0),
                CourseId = reader.GetInt64(1),
                ResourceId = reader.GetInt32(2),
                TaskName = reader.GetString(3),
                Student = reader.GetString(4),
                FileName = reader.GetString(5),
                StoredName = reader.GetString(6),
                SubmittedAt = reader.GetDateTime(7),
                Score = reader.IsDBNull(8) ? null : reader.GetInt32(8),
                Feedback = reader.GetString(9)
            });
        }
        return submissions;
    }
}
