using System.Security.Cryptography;
using Npgsql;
using WebSiteAAA.Core;
using Microsoft.Extensions.DependencyInjection;

namespace WebSiteAAA.Providers.Postgres;

public static class CourseSampleAccountsSeeder
{
    public static async Task<(int students, int tutors, int enrollments, int assignments)> ApplyAsync(
        IServiceProvider services, string credentialsFile)
    {
        var users = services.GetRequiredService<IUserRepository>();
        var roles = services.GetRequiredService<IRoleRepository>();
        var auth = services.GetRequiredService<AuthService>();
        var db = services.GetRequiredService<NpgsqlDataSource>();
        var courses = await services.GetRequiredService<ICourseRepository>().GetAllAsync();
        var newCredentials = new List<string> { "username,password,role,course" };
        var students = 0;
        var tutors = 0;
        var enrollments = 0;
        var assignments = 0;

        await EnsureAccount("system_admin", "system_admin@example.invalid", "admin", "System administration");

        for (var i = 0; i < courses.Count; i++)
        {
            var course = courses[i];
            var courseKey = $"course{i + 1:00}";
            for (var n = 1; n <= 5; n++)
            {
                var username = $"student_{courseKey}_{n:00}";
                await EnsureAccount(username, $"{username}@example.invalid", "user", course.Name);
                students++;
                await using var cmd = db.CreateCommand(
                    "INSERT INTO enrollments (student_username, course_id, status, decided_at) VALUES ($1::citext, $2, 'Approved', now()) ON CONFLICT (student_username, course_id) WHERE status <> 'Rejected' DO NOTHING");
                cmd.Parameters.AddWithValue(username);
                cmd.Parameters.AddWithValue(course.Id);
                enrollments += await cmd.ExecuteNonQueryAsync();
            }

            for (var n = 1; n <= 2; n++)
            {
                var username = $"tutor_{courseKey}_{n:00}";
                await EnsureAccount(username, $"{username}@example.invalid", "tutor", course.Name);
                tutors++;
                await using var cmd = db.CreateCommand(
                    "INSERT INTO course_tutors (course_id, tutor_username) VALUES ($1, $2::citext) ON CONFLICT DO NOTHING");
                cmd.Parameters.AddWithValue(course.Id);
                cmd.Parameters.AddWithValue(username);
                assignments += await cmd.ExecuteNonQueryAsync();
            }
        }

        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(credentialsFile))!);
        await File.WriteAllLinesAsync(credentialsFile, newCredentials);
        if (!OperatingSystem.IsWindows())
            File.SetUnixFileMode(credentialsFile, UnixFileMode.UserRead | UnixFileMode.UserWrite);
        return (students, tutors, enrollments, assignments);

        async Task EnsureAccount(string username, string email, string role, string courseName)
        {
            if (await users.GetAsync(username) is null)
            {
                var password = Convert.ToBase64String(RandomNumberGenerator.GetBytes(24))
                    .TrimEnd('=').Replace('+', '-').Replace('/', '_');
                await auth.RegisterAsync(username, password, email);
                newCredentials.Add($"{username},{password},{role},{courseName}");
            }
            await roles.AssignRoleAsync(username, role);
        }
    }
}
