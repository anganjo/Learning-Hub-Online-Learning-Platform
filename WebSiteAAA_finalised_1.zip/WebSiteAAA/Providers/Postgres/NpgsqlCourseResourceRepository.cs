using Npgsql;
using NpgsqlTypes;
using WebSiteAAA.Services;

namespace WebSiteAAA.Providers.Postgres;

public sealed class NpgsqlCourseResourceRepository(NpgsqlDataSource db) : ICourseResourceRepository
{
    public async Task EnsureSeededAsync(long courseId, IReadOnlyCollection<Resource> resources)
    {
        await using var connection = await db.OpenConnectionAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        await using var marker = new NpgsqlCommand(
            @"INSERT INTO course_resource_seed_state (course_id)
              VALUES ($1)
              ON CONFLICT (course_id) DO NOTHING
              RETURNING course_id",
            connection, transaction);
        marker.Parameters.AddWithValue(courseId);
        if (await marker.ExecuteScalarAsync() is null)
        {
            await transaction.CommitAsync();
            return;
        }

        foreach (var resource in resources)
        {
            await using var insert = new NpgsqlCommand(
                @"INSERT INTO course_resources
                    (course_id, title, category, url, description, instructor)
                  VALUES ($1, $2, $3, $4, $5, $6)",
                connection, transaction);
            insert.Parameters.AddWithValue(courseId);
            insert.Parameters.AddWithValue(resource.Title);
            insert.Parameters.AddWithValue(resource.Category);
            insert.Parameters.AddWithValue(resource.Url);
            insert.Parameters.AddWithValue(resource.Description);
            insert.Parameters.AddWithValue(resource.Instructor);
            await insert.ExecuteNonQueryAsync();
        }
        await transaction.CommitAsync();
    }

    public async Task<List<Resource>> GetForCourseAsync(long courseId, string? category = null, string? search = null)
    {
        await using var cmd = db.CreateCommand(
            @"SELECT id, course_id, title, category, url, description, instructor
              FROM course_resources
              WHERE course_id = $1
                AND ($2 IS NULL OR category = $2)
                AND ($3 IS NULL OR title || ' ' || description ILIKE '%' || $3 || '%')
              ORDER BY id");
        cmd.Parameters.AddWithValue(courseId);
        cmd.Parameters.Add(new NpgsqlParameter { NpgsqlDbType = NpgsqlDbType.Text, Value = (object?)category ?? DBNull.Value });
        cmd.Parameters.Add(new NpgsqlParameter { NpgsqlDbType = NpgsqlDbType.Text, Value = (object?)search ?? DBNull.Value });
        var resources = new List<Resource>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync()) resources.Add(ReadResource(reader));
        return resources;
    }

    public async Task<Resource?> GetAsync(int id)
    {
        await using var cmd = db.CreateCommand(
            @"SELECT id, course_id, title, category, url, description, instructor
              FROM course_resources WHERE id = $1");
        cmd.Parameters.AddWithValue(id);
        await using var reader = await cmd.ExecuteReaderAsync();
        return await reader.ReadAsync() ? ReadResource(reader) : null;
    }

    public async Task<int> CreateAsync(Resource resource)
    {
        await using var cmd = db.CreateCommand(
            @"INSERT INTO course_resources
                (course_id, title, category, url, description, instructor)
              VALUES ($1, $2, $3, $4, $5, $6)
              RETURNING id");
        cmd.Parameters.AddWithValue(resource.CourseId);
        cmd.Parameters.AddWithValue(resource.Title);
        cmd.Parameters.AddWithValue(resource.Category);
        cmd.Parameters.AddWithValue(resource.Url);
        cmd.Parameters.AddWithValue(resource.Description);
        cmd.Parameters.AddWithValue(resource.Instructor);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync());
    }

    public async Task<bool> UpdateAsync(Resource resource)
    {
        await using var cmd = db.CreateCommand(
            @"UPDATE course_resources
              SET title = $3, category = $4, url = $5, description = $6, instructor = $7
              WHERE id = $1 AND course_id = $2");
        AddResourceParameters(cmd, resource);
        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<bool> DeleteAsync(long courseId, int id)
    {
        await using var cmd = db.CreateCommand(
            "DELETE FROM course_resources WHERE id = $1 AND course_id = $2");
        cmd.Parameters.AddWithValue(id);
        cmd.Parameters.AddWithValue(courseId);
        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    private static void AddResourceParameters(NpgsqlCommand cmd, Resource resource)
    {
        cmd.Parameters.AddWithValue(resource.Id);
        cmd.Parameters.AddWithValue(resource.CourseId);
        cmd.Parameters.AddWithValue(resource.Title);
        cmd.Parameters.AddWithValue(resource.Category);
        cmd.Parameters.AddWithValue(resource.Url);
        cmd.Parameters.AddWithValue(resource.Description);
        cmd.Parameters.AddWithValue(resource.Instructor);
    }

    private static Resource ReadResource(NpgsqlDataReader reader) => new()
    {
        Id = reader.GetInt32(0),
        CourseId = reader.GetInt64(1),
        Title = reader.GetString(2),
        Category = reader.GetString(3),
        Url = reader.GetString(4),
        Description = reader.GetString(5),
        Instructor = reader.GetString(6)
    };
}
