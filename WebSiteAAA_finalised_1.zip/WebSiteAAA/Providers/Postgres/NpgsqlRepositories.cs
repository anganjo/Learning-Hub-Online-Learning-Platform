using Npgsql;
using NpgsqlTypes;
using WebSiteAAA.Core;

namespace WebSiteAAA.Providers.Postgres;






public class NpgsqlUserRepository : IUserRepository
{
    private readonly NpgsqlDataSource _db;
    public NpgsqlUserRepository(NpgsqlDataSource db) => _db = db;

    public async Task<long> CreateAsync(string username, string passwordHash, string? email)
    {
        await using var cmd = _db.CreateCommand(
            "INSERT INTO users (username, password_hash, email) VALUES ($1, $2, $3) RETURNING id");
        cmd.Parameters.AddWithValue(username);
        cmd.Parameters.AddWithValue(passwordHash);
        cmd.Parameters.AddWithValue((object?)email ?? DBNull.Value);
        return (long)(await cmd.ExecuteScalarAsync())!;
    }

    public async Task<UserRecord?> GetAsync(string username)
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT id, username, email, password_hash, created_at, failed_attempts, locked_until, is_active
              FROM users WHERE username = $1::citext");
        cmd.Parameters.AddWithValue(username);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync()) return null;

        return new UserRecord(
            reader.GetInt64(0), reader.GetString(1),
            reader.IsDBNull(2) ? null : reader.GetString(2),
            reader.GetString(3), reader.GetFieldValue<DateTimeOffset>(4),
            reader.GetInt32(5),
            reader.IsDBNull(6) ? null : reader.GetFieldValue<DateTimeOffset>(6),
            reader.GetBoolean(7));
    }

    public async Task<int> RecordFailedAttemptAsync(string username)
    {
        await using var cmd = _db.CreateCommand(
            "UPDATE users SET failed_attempts = failed_attempts + 1 WHERE username = $1::citext RETURNING failed_attempts");
        cmd.Parameters.AddWithValue(username);
        return (int)(await cmd.ExecuteScalarAsync())!;
    }

    public async Task ResetFailedAttemptsAsync(string username)
    {
        await using var cmd = _db.CreateCommand(
            "UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE username = $1::citext");
        cmd.Parameters.AddWithValue(username);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task LockAsync(string username, DateTimeOffset lockedUntil)
    {
        await using var cmd = _db.CreateCommand("UPDATE users SET locked_until = $2 WHERE username = $1::citext");
        cmd.Parameters.AddWithValue(username);
        cmd.Parameters.AddWithValue(lockedUntil);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<List<UserSummary>> GetAllAsync(int limit, int offset)
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT id, username, email, created_at, failed_attempts, locked_until, is_active
              FROM users ORDER BY id LIMIT $1 OFFSET $2");
        cmd.Parameters.AddWithValue(limit);
        cmd.Parameters.AddWithValue(offset);

        var results = new List<UserSummary>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            results.Add(new UserSummary(
                reader.GetInt64(0), reader.GetString(1),
                reader.IsDBNull(2) ? null : reader.GetString(2),
                reader.GetFieldValue<DateTimeOffset>(3), reader.GetInt32(4),
                reader.IsDBNull(5) ? null : reader.GetFieldValue<DateTimeOffset>(5),
                reader.GetBoolean(6)));
        }
        return results;
    }

    public async Task UpdateEmailAsync(string username, string? email)
    {
        await using var cmd = _db.CreateCommand("UPDATE users SET email = $2 WHERE username = $1::citext");
        cmd.Parameters.AddWithValue(username);
        cmd.Parameters.AddWithValue((object?)email ?? DBNull.Value);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UpdatePasswordHashAsync(string username, string passwordHash)
    {
        await using var cmd = _db.CreateCommand("UPDATE users SET password_hash = $2 WHERE username = $1::citext");
        cmd.Parameters.AddWithValue(username);
        cmd.Parameters.AddWithValue(passwordHash);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<bool> DeleteAsync(string username)
    {
        await using var cmd = _db.CreateCommand("DELETE FROM users WHERE username = $1::citext");
        cmd.Parameters.AddWithValue(username);
        return await cmd.ExecuteNonQueryAsync() > 0;
    }
}

public class NpgsqlSessionRepository : ISessionRepository
{
    private readonly NpgsqlDataSource _db;
    public NpgsqlSessionRepository(NpgsqlDataSource db) => _db = db;

    public async Task CreateAsync(string username, byte[] tokenHash, DateTimeOffset expiresAt)
    {
        await using var cmd = _db.CreateCommand(
            "INSERT INTO sessions (username, token_hash, expires_at) VALUES ($1, $2, $3)");
        cmd.Parameters.AddWithValue(username);
        cmd.Parameters.Add(new NpgsqlParameter { Value = tokenHash, NpgsqlDbType = NpgsqlDbType.Bytea });
        cmd.Parameters.AddWithValue(expiresAt);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<SessionRecord?> GetAsync(byte[] tokenHash)
    {
        await using var cmd = _db.CreateCommand(
            "SELECT id, username, token_hash, created_at, expires_at, revoked FROM sessions WHERE token_hash = $1");
        cmd.Parameters.Add(new NpgsqlParameter { Value = tokenHash, NpgsqlDbType = NpgsqlDbType.Bytea });

        await using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync()) return null;

        return new SessionRecord(
            reader.GetInt64(0), reader.GetString(1), (byte[])reader[2],
            reader.GetFieldValue<DateTimeOffset>(3), reader.GetFieldValue<DateTimeOffset>(4), reader.GetBoolean(5));
    }

    public async Task<bool> RevokeAsync(byte[] tokenHash)
    {
        await using var cmd = _db.CreateCommand("UPDATE sessions SET revoked = TRUE WHERE token_hash = $1");
        cmd.Parameters.Add(new NpgsqlParameter { Value = tokenHash, NpgsqlDbType = NpgsqlDbType.Bytea });
        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<int> RevokeAllAsync(string username)
    {
        await using var cmd = _db.CreateCommand(
            "UPDATE sessions SET revoked = TRUE WHERE username = $1::citext AND revoked = FALSE");
        cmd.Parameters.AddWithValue(username);
        return await cmd.ExecuteNonQueryAsync();
    }
}

public class NpgsqlRoleRepository : IRoleRepository
{
    private readonly NpgsqlDataSource _db;
    public NpgsqlRoleRepository(NpgsqlDataSource db) => _db = db;

    public async Task AssignRoleAsync(string username, string role)
    {
        await using var cmd = _db.CreateCommand(
            @"INSERT INTO user_roles (user_id, role_id)
              SELECT u.id, r.id FROM users u, roles r WHERE u.username = $1::citext AND r.name = $2
              ON CONFLICT DO NOTHING");
        cmd.Parameters.AddWithValue(username);
        cmd.Parameters.AddWithValue(role);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<bool> RevokeRoleAsync(string username, string role)
    {
        await using var cmd = _db.CreateCommand(
            @"DELETE FROM user_roles
              WHERE user_id = (SELECT id FROM users WHERE username = $1::citext)
                AND role_id = (SELECT id FROM roles WHERE name = $2)");
        cmd.Parameters.AddWithValue(username);
        cmd.Parameters.AddWithValue(role);
        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<List<string>> GetRolesAsync(string username)
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT r.name FROM roles r
              JOIN user_roles ur ON ur.role_id = r.id
              JOIN users u ON u.id = ur.user_id
              WHERE u.username = $1::citext");
        cmd.Parameters.AddWithValue(username);

        var roles = new List<string>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync()) roles.Add(reader.GetString(0));
        return roles;
    }

    public async Task<bool> UserHasPermissionAsync(string username, string permission)
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT 1 FROM users u
              JOIN user_roles ur ON u.id = ur.user_id
              JOIN roles r ON ur.role_id = r.id
              JOIN role_permissions rp ON r.id = rp.role_id
              JOIN permissions p ON rp.permission_id = p.id
              WHERE u.username = $1::citext AND p.name = $2
              LIMIT 1");
        cmd.Parameters.AddWithValue(username);
        cmd.Parameters.AddWithValue(permission);
        return await cmd.ExecuteScalarAsync() is not null;
    }

    public async Task<List<string>> GetAllRolesAsync()
    {
        await using var cmd = _db.CreateCommand("SELECT name FROM roles ORDER BY name");
        var roles = new List<string>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync()) roles.Add(reader.GetString(0));
        return roles;
    }
}

public class NpgsqlAuditSink : IAuditSink
{
    private readonly NpgsqlDataSource _db;
    public NpgsqlAuditSink(NpgsqlDataSource db) => _db = db;

    public async Task AppendAsync(AuditRecord record)
    {
        await using var connection = await _db.OpenConnectionAsync();
        await using var transaction = await connection.BeginTransactionAsync();

        
        
        
        await using (var lockCmd = new NpgsqlCommand(
            "SELECT pg_advisory_xact_lock(hashtext('audit_log_chain'))", connection, transaction))
        {
            await lockCmd.ExecuteNonQueryAsync();
        }

        await using var insertCmd = new NpgsqlCommand(
            @"INSERT INTO audit_log (""timestamp"", event_type, action, result, username, resource, details, prev_hash, entry_hash)
              VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)", connection, transaction);

        insertCmd.Parameters.AddWithValue(record.Timestamp);
        insertCmd.Parameters.AddWithValue(record.EventType);
        insertCmd.Parameters.AddWithValue(record.Action);
        insertCmd.Parameters.AddWithValue(record.Result);
        insertCmd.Parameters.AddWithValue((object?)record.Username ?? DBNull.Value);
        insertCmd.Parameters.AddWithValue((object?)record.Resource ?? DBNull.Value);
        insertCmd.Parameters.AddWithValue((object?)record.Details ?? DBNull.Value);
        insertCmd.Parameters.Add(new NpgsqlParameter { Value = record.PrevHash, NpgsqlDbType = NpgsqlDbType.Bytea });
        insertCmd.Parameters.Add(new NpgsqlParameter { Value = record.EntryHash, NpgsqlDbType = NpgsqlDbType.Bytea });

        await insertCmd.ExecuteNonQueryAsync();
        await transaction.CommitAsync();
    }

    public async Task<byte[]?> GetLastHashAsync()
    {
        await using var cmd = _db.CreateCommand("SELECT entry_hash FROM audit_log ORDER BY id DESC LIMIT 1");
        var result = await cmd.ExecuteScalarAsync();
        return result as byte[];
    }

    public async Task<List<AuditRecord>> GetAllOrderedAsync()
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT id, ""timestamp"", event_type, action, result, username, resource, details, prev_hash, entry_hash
              FROM audit_log ORDER BY id ASC");

        var results = new List<AuditRecord>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            results.Add(new AuditRecord(
                reader.GetInt64(0), reader.GetFieldValue<DateTimeOffset>(1), reader.GetString(2),
                reader.GetString(3), reader.GetString(4),
                reader.IsDBNull(5) ? null : reader.GetString(5),
                reader.IsDBNull(6) ? null : reader.GetString(6),
                reader.IsDBNull(7) ? null : reader.GetString(7),
                (byte[])reader[8], (byte[])reader[9]));
        }
        return results;
    }
}
