using Npgsql;

namespace WebSiteAAA.Providers.Postgres;









public static class Db
{
    public static NpgsqlDataSource CreateDataSource(string connectionString) =>
        NpgsqlDataSource.Create(connectionString);

    public static async Task ApplySchemaAsync(string connectionString)
    {
        var schemaPath = Path.Combine(AppContext.BaseDirectory, "sql", "schema.sql");
        var schemaSql = await File.ReadAllTextAsync(schemaPath);

        await using var connection = new NpgsqlConnection(connectionString);
        await connection.OpenAsync();

        await using (var extensionCmd = new NpgsqlCommand("CREATE EXTENSION IF NOT EXISTS citext", connection))
        {
            await extensionCmd.ExecuteNonQueryAsync();
        }

        await using var schemaCmd = new NpgsqlCommand(schemaSql, connection);
        await schemaCmd.ExecuteNonQueryAsync();
    }
}
