using Npgsql;
using WebSiteAAA.Core;

namespace WebSiteAAA.Providers.Postgres;







public class NpgsqlCourseRepository : ICourseRepository
{
    private readonly NpgsqlDataSource _db;
    public NpgsqlCourseRepository(NpgsqlDataSource db) => _db = db;

    public async Task<long> CreateAsync(string name)
    {
        await using var cmd = _db.CreateCommand("INSERT INTO courses (name) VALUES ($1) RETURNING id");
        cmd.Parameters.AddWithValue(name);
        return (long)(await cmd.ExecuteScalarAsync())!;
    }

    public async Task<bool> UpdateAsync(long courseId, string name)
    {
        await using var cmd = _db.CreateCommand("UPDATE courses SET name = $2 WHERE id = $1");
        cmd.Parameters.AddWithValue(courseId);
        cmd.Parameters.AddWithValue(name);
        return await cmd.ExecuteNonQueryAsync() == 1;
    }

    public async Task<bool> DeleteAsync(long courseId)
    {
        try
        {
            await using var cmd = _db.CreateCommand("DELETE FROM courses WHERE id = $1");
            cmd.Parameters.AddWithValue(courseId);
            return await cmd.ExecuteNonQueryAsync() == 1;
        }
        catch (PostgresException ex) when (ex.SqlState == PostgresErrorCodes.ForeignKeyViolation)
        {
            throw new InvalidOperationException("This course cannot be deleted because it has payment or certificate records.", ex);
        }
    }

    public async Task<List<CourseRecord>> GetAllAsync()
    {
        await using var cmd = _db.CreateCommand("SELECT id, name FROM courses ORDER BY id");
        var results = new List<CourseRecord>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync()) results.Add(new CourseRecord(reader.GetInt64(0), reader.GetString(1)));
        return results;
    }

    public async Task<CourseRecord?> GetAsync(long courseId)
    {
        await using var cmd = _db.CreateCommand("SELECT id, name FROM courses WHERE id = $1");
        cmd.Parameters.AddWithValue(courseId);
        await using var reader = await cmd.ExecuteReaderAsync();
        return await reader.ReadAsync() ? new CourseRecord(reader.GetInt64(0), reader.GetString(1)) : null;
    }
}

public class NpgsqlEnrollmentRepository : IEnrollmentRepository
{
    private readonly NpgsqlDataSource _db;
    public NpgsqlEnrollmentRepository(NpgsqlDataSource db) => _db = db;

    private static EnrollmentStatus ParseStatus(string s) => Enum.Parse<EnrollmentStatus>(s, ignoreCase: true);

    public async Task<long> RequestAsync(string studentUsername, long courseId)
    {
        await using var connection = await _db.OpenConnectionAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        await using (var lockCommand = connection.CreateCommand())
        {
            lockCommand.Transaction = transaction;
            lockCommand.CommandText = "SELECT pg_advisory_xact_lock(hashtextextended($1, 0))";
            lockCommand.Parameters.AddWithValue($"enrollment:{studentUsername.ToUpperInvariant()}:{courseId}");
            await lockCommand.ExecuteScalarAsync();
        }

        await using (var check = connection.CreateCommand())
        {
            check.Transaction = transaction;
            check.CommandText =
                @"SELECT COUNT(*), COUNT(*) FILTER (WHERE status = 'Rejected'),
                         COUNT(*) FILTER (WHERE status <> 'Rejected')
                  FROM enrollments
                  WHERE student_username = $1::citext AND course_id = $2";
            check.Parameters.AddWithValue(studentUsername);
            check.Parameters.AddWithValue(courseId);
            long rejected;
            long activeOrApproved;
            await using (var reader = await check.ExecuteReaderAsync())
            {
                await reader.ReadAsync();
                rejected = reader.GetInt64(1);
                activeOrApproved = reader.GetInt64(2);
            }
            if (activeOrApproved > 0 || rejected >= 2)
                throw new InvalidOperationException("This course is not available for another enrollment request.");

            await using var insert = connection.CreateCommand();
            insert.Transaction = transaction;
            insert.CommandText =
                @"INSERT INTO enrollments (student_username, course_id, status)
                  VALUES ($1::citext, $2, 'Pending') RETURNING id";
            insert.Parameters.AddWithValue(studentUsername);
            insert.Parameters.AddWithValue(courseId);
            var id = (long)(await insert.ExecuteScalarAsync())!;
            await transaction.CommitAsync();
            return id;
        }
    }

    public async Task<bool> DecideAsync(long enrollmentId, bool approve, string decidedBy)
    {
        await using var cmd = _db.CreateCommand(
            @"UPDATE enrollments SET status = $2, decided_by = $3, decided_at = now()
              WHERE id = $1 AND status = 'Pending'");
        cmd.Parameters.AddWithValue(enrollmentId);
        cmd.Parameters.AddWithValue(approve ? "Approved" : "Rejected");
        cmd.Parameters.AddWithValue(decidedBy);
        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<List<EnrollmentRecord>> GetForStudentAsync(string studentUsername)
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT id, student_username, course_id, status, decided_by, requested_at, decided_at
              FROM enrollments WHERE student_username = $1::citext ORDER BY requested_at DESC");
        cmd.Parameters.AddWithValue(studentUsername);
        return await ReadAllAsync(cmd);
    }

    public async Task<List<EnrollmentRecord>> GetForCoursesAsync(IReadOnlyCollection<long> courseIds)
    {
        if (courseIds.Count == 0) return new List<EnrollmentRecord>();

        await using var cmd = _db.CreateCommand(
            @"SELECT id, student_username, course_id, status, decided_by, requested_at, decided_at
              FROM enrollments WHERE course_id = ANY($1) ORDER BY requested_at DESC");
        cmd.Parameters.AddWithValue(courseIds.ToArray());
        return await ReadAllAsync(cmd);
    }

    public async Task<List<EnrollmentRecord>> GetPendingAsync()
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT id, student_username, course_id, status, decided_by, requested_at, decided_at
              FROM enrollments WHERE status = 'Pending' ORDER BY requested_at ASC");
        return await ReadAllAsync(cmd);
    }

    public async Task<bool> IsApprovedAsync(string studentUsername, long courseId)
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT 1 FROM enrollments
              WHERE student_username = $1::citext AND course_id = $2 AND status = 'Approved' LIMIT 1");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        return await cmd.ExecuteScalarAsync() is not null;
    }

    private static async Task<List<EnrollmentRecord>> ReadAllAsync(NpgsqlCommand cmd)
    {
        var results = new List<EnrollmentRecord>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            results.Add(new EnrollmentRecord(
                reader.GetInt64(0), reader.GetString(1), reader.GetInt64(2),
                ParseStatus(reader.GetString(3)),
                reader.IsDBNull(4) ? null : reader.GetString(4),
                reader.GetFieldValue<DateTimeOffset>(5),
                reader.IsDBNull(6) ? null : reader.GetFieldValue<DateTimeOffset>(6)));
        }
        return results;
    }
}

public sealed class NpgsqlExamAttemptRepository(NpgsqlDataSource db) : IExamAttemptRepository
{
    public async Task<DateTimeOffset?> GetStartedAsync(string studentUsername, long courseId)
    {
        await using var cmd = db.CreateCommand(
            @"SELECT started_at
              FROM course_exam_attempts
              WHERE student_username = $1::citext AND course_id = $2");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        await using var reader = await cmd.ExecuteReaderAsync();
        return await reader.ReadAsync() ? reader.GetFieldValue<DateTimeOffset>(0) : null;
    }

    public async Task StartAsync(string studentUsername, long courseId, int durationMinutes)
    {
        await using var cmd = db.CreateCommand(
            @"INSERT INTO course_exam_attempts (student_username, course_id, started_at)
              VALUES ($1::citext, $2, now())
              ON CONFLICT (student_username, course_id) DO UPDATE
              SET started_at = EXCLUDED.started_at
              WHERE course_exam_attempts.started_at <= now() - ($3 * interval '1 minute')");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        cmd.Parameters.AddWithValue(durationMinutes);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task EndAsync(string studentUsername, long courseId)
    {
        await using var cmd = db.CreateCommand(
            @"DELETE FROM course_exam_attempts
              WHERE student_username = $1::citext AND course_id = $2");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        await cmd.ExecuteNonQueryAsync();
    }
}

public class NpgsqlAchievementRepository : IAchievementRepository
{
    private readonly NpgsqlDataSource _db;
    public NpgsqlAchievementRepository(NpgsqlDataSource db) => _db = db;

    public async Task<long> AddAsync(string studentUsername, long courseId, string title, string? details)
    {
        await using var cmd = _db.CreateCommand(
            @"INSERT INTO achievements (student_username, course_id, title, details)
              VALUES ($1, $2, $3, $4) RETURNING id");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        cmd.Parameters.AddWithValue(title);
        cmd.Parameters.AddWithValue((object?)details ?? DBNull.Value);
        return (long)(await cmd.ExecuteScalarAsync())!;
    }

    public async Task<List<AchievementRecord>> GetForStudentAsync(string studentUsername)
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT id, student_username, course_id, title, details, created_at
              FROM achievements WHERE student_username = $1::citext ORDER BY created_at DESC");
        cmd.Parameters.AddWithValue(studentUsername);

        var results = new List<AchievementRecord>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            results.Add(new AchievementRecord(
                reader.GetInt64(0), reader.GetString(1), reader.GetInt64(2), reader.GetString(3),
                reader.IsDBNull(4) ? null : reader.GetString(4), reader.GetFieldValue<DateTimeOffset>(5)));
        }
        return results;
    }
}

public class NpgsqlCommentRepository : ICommentRepository
{
    private readonly NpgsqlDataSource _db;
    public NpgsqlCommentRepository(NpgsqlDataSource db) => _db = db;

    public async Task<long> AddAsync(string studentUsername, string authorUsername, string text)
    {
        await using var cmd = _db.CreateCommand(
            @"INSERT INTO comments (student_username, author_username, text)
              VALUES ($1, $2, $3) RETURNING id");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(authorUsername);
        cmd.Parameters.AddWithValue(text);
        return (long)(await cmd.ExecuteScalarAsync())!;
    }

    public async Task<List<CommentRecord>> GetForStudentAsync(string studentUsername)
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT id, student_username, author_username, text, created_at
              FROM comments WHERE student_username = $1::citext ORDER BY created_at DESC");
        cmd.Parameters.AddWithValue(studentUsername);

        var results = new List<CommentRecord>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            results.Add(new CommentRecord(
                reader.GetInt64(0), reader.GetString(1), reader.GetString(2), reader.GetString(3),
                reader.GetFieldValue<DateTimeOffset>(4)));
        }
        return results;
    }
}

public class NpgsqlCertificateRepository : ICertificateRepository
{
    private readonly NpgsqlDataSource _db;
    public NpgsqlCertificateRepository(NpgsqlDataSource db) => _db = db;

    public async Task<CertificateRecord> IssueAsync(string studentUsername, long courseId, int examScore)
    {
        await using (var insert = _db.CreateCommand(
            @"INSERT INTO certificates (student_username, course_id, exam_score)
              VALUES ($1::citext, $2, $3)
              ON CONFLICT (student_username, course_id) DO NOTHING"))
        {
            insert.Parameters.AddWithValue(studentUsername);
            insert.Parameters.AddWithValue(courseId);
            insert.Parameters.AddWithValue(examScore);
            await insert.ExecuteNonQueryAsync();
        }

        await using var select = _db.CreateCommand(
            @"SELECT id, certificate_no, student_username::text, course_id, exam_score, issued_at
              FROM certificates
              WHERE student_username = $1::citext AND course_id = $2");
        select.Parameters.AddWithValue(studentUsername);
        select.Parameters.AddWithValue(courseId);
        await using var reader = await select.ExecuteReaderAsync();
        if (!await reader.ReadAsync())
            throw new InvalidOperationException("The issued certificate could not be loaded.");
        return ReadCertificate(reader);
    }

    public async Task<List<CertificateRecord>> GetForStudentAsync(string studentUsername)
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT id, certificate_no, student_username::text, course_id, exam_score, issued_at
              FROM certificates
              WHERE student_username = $1::citext
              ORDER BY issued_at DESC");
        cmd.Parameters.AddWithValue(studentUsername);
        var records = new List<CertificateRecord>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync()) records.Add(ReadCertificate(reader));
        return records;
    }

    private static CertificateRecord ReadCertificate(NpgsqlDataReader reader) =>
        new(reader.GetInt64(0), reader.GetString(1), reader.GetString(2), reader.GetInt64(3),
            reader.IsDBNull(4) ? null : reader.GetInt32(4), reader.GetFieldValue<DateTimeOffset>(5));
}

public class NpgsqlLessonProgressRepository : ILessonProgressRepository
{
    private readonly NpgsqlDataSource _db;
    public NpgsqlLessonProgressRepository(NpgsqlDataSource db) => _db = db;

    public async Task<HashSet<string>> GetCompletedKeysAsync(string studentUsername, long courseId)
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT progress_key FROM course_lesson_progress
              WHERE student_username = $1::citext AND course_id = $2");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        var keys = new HashSet<string>(StringComparer.Ordinal);
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync()) keys.Add(reader.GetString(0));
        return keys;
    }

    public async Task MarkCompleteAsync(string studentUsername, long courseId, string progressKey)
    {
        await using var cmd = _db.CreateCommand(
            @"INSERT INTO course_lesson_progress (student_username, course_id, progress_key)
              VALUES ($1::citext, $2, $3)
              ON CONFLICT (student_username, course_id, progress_key) DO NOTHING");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        cmd.Parameters.AddWithValue(progressKey);
        await cmd.ExecuteNonQueryAsync();
    }
}

public class NpgsqlExamResultRepository : IExamResultRepository
{
    private readonly NpgsqlDataSource _db;
    public NpgsqlExamResultRepository(NpgsqlDataSource db) => _db = db;

    public async Task RecordAsync(string studentUsername, long courseId, int score, bool passed)
    {
        await using var connection = await _db.OpenConnectionAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        await LockAsync(connection, transaction, courseId.ToString());
        var quizId = await GetOrCreateFinalExamQuizIdAsync(connection, transaction, courseId);
        var studentCourseKey = $"{studentUsername.ToUpperInvariant()}:{courseId}";
        await LockAsync(connection, transaction, studentCourseKey);

        int attemptNumber;
        await using (var nextAttempt = connection.CreateCommand())
        {
            nextAttempt.Transaction = transaction;
            nextAttempt.CommandText =
                "SELECT COALESCE(MAX(attempt_no), 0) + 1 FROM quiz_attempts WHERE quiz_id = $1 AND student_username = $2::citext";
            nextAttempt.Parameters.AddWithValue(quizId);
            nextAttempt.Parameters.AddWithValue(studentUsername);
            attemptNumber = Convert.ToInt32(await nextAttempt.ExecuteScalarAsync());
        }

        await using (var insert = connection.CreateCommand())
        {
            insert.Transaction = transaction;
            insert.CommandText =
                @"INSERT INTO quiz_attempts (quiz_id, student_username, attempt_no, score, passed)
                  VALUES ($1, $2::citext, $3, $4, $5)";
            insert.Parameters.AddWithValue(quizId);
            insert.Parameters.AddWithValue(studentUsername);
            insert.Parameters.AddWithValue(attemptNumber);
            insert.Parameters.AddWithValue(score);
            insert.Parameters.AddWithValue(passed);
            await insert.ExecuteNonQueryAsync();
        }

        await transaction.CommitAsync();
    }

    public async Task<ExamOutcome> GetOutcomeAsync(string studentUsername, long courseId)
    {
        await using var cmd = _db.CreateCommand(
            @"SELECT MAX(a.score), COALESCE(BOOL_OR(a.passed), FALSE)
              FROM quiz_attempts a
              JOIN quizzes q ON q.id = a.quiz_id AND q.is_final_exam
              JOIN modules m ON m.id = q.module_id
              WHERE a.student_username = $1::citext AND m.course_id = $2");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        await using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync()) return new ExamOutcome(null, false);
        return new ExamOutcome(reader.IsDBNull(0) ? null : Convert.ToInt32(reader.GetDecimal(0)), reader.GetBoolean(1));
    }

    public async Task<List<ExamAttemptRecord>> GetLatestResultsAsync()
    {
        await using var cmd = _db.CreateCommand(
            @"WITH ranked_attempts AS (
                  SELECT a.student_username::text, m.course_id, a.attempt_no,
                         a.score, a.passed, a.submitted_at,
                         row_number() OVER (
                             PARTITION BY a.student_username, m.course_id
                             ORDER BY a.submitted_at DESC, a.attempt_no DESC
                         ) AS result_order
                  FROM quiz_attempts a
                  JOIN quizzes q ON q.id = a.quiz_id AND q.is_final_exam
                  JOIN modules m ON m.id = q.module_id
              )
              SELECT student_username, course_id, attempt_no, score, passed, submitted_at
              FROM ranked_attempts
              WHERE result_order = 1
              ORDER BY submitted_at DESC");
        var results = new List<ExamAttemptRecord>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
            results.Add(new ExamAttemptRecord(
                reader.GetString(0),
                reader.GetInt64(1),
                reader.GetInt32(2),
                Convert.ToInt32(reader.GetDecimal(3)),
                reader.GetBoolean(4),
                reader.GetFieldValue<DateTimeOffset>(5)));
        return results;
    }

    private static async Task LockAsync(NpgsqlConnection connection, NpgsqlTransaction transaction, string key)
    {
        await using var cmd = connection.CreateCommand();
        cmd.Transaction = transaction;
        cmd.CommandText = "SELECT pg_advisory_xact_lock(hashtextextended($1, 0))";
        cmd.Parameters.AddWithValue(key);
        await cmd.ExecuteScalarAsync();
    }

    private static async Task<long> GetOrCreateFinalExamQuizIdAsync(
        NpgsqlConnection connection, NpgsqlTransaction transaction, long courseId)
    {
        await using (var find = connection.CreateCommand())
        {
            find.Transaction = transaction;
            find.CommandText =
                @"SELECT q.id FROM quizzes q
                  JOIN modules m ON m.id = q.module_id
                  WHERE m.course_id = $1 AND q.is_final_exam
                  LIMIT 1";
            find.Parameters.AddWithValue(courseId);
            var existing = await find.ExecuteScalarAsync();
            if (existing is long quizId) return quizId;
        }

        long moduleId;
        await using (var createModule = connection.CreateCommand())
        {
            createModule.Transaction = transaction;
            createModule.CommandText =
                @"INSERT INTO modules (course_id, title, position)
                  SELECT $1, 'Final exam', COALESCE(MAX(position), 0) + 1
                  FROM modules WHERE course_id = $1
                  RETURNING id";
            createModule.Parameters.AddWithValue(courseId);
            moduleId = (long)(await createModule.ExecuteScalarAsync())!;
        }

        await using var createQuiz = connection.CreateCommand();
        createQuiz.Transaction = transaction;
        createQuiz.CommandText =
            @"INSERT INTO quizzes (module_id, title, is_final_exam)
              VALUES ($1, 'Final exam', TRUE)
              RETURNING id";
        createQuiz.Parameters.AddWithValue(moduleId);
        return (long)(await createQuiz.ExecuteScalarAsync())!;
    }
}
