using Npgsql;
using WebSiteAAA.Services;

namespace WebSiteAAA.Providers.Postgres;

public sealed class NpgsqlQuizScoreRepository(NpgsqlDataSource db) : IQuizScoreRepository
{
    public async Task<int?> GetScoreAsync(string studentUsername, long courseId)
    {
        await using var cmd = db.CreateCommand(
            "SELECT score FROM course_quiz_scores WHERE student_username = $1::citext AND course_id = $2");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        return await cmd.ExecuteScalarAsync() is int score ? score : null;
    }

    public async Task RecordScoreAsync(string studentUsername, long courseId, int score)
    {
        await using var cmd = db.CreateCommand(
            @"INSERT INTO course_quiz_scores (student_username, course_id, score)
              VALUES ($1::citext, $2, $3)
              ON CONFLICT (student_username, course_id)
              DO UPDATE SET score = EXCLUDED.score, updated_at = now()");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        cmd.Parameters.AddWithValue(score);
        await cmd.ExecuteNonQueryAsync();
    }
}
