using Npgsql;
using WebSiteAAA.Services;

namespace WebSiteAAA.Providers.Postgres;

public sealed class NpgsqlCourseContentRepository(NpgsqlDataSource db) : ICourseContentRepository
{
    public async Task EnsureSeededAsync(long courseId, SeedCourse seed)
    {
        await using var connection = await db.OpenConnectionAsync();

        bool needsSeed;
        await using (var state = connection.CreateCommand())
        {
            state.CommandText = "SELECT NOT EXISTS (SELECT 1 FROM course_content_seed_state WHERE course_id = $1)";
            state.Parameters.AddWithValue(courseId);
            needsSeed = (bool)(await state.ExecuteScalarAsync())!;
        }

        if (needsSeed)
        {
            await using var lessonCount = connection.CreateCommand();
            lessonCount.CommandText =
                @"SELECT COUNT(*)
                  FROM modules m JOIN materials a ON a.module_id = m.id
                  WHERE m.course_id = $1 AND NOT EXISTS (
                      SELECT 1 FROM quizzes q WHERE q.module_id = m.id AND q.is_final_exam
                  )";
            lessonCount.Parameters.AddWithValue(courseId);
            if (Convert.ToInt64(await lessonCount.ExecuteScalarAsync()) == 0)
                foreach (var lesson in seed.Lessons)
                    await AddLessonAsync(courseId, lesson.Title, "Text", lesson.Description);
        }

        var newFinalQuiz = await FindFinalQuizIdAsync(connection, null, courseId) is null;
        var quizId = await GetOrCreateFinalQuizIdAsync(connection, null, courseId);
        bool seedExamQuestions = newFinalQuiz;
        if (needsSeed && !newFinalQuiz)
        {
            await using var questionCount = connection.CreateCommand();
            questionCount.CommandText = "SELECT COUNT(*) FROM questions WHERE quiz_id = $1";
            questionCount.Parameters.AddWithValue(quizId);
            seedExamQuestions = Convert.ToInt64(await questionCount.ExecuteScalarAsync()) == 0;
        }

        if (seedExamQuestions)
        {
            foreach (var question in seed.Questions)
                await InsertQuestionAsync(connection, null, quizId, question.Text, question.Options, question.Answer);

            await using var settings = connection.CreateCommand();
            settings.CommandText =
                @"UPDATE quizzes SET title = CASE WHEN title = 'Final exam' THEN $2 ELSE title END,
                     duration_minutes = CASE WHEN duration_minutes = 30 THEN $3 ELSE duration_minutes END,
                     pass_score = CASE WHEN pass_score = 70 THEN $4 ELSE pass_score END
                  WHERE id = $1";
            settings.Parameters.AddWithValue(quizId);
            settings.Parameters.AddWithValue(seed.ExamTitle);
            settings.Parameters.AddWithValue(seed.ExamMinutes);
            settings.Parameters.AddWithValue(seed.PassMark);
            await settings.ExecuteNonQueryAsync();
        }

        if (needsSeed)
        {
            await using var markSeeded = connection.CreateCommand();
            markSeeded.CommandText =
                "INSERT INTO course_content_seed_state (course_id) VALUES ($1) ON CONFLICT DO NOTHING";
            markSeeded.Parameters.AddWithValue(courseId);
            await markSeeded.ExecuteNonQueryAsync();
        }
    }

    public async Task<List<SModule>> GetLessonsAsync(long courseId)
    {
        await using var cmd = db.CreateCommand(
            @"SELECT id, title, kind, body,
                     row_number() OVER (ORDER BY position, id)::INTEGER AS lesson_order
              FROM (
                  SELECT DISTINCT ON (m.id) m.id, m.title, a.kind,
                         COALESCE(a.body, a.resource_url, '') AS body, m.position, a.position AS material_position
                  FROM modules m
                  JOIN materials a ON a.module_id = m.id
                  WHERE m.course_id = $1
                    AND NOT EXISTS (SELECT 1 FROM quizzes q WHERE q.module_id = m.id AND q.is_final_exam)
                  ORDER BY m.id, a.position
              ) lessons
              ORDER BY position, id");
        cmd.Parameters.AddWithValue(courseId);
        var lessons = new List<SModule>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            var id = checked((int)reader.GetInt64(0));
            lessons.Add(new SModule(id, courseId, reader.GetString(1), DisplayKind(reader.GetString(2)),
                reader.GetString(3), $"seed:{reader.GetInt32(4)}"));
        }
        return lessons;
    }

    public async Task<SModule?> GetLessonAsync(long courseId, int lessonId) =>
        (await GetLessonsAsync(courseId)).FirstOrDefault(m => m.Id == lessonId);

    public async Task<int> AddLessonAsync(long courseId, string title, string kind, string body)
    {
        await using var connection = await db.OpenConnectionAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        await LockCourseAsync(connection, transaction, courseId);
        long moduleId;
        await using (var module = connection.CreateCommand())
        {
            module.Transaction = transaction;
            module.CommandText =
                @"INSERT INTO modules (course_id, title, position)
                  SELECT $1, $2, COALESCE(MAX(position), 0) + 1
                  FROM modules WHERE course_id = $1
                  RETURNING id";
            module.Parameters.AddWithValue(courseId);
            module.Parameters.AddWithValue(title);
            moduleId = (long)(await module.ExecuteScalarAsync())!;
        }
        await InsertMaterialAsync(connection, transaction, moduleId, title, kind, body);
        await transaction.CommitAsync();
        return checked((int)moduleId);
    }

    public async Task<bool> UpdateLessonAsync(long courseId, int lessonId, string title, string kind, string body)
    {
        await using var connection = await db.OpenConnectionAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        await using (var module = connection.CreateCommand())
        {
            module.Transaction = transaction;
            module.CommandText = "UPDATE modules SET title = $3 WHERE id = $1 AND course_id = $2 AND EXISTS (SELECT 1 FROM materials WHERE module_id = modules.id)";
            module.Parameters.AddWithValue(lessonId);
            module.Parameters.AddWithValue(courseId);
            module.Parameters.AddWithValue(title);
            if (await module.ExecuteNonQueryAsync() == 0)
            {
                await transaction.RollbackAsync();
                return false;
            }
        }
        await using (var material = connection.CreateCommand())
        {
            material.Transaction = transaction;
            material.CommandText =
                @"UPDATE materials SET title = $2, kind = $3, body = $4, resource_url = NULL
                  WHERE module_id = $1 AND id = (
                      SELECT id FROM materials WHERE module_id = $1 ORDER BY position LIMIT 1
                  )";
            material.Parameters.AddWithValue(lessonId);
            material.Parameters.AddWithValue(title);
            material.Parameters.AddWithValue(DatabaseKind(kind));
            material.Parameters.AddWithValue(body);
            await material.ExecuteNonQueryAsync();
        }
        await transaction.CommitAsync();
        return true;
    }

    public async Task<bool> DeleteLessonAsync(long courseId, int lessonId)
    {
        await using var cmd = db.CreateCommand(
            @"DELETE FROM modules m
              WHERE m.id = $1 AND m.course_id = $2
                AND EXISTS (SELECT 1 FROM materials a WHERE a.module_id = m.id)");
        cmd.Parameters.AddWithValue(lessonId);
        cmd.Parameters.AddWithValue(courseId);
        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<List<SQuestion>> GetQuestionsAsync(long courseId)
    {
        var result = new List<SQuestion>();
        await using var connection = await db.OpenConnectionAsync();
        var quizId = await FindFinalQuizIdAsync(connection, null, courseId);
        if (quizId is null) return result;

        await using var questions = connection.CreateCommand();
        questions.CommandText = "SELECT id, text FROM questions WHERE quiz_id = $1 ORDER BY position, id";
        questions.Parameters.AddWithValue(quizId.Value);
        await using var reader = await questions.ExecuteReaderAsync();
        var rows = new List<(int Id, string Text)>();
        while (await reader.ReadAsync()) rows.Add((checked((int)reader.GetInt64(0)), reader.GetString(1)));
        await reader.CloseAsync();

        foreach (var (id, text) in rows)
        {
            await using var optionsCommand = connection.CreateCommand();
            optionsCommand.CommandText =
                "SELECT text, is_correct FROM answer_options WHERE question_id = $1 ORDER BY position";
            optionsCommand.Parameters.AddWithValue(id);
            var options = new List<string>();
            var answer = 0;
            await using var optionsReader = await optionsCommand.ExecuteReaderAsync();
            while (await optionsReader.ReadAsync())
            {
                if (optionsReader.GetBoolean(1)) answer = options.Count;
                options.Add(optionsReader.GetString(0));
            }
            if (options.Count == 4) result.Add(new SQuestion(id, courseId, text, options.ToArray(), answer));
        }
        return result;
    }

    public async Task<SQuestion?> GetQuestionAsync(long courseId, int questionId) =>
        (await GetQuestionsAsync(courseId)).FirstOrDefault(q => q.Id == questionId);

    public async Task AddQuestionAsync(long courseId, string text, string[] options, int answer)
    {
        await using var connection = await db.OpenConnectionAsync();
        var quizId = await GetOrCreateFinalQuizIdAsync(connection, null, courseId);
        await InsertQuestionAsync(connection, null, quizId, text, options, answer);
    }

    public async Task<bool> UpdateQuestionAsync(long courseId, int questionId, string text, string[] options, int answer)
    {
        await using var connection = await db.OpenConnectionAsync();
        var quizId = await FindFinalQuizIdAsync(connection, null, courseId);
        if (quizId is null) return false;
        await using var transaction = await connection.BeginTransactionAsync();
        await using (var update = connection.CreateCommand())
        {
            update.Transaction = transaction;
            update.CommandText = "UPDATE questions SET text = $3 WHERE id = $1 AND quiz_id = $2";
            update.Parameters.AddWithValue(questionId);
            update.Parameters.AddWithValue(quizId.Value);
            update.Parameters.AddWithValue(text);
            if (await update.ExecuteNonQueryAsync() == 0)
            {
                await transaction.RollbackAsync();
                return false;
            }
        }
        await using (var delete = connection.CreateCommand())
        {
            delete.Transaction = transaction;
            delete.CommandText = "DELETE FROM answer_options WHERE question_id = $1";
            delete.Parameters.AddWithValue(questionId);
            await delete.ExecuteNonQueryAsync();
        }
        await InsertOptionsAsync(connection, transaction, questionId, options, answer);
        await transaction.CommitAsync();
        return true;
    }

    public async Task<bool> DeleteQuestionAsync(long courseId, int questionId)
    {
        await using var cmd = db.CreateCommand(
            @"DELETE FROM questions q USING quizzes z, modules m
              WHERE q.id = $1 AND q.quiz_id = z.id AND z.module_id = m.id
                AND z.is_final_exam AND m.course_id = $2");
        cmd.Parameters.AddWithValue(questionId);
        cmd.Parameters.AddWithValue(courseId);
        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<ExamSettings> GetExamSettingsAsync(long courseId)
    {
        await using var cmd = db.CreateCommand(
            @"SELECT q.title, q.duration_minutes, q.pass_score
              FROM quizzes q JOIN modules m ON m.id = q.module_id
              WHERE m.course_id = $1 AND q.is_final_exam");
        cmd.Parameters.AddWithValue(courseId);
        await using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync()) return new ExamSettings();
        return new ExamSettings
        {
            Title = reader.GetString(0),
            DurationMinutes = reader.GetInt32(1),
            PassMark = decimal.ToInt32(reader.GetDecimal(2))
        };
    }

    public async Task SaveExamSettingsAsync(long courseId, string title, int minutes, int passMark)
    {
        await using var connection = await db.OpenConnectionAsync();
        var quizId = await GetOrCreateFinalQuizIdAsync(connection, null, courseId);
        await using var cmd = connection.CreateCommand();
        cmd.CommandText = "UPDATE quizzes SET title = $2, duration_minutes = $3, pass_score = $4 WHERE id = $1";
        cmd.Parameters.AddWithValue(quizId);
        cmd.Parameters.AddWithValue(title);
        cmd.Parameters.AddWithValue(minutes);
        cmd.Parameters.AddWithValue(passMark);
        await cmd.ExecuteNonQueryAsync();
    }

    private static async Task<long?> FindFinalQuizIdAsync(NpgsqlConnection connection, NpgsqlTransaction? transaction, long courseId)
    {
        await using var cmd = connection.CreateCommand();
        cmd.Transaction = transaction;
        cmd.CommandText =
            @"SELECT q.id FROM quizzes q JOIN modules m ON m.id = q.module_id
              WHERE m.course_id = $1 AND q.is_final_exam LIMIT 1";
        cmd.Parameters.AddWithValue(courseId);
        var result = await cmd.ExecuteScalarAsync();
        return result is null or DBNull ? null : Convert.ToInt64(result);
    }

    private static async Task<long> GetOrCreateFinalQuizIdAsync(NpgsqlConnection connection, NpgsqlTransaction? transaction, long courseId)
    {
        if (transaction is null)
        {
            await using var newTransaction = await connection.BeginTransactionAsync();
            var createdQuizId = await GetOrCreateFinalQuizIdAsync(connection, newTransaction, courseId);
            await newTransaction.CommitAsync();
            return createdQuizId;
        }

        await LockCourseAsync(connection, transaction, courseId);
        var existing = await FindFinalQuizIdAsync(connection, transaction, courseId);
        if (existing is not null) return existing.Value;

        long moduleId;
        await using (var module = connection.CreateCommand())
        {
            module.Transaction = transaction;
            module.CommandText =
                @"INSERT INTO modules (course_id, title, position)
                  SELECT $1, 'Final exam', COALESCE(MAX(position), 0) + 1
                  FROM modules WHERE course_id = $1
                  RETURNING id";
            module.Parameters.AddWithValue(courseId);
            moduleId = (long)(await module.ExecuteScalarAsync())!;
        }
        await using var quiz = connection.CreateCommand();
        quiz.Transaction = transaction;
        quiz.CommandText = "INSERT INTO quizzes (module_id, title, is_final_exam) VALUES ($1, 'Final exam', TRUE) RETURNING id";
        quiz.Parameters.AddWithValue(moduleId);
        return (long)(await quiz.ExecuteScalarAsync())!;
    }

    private static async Task LockCourseAsync(NpgsqlConnection connection, NpgsqlTransaction transaction, long courseId)
    {
        await using var cmd = connection.CreateCommand();
        cmd.Transaction = transaction;
        cmd.CommandText = "SELECT pg_advisory_xact_lock(hashtextextended($1, 0))";
        cmd.Parameters.AddWithValue(courseId.ToString(System.Globalization.CultureInfo.InvariantCulture));
        await cmd.ExecuteScalarAsync();
    }

    private static async Task InsertQuestionAsync(
        NpgsqlConnection connection, NpgsqlTransaction? transaction, long quizId, string text, string[] options, int answer)
    {
        long questionId;
        await using (var question = connection.CreateCommand())
        {
            question.Transaction = transaction;
            question.CommandText =
                @"INSERT INTO questions (quiz_id, text, kind, position)
                  SELECT $1, $2, 'single', COALESCE(MAX(position), 0) + 1
                  FROM questions WHERE quiz_id = $1 RETURNING id";
            question.Parameters.AddWithValue(quizId);
            question.Parameters.AddWithValue(text);
            questionId = (long)(await question.ExecuteScalarAsync())!;
        }
        await InsertOptionsAsync(connection, transaction, questionId, options, answer);
    }

    private static async Task InsertOptionsAsync(
        NpgsqlConnection connection, NpgsqlTransaction? transaction, long questionId, string[] options, int answer)
    {
        for (var index = 0; index < options.Length; index++)
        {
            await using var option = connection.CreateCommand();
            option.Transaction = transaction;
            option.CommandText =
                "INSERT INTO answer_options (question_id, text, is_correct, position) VALUES ($1, $2, $3, $4)";
            option.Parameters.AddWithValue(questionId);
            option.Parameters.AddWithValue(options[index]);
            option.Parameters.AddWithValue(index == answer);
            option.Parameters.AddWithValue(index + 1);
            await option.ExecuteNonQueryAsync();
        }
    }

    private static async Task InsertMaterialAsync(
        NpgsqlConnection connection, NpgsqlTransaction transaction, long moduleId, string title, string kind, string body)
    {
        await using var material = connection.CreateCommand();
        material.Transaction = transaction;
        material.CommandText =
            "INSERT INTO materials (module_id, kind, title, body, position) VALUES ($1, $2, $3, $4, 1)";
        material.Parameters.AddWithValue(moduleId);
        material.Parameters.AddWithValue(DatabaseKind(kind));
        material.Parameters.AddWithValue(title);
        material.Parameters.AddWithValue(body);
        await material.ExecuteNonQueryAsync();
    }

    private static string DatabaseKind(string kind) => kind switch
    {
        "Text" => "text",
        "Video" => "video",
        "PDF" => "pdf",
        _ => throw new ArgumentOutOfRangeException(nameof(kind), kind, "Unsupported lesson type.")
    };

    private static string DisplayKind(string kind) => kind switch
    {
        "text" => "Text",
        "video" => "Video",
        "pdf" => "PDF",
        _ => kind
    };
}
