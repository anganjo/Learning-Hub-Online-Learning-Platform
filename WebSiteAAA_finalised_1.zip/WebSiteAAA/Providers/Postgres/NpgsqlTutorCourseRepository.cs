using Npgsql;
using WebSiteAAA.Services;

namespace WebSiteAAA.Providers.Postgres;

public sealed class NpgsqlTutorCourseRepository(NpgsqlDataSource db) : ITutorCourseRepository
{
    public async Task<HashSet<long>> GetCourseIdsAsync(string tutorUsername)
    {
        await using var cmd = db.CreateCommand("SELECT course_id FROM course_tutors WHERE tutor_username = $1::citext");
        cmd.Parameters.AddWithValue(tutorUsername);
        var ids = new HashSet<long>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync()) ids.Add(reader.GetInt64(0));
        return ids;
    }

    public async Task<List<string>> GetTutorsAsync(long courseId)
    {
        await using var cmd = db.CreateCommand(
            "SELECT tutor_username::text FROM course_tutors WHERE course_id = $1 ORDER BY tutor_username");
        cmd.Parameters.AddWithValue(courseId);
        var names = new List<string>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync()) names.Add(reader.GetString(0));
        return names;
    }

    public async Task<bool> AssignAsync(long courseId, string tutorUsername)
    {
        await using var cmd = db.CreateCommand(
            @"INSERT INTO course_tutors (course_id, tutor_username) VALUES ($1, $2::citext)
              ON CONFLICT DO NOTHING");
        cmd.Parameters.AddWithValue(courseId);
        cmd.Parameters.AddWithValue(tutorUsername);
        return await cmd.ExecuteNonQueryAsync() == 1;
    }

    public async Task<bool> RemoveAsync(long courseId, string tutorUsername)
    {
        await using var cmd = db.CreateCommand(
            "DELETE FROM course_tutors WHERE course_id = $1 AND tutor_username = $2::citext");
        cmd.Parameters.AddWithValue(courseId);
        cmd.Parameters.AddWithValue(tutorUsername);
        return await cmd.ExecuteNonQueryAsync() == 1;
    }
}
