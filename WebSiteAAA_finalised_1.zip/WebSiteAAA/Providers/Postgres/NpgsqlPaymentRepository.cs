using Npgsql;
using WebSiteAAA.Core;

namespace WebSiteAAA.Providers.Postgres;




public class NpgsqlPaymentRepository : IPaymentRepository
{
    private const string Columns =
        "id, student_username::text, course_id, amount, currency, status, provider, provider_ref, created_at, paid_at";

    private readonly NpgsqlDataSource _db;
    public NpgsqlPaymentRepository(NpgsqlDataSource db) => _db = db;

    public async Task<decimal> GetPriceAsync(long courseId)
    {
        await using var cmd = _db.CreateCommand("SELECT price_amount FROM courses WHERE id = $1");
        cmd.Parameters.AddWithValue(courseId);
        return await cmd.ExecuteScalarAsync() is decimal d ? d : 0m;
    }

    public async Task SetPriceAsync(long courseId, decimal amount, string currency = "USD")
    {
        if (amount < 0) throw new ArgumentOutOfRangeException(nameof(amount));
        await using var cmd = _db.CreateCommand("UPDATE courses SET price_amount = $2, currency = $3 WHERE id = $1");
        cmd.Parameters.AddWithValue(courseId);
        cmd.Parameters.AddWithValue(amount);
        cmd.Parameters.AddWithValue(currency);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<long> CreateAsync(string studentUsername, long courseId)
    {
        await using var cmd = _db.CreateCommand(
            @"INSERT INTO payments (student_username, course_id, amount, currency)
              SELECT $1::citext, c.id, c.price_amount, c.currency FROM courses c
              WHERE c.id = $2
                AND NOT EXISTS (SELECT 1 FROM payments p
                                WHERE p.student_username = $1::citext AND p.course_id = c.id AND p.status = 'Paid')
              RETURNING id");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        return await cmd.ExecuteScalarAsync() is long id
            ? id
            : throw new InvalidOperationException("Unknown course or course already paid for.");
    }

    public async Task<bool> MarkPaidAsync(long paymentId, string provider, string providerRef)
    {
        
        
        await using var cmd = _db.CreateCommand(
            @"UPDATE payments SET status = 'Paid', paid_at = now(), provider = $2, provider_ref = $3
              WHERE id = $1 AND status = 'Pending'");
        cmd.Parameters.AddWithValue(paymentId);
        cmd.Parameters.AddWithValue(provider);
        cmd.Parameters.AddWithValue(providerRef);
        return await cmd.ExecuteNonQueryAsync() == 1;
    }

    public Task<bool> MarkFailedAsync(long paymentId) => TransitionAsync(paymentId, "Pending", "Failed");

    public Task<bool> RefundAsync(long paymentId) => TransitionAsync(paymentId, "Paid", "Refunded");

    private async Task<bool> TransitionAsync(long id, string from, string to)
    {
        await using var cmd = _db.CreateCommand("UPDATE payments SET status = $3 WHERE id = $1 AND status = $2");
        cmd.Parameters.AddWithValue(id);
        cmd.Parameters.AddWithValue(from);
        cmd.Parameters.AddWithValue(to);
        return await cmd.ExecuteNonQueryAsync() == 1;
    }

    public async Task<bool> HasPaidAsync(string studentUsername, long courseId)
    {
        await using var cmd = _db.CreateCommand("SELECT has_paid_access($1::citext, $2)");
        cmd.Parameters.AddWithValue(studentUsername);
        cmd.Parameters.AddWithValue(courseId);
        return await cmd.ExecuteScalarAsync() is true;
    }

    public async Task<List<PaymentRecord>> GetForStudentAsync(string studentUsername)
    {
        await using var cmd = _db.CreateCommand($"SELECT {Columns} FROM payments WHERE student_username = $1::citext ORDER BY id DESC");
        cmd.Parameters.AddWithValue(studentUsername);
        return await ReadAllAsync(cmd);
    }

    public async Task<List<PaymentRecord>> GetAllAsync()
    {
        await using var cmd = _db.CreateCommand($"SELECT {Columns} FROM payments ORDER BY id DESC");
        return await ReadAllAsync(cmd);
    }

    private static async Task<List<PaymentRecord>> ReadAllAsync(NpgsqlCommand cmd)
    {
        var list = new List<PaymentRecord>();
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
            list.Add(new PaymentRecord(
                r.GetInt64(0), r.GetString(1), r.GetInt64(2), r.GetDecimal(3), r.GetString(4).Trim(),
                Enum.Parse<PaymentStatus>(r.GetString(5)),
                r.IsDBNull(6) ? null : r.GetString(6), r.IsDBNull(7) ? null : r.GetString(7),
                r.GetFieldValue<DateTimeOffset>(8), r.IsDBNull(9) ? null : r.GetFieldValue<DateTimeOffset>(9)));
        return list;
    }
}
