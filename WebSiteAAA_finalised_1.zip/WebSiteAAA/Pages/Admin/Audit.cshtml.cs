using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;

namespace WebSiteAAA.Pages.Admin;

[Authorize(Roles = "admin")]
public class AuditModel : PageModel
{
    private readonly AuthorizationService _authz;
    private readonly IAuditSink _audit;

    public AuditModel(AuthorizationService authz, IAuditSink audit)
    {
        _authz = authz;
        _audit = audit;
    }

    public List<AuditRecord> Events { get; private set; } = new();
    public bool ChainValid { get; private set; }
    public long? BrokenAtId { get; private set; }
    public string? Error { get; private set; }

    public async Task OnGetAsync()
    {
        var token = User.GetAaaToken();
        if (token is null || !await _authz.RequirePermissionAsync(token, "audit.read"))
        {
            Error = "Insufficient permissions";
            return;
        }

        var all = await _audit.GetAllOrderedAsync();
        Events = all.AsEnumerable().Reverse().Take(100).ToList();

        (ChainValid, BrokenAtId) = await AuditChain.VerifyAsync(_audit);
    }
}
