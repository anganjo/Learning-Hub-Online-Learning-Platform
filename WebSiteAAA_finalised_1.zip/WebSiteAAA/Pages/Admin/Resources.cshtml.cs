using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.Admin;



[Authorize(Roles = "admin")]
public class ResourcesModel(
    AuthorizationService authz,
    ICourseRepository courses,
    ICourseResourceRepository resources,
    ICourseContentRepository content) : PageModel
{
    public class RIn
    {
        public int Id { get; set; }
        [Required, MinLength(3)] public string Title { get; set; } = "";
        [Required] public string Category { get; set; } = "Lesson";
        [Required] public string Url { get; set; } = "";
        [Required, MinLength(5)] public string Description { get; set; } = "";
        [Required, MinLength(2)] public string Instructor { get; set; } = "";
    }

    [BindProperty(SupportsGet = true)] public long? CourseId { get; set; }
    [BindProperty(SupportsGet = true)] public int? Edit { get; set; }
    [BindProperty] public RIn In { get; set; } = new();
    [TempData] public string? Msg { get; set; }

    public List<CourseRecord> Courses { get; private set; } = new();
    public List<Resource> Items { get; private set; } = new();
    public ExamSettings Exam { get; private set; } = new();
    public string? Error { get; private set; }

    private async Task<bool> GateAsync()
    {
        var token = User.GetAaaToken();
        return token is not null && await authz.RequirePermissionAsync(token, "content.manage");
    }

    private async Task LoadAsync()
    {
        Courses = await courses.GetAllAsync();
        CourseId ??= Courses.FirstOrDefault()?.Id;
        if (CourseId is long c)
        {
            Items = await resources.GetForCourseAsync(c);
            Exam = await content.GetExamSettingsAsync(c);
        }
    }

    public async Task OnGetAsync()
    {
        if (!await GateAsync()) { Error = "Insufficient permissions"; return; }
        await LoadAsync();
        if (Edit is int id && await resources.GetAsync(id) is Resource r && r.CourseId == CourseId)
            In = new RIn { Id = r.Id, Title = r.Title, Category = r.Category, Url = r.Url, Description = r.Description, Instructor = r.Instructor };
    }

    public async Task<IActionResult> OnPostSaveAsync()
    {
        if (!await GateAsync()) return RedirectToPage(new { CourseId });
        
        if (!Uri.TryCreate(In.Url, UriKind.Absolute, out var u) || (u.Scheme != Uri.UriSchemeHttps && u.Scheme != Uri.UriSchemeHttp))
            ModelState.AddModelError("In.Url", "Enter a full link starting with http:// or https://");
        if (!ResourceCategories.All.Contains(In.Category)) ModelState.AddModelError("In.Category", "Choose a category from the list");
        if (CourseId is not long c || await courses.GetAsync(c) is null)
        {
            Error = "Choose a valid course.";
            await LoadAsync();
            return Page();
        }
        if (In.Id != 0 && (await resources.GetAsync(In.Id) is not Resource existing || existing.CourseId != c))
            ModelState.AddModelError("In.Id", "The resource could not be found in this course. Select it again and retry.");
        if (!ModelState.IsValid) { await LoadAsync(); return Page(); }

        var r = new Resource { Id = In.Id, CourseId = c, Title = In.Title.Trim(), Category = In.Category, Url = In.Url.Trim(), Description = In.Description.Trim(), Instructor = In.Instructor.Trim() };
        if (In.Id == 0)
        {
            await resources.CreateAsync(r);
            Msg = "Resource added.";
        }
        else if (await resources.UpdateAsync(r)) Msg = "Resource updated.";
        else
        {
            Msg = "The resource could not be updated because it no longer exists. Please select it again.";
        }
        return RedirectToPage(new { CourseId });
    }

    public async Task<IActionResult> OnPostDeleteAsync(int id)
    {
        if (await GateAsync() && CourseId is long c)
            Msg = await resources.DeleteAsync(c, id) ? "Resource deleted." : "Resource not found.";
        return RedirectToPage(new { CourseId });
    }

    public async Task<IActionResult> OnPostExamAsync(string title, int minutes, int passMark)
    {
        if (!await GateAsync() || CourseId is not long c) return RedirectToPage(new { CourseId });
        if (string.IsNullOrWhiteSpace(title) || minutes is < 5 or > 240 || passMark is < 1 or > 100)
            Msg = "Enter a title, a time limit of 5 to 240 minutes and a pass mark of 1 to 100.";
        else
        {
            await content.SaveExamSettingsAsync(c, title.Trim(), minutes, passMark);
            Msg = "Exam settings saved.";
        }
        return RedirectToPage(new { CourseId });
    }
}
