using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;

namespace WebSiteAAA.Pages.Admin;



[Authorize(Roles = "admin")]
public class DashboardModel(AuthorizationService authz, IUserRepository users, IRoleRepository roles,
    IAuditSink audit, ICourseRepository courses, IEnrollmentRepository enrollments) : PageModel
{
    public string? Error { get; private set; }
    public int TotalUsers { get; private set; }
    public int LockedOrDisabled { get; private set; }
    public int CourseCount { get; private set; }
    public int PendingCount { get; private set; }
    public bool ShowPending { get; private set; }
    public bool ShowAudit { get; private set; }
    public List<(string Day, int Count)> Signups { get; private set; } = new();
    public int SignupMax { get; private set; }
    public SortedDictionary<string, int> RoleCounts { get; private set; } = new();
    public List<AuditRecord> Recent { get; private set; } = new();
    public List<(string Student, string Course, string At)> Pending { get; private set; } = new();

    public async Task OnGetAsync()
    {
        var token = User.GetAaaToken();
        if (token is null || !await authz.RequirePermissionAsync(token, "users.read"))
        {
            Error = "Insufficient permissions";
            return;
        }

        var all = await users.GetAllAsync(limit: 200, offset: 0);
        TotalUsers = all.Count;
        var now = DateTimeOffset.UtcNow;
        LockedOrDisabled = all.Count(u => !u.IsActive || (u.LockedUntil is DateTimeOffset l && l > now));

        for (var i = 6; i >= 0; i--)
        {
            var day = DateTime.UtcNow.Date.AddDays(-i);
            Signups.Add((day.ToString("ddd"), all.Count(u => u.CreatedAt.UtcDateTime.Date == day)));
        }
        SignupMax = Signups.Max(s => s.Count);

        foreach (var u in all)
            foreach (var role in await roles.GetRolesAsync(u.Username))
                RoleCounts[role] = RoleCounts.GetValueOrDefault(role) + 1;

        var courseList = await courses.GetAllAsync();
        CourseCount = courseList.Count;

        if (await authz.RequirePermissionAsync(token, "enrollment.approve"))
        {
            ShowPending = true;
            var names = courseList.ToDictionary(c => c.Id, c => c.Name);
            var pending = await enrollments.GetPendingAsync();
            PendingCount = pending.Count;
            Pending = pending.Take(5)
                .Select(e => (e.StudentUsername, names.GetValueOrDefault(e.CourseId, "Course #" + e.CourseId), e.RequestedAt.ToString("yyyy-MM-dd HH:mm")))
                .ToList();
        }

        if (await authz.RequirePermissionAsync(token, "audit.read"))
        {
            ShowAudit = true;
            Recent = (await audit.GetAllOrderedAsync()).AsEnumerable().Reverse().Take(8).ToList();
        }
    }
}
