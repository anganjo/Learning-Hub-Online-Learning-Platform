using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;

namespace WebSiteAAA.Pages.Admin;





[Authorize(Roles = "admin")]
public class UsersModel : PageModel
{
    private readonly AuthorizationService _authz;
    private readonly IUserRepository _users;
    private readonly IRoleRepository _roles;
    private readonly IAuditSink _audit;
    private readonly AuthService _auth;

    public UsersModel(AuthorizationService authz, IUserRepository users, IRoleRepository roles, IAuditSink audit, AuthService auth)
    {
        _authz = authz;
        _users = users;
        _roles = roles;
        _audit = audit;
        _auth = auth;
    }

    public List<UserSummary> Users { get; private set; } = new();
    public Dictionary<string, List<string>> RolesByUsername { get; private set; } = new();
    public List<string> AllRoles { get; private set; } = new();
    public bool CanAssignRoles { get; private set; }
    public bool CanCreateUsers { get; private set; }
    public string? Error { get; private set; }
    [BindProperty] public string NewUsername { get; set; } = "";
    [BindProperty] public string? NewEmail { get; set; }
    [BindProperty] public string NewPassword { get; set; } = "";

    public async Task OnGetAsync()
    {
        var token = User.GetAaaToken();
        if (token is null) { Error = "Session is invalid"; return; }

        if (!await _authz.RequirePermissionAsync(token, "users.read"))
        {
            Error = "Insufficient permissions";
            return;
        }

        Users = await _users.GetAllAsync(limit: 200, offset: 0);
        CanAssignRoles = await _authz.RequirePermissionAsync(token, "roles.assign");
        CanCreateUsers = await _authz.RequirePermissionAsync(token, "users.create");
        AllRoles = await _roles.GetAllRolesAsync();

        foreach (var u in Users)
        {
            RolesByUsername[u.Username] = await _roles.GetRolesAsync(u.Username);
        }
    }

    public async Task<IActionResult> OnPostCreateAsync()
    {
        var token = User.GetAaaToken();
        if (token is null || !await _authz.RequirePermissionAsync(token, "users.create")) return Forbid();
        try
        {
            var username = NewUsername?.Trim() ?? "";
            await _auth.RegisterAsync(username, NewPassword ?? "", string.IsNullOrWhiteSpace(NewEmail) ? null : NewEmail.Trim());
            TempData["Success"] = $"User {username} created.";
            return RedirectToPage();
        }
        catch (AuthError e)
        {
            Error = e.Message;
            NewPassword = "";
            await OnGetAsync();
            return Page();
        }
    }

    public async Task<IActionResult> OnPostDeleteAsync(string username)
    {
        var token = User.GetAaaToken();
        if (token is not null && await _authz.RequirePermissionAsync(token, "users.delete"))
        {
            await _users.DeleteAsync(username);
        }

        return RedirectToPage();
    }

    
    
    
    
    public async Task<IActionResult> OnPostAssignRoleAsync(string username, string role)
    {
        var token = User.GetAaaToken();
        if (token is not null && await _authz.RequirePermissionAsync(token, "roles.assign"))
        {
            var validRoles = await _roles.GetAllRolesAsync();
            if (validRoles.Contains(role))
            {
                await _roles.AssignRoleAsync(username, role);
                await AuditChain.RecordAsync(_audit, new AuditEvent(
                    "ADMIN", "ROLE_ASSIGN", "SUCCESS", User.Identity!.Name, "user_roles", $"{role} -> {username}"));
            }
        }

        return RedirectToPage();
    }

    
    
    
    
    
    
    public async Task<IActionResult> OnPostRevokeRoleAsync(string username, string role)
    {
        var token = User.GetAaaToken();
        var isSelfAdmin = role == "admin" && string.Equals(username, User.Identity!.Name, StringComparison.OrdinalIgnoreCase);

        if (token is not null && role != "user" && !isSelfAdmin
            && await _authz.RequirePermissionAsync(token, "roles.assign"))
        {
            if (await _roles.RevokeRoleAsync(username, role))
            {
                await AuditChain.RecordAsync(_audit, new AuditEvent(
                    "ADMIN", "ROLE_REVOKE", "SUCCESS", User.Identity!.Name, "user_roles", $"{role} <- {username}"));
            }
        }

        return RedirectToPage();
    }
}
