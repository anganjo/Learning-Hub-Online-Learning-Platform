using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;

namespace WebSiteAAA.Pages.Admin;

[Authorize(Roles = "admin")]
public class CoursesModel(
    AuthorizationService authz, ICourseRepository courses, IPaymentRepository payments,
    WebSiteAAA.Services.ITutorCourseRepository tutors, IRoleRepository roles) : PageModel
{
    [BindProperty(SupportsGet = true)] public long? EditId { get; set; }
    [BindProperty] public long CourseId { get; set; }
    [BindProperty, Required, StringLength(120, MinimumLength = 3)] public string Name { get; set; } = "";
    [BindProperty, Range(0, 100000)] public decimal Price { get; set; } = 25m;
    [TempData] public string? Msg { get; set; }

    public List<CourseRecord> Items { get; private set; } = new();
    public Dictionary<long, decimal> Prices { get; private set; } = new();
    public Dictionary<long, List<string>> Tutors { get; private set; } = new();
    public string? Error { get; private set; }

    private async Task<bool> GateAsync()
    {
        var token = User.GetAaaToken();
        return token is not null && await authz.RequirePermissionAsync(token, "courses.manage");
    }

    public async Task OnGetAsync()
    {
        if (!await GateAsync()) { Error = "Insufficient permissions"; return; }
        await LoadListAsync();
        if (EditId is long id)
        {
            var course = Items.FirstOrDefault(c => c.Id == id);
            if (course is null) { Error = "Course not found."; return; }
            CourseId = course.Id;
            Name = course.Name;
            Price = Prices.GetValueOrDefault(course.Id);
        }
    }

    private async Task LoadListAsync()
    {
        Items = await courses.GetAllAsync();
        foreach (var course in Items)
        {
            Prices[course.Id] = await payments.GetPriceAsync(course.Id);
            Tutors[course.Id] = await tutors.GetTutorsAsync(course.Id);
        }
    }

    public async Task<IActionResult> OnPostAssignTutorAsync(long courseId, string? tutorUsername)
    {
        if (!await GateAsync()) return Forbid();
        tutorUsername = (tutorUsername ?? "").Trim();
        if (await courses.GetAsync(courseId) is null) Msg = "Course not found.";
        else if (tutorUsername.Length == 0 || !(await roles.GetRolesAsync(tutorUsername)).Contains("tutor"))
            Msg = "That user does not exist or does not have the tutor role.";
        else Msg = await tutors.AssignAsync(courseId, tutorUsername) ? "Tutor assigned." : "Tutor is already assigned.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostRemoveTutorAsync(long courseId, string tutorUsername)
    {
        if (!await GateAsync()) return Forbid();
        Msg = await tutors.RemoveAsync(courseId, tutorUsername) ? "Tutor removed." : "Assignment not found.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostSaveAsync()
    {
        if (!await GateAsync()) return Forbid();
        Name = (Name ?? "").Trim();
        if (Name.Length is < 3 or > 120)
            ModelState.AddModelError(nameof(Name), "Enter a course name between 3 and 120 characters.");
        if (!ModelState.IsValid)
        {
            await LoadListAsync();
            return Page();
        }

        if (CourseId == 0)
        {
            var courseId = await courses.CreateAsync(Name);
            await payments.SetPriceAsync(courseId, Price, "USD");
            Msg = "Course created.";
        }
        else if (await courses.UpdateAsync(CourseId, Name))
        {
            await payments.SetPriceAsync(CourseId, Price, "USD");
            Msg = "Course updated.";
        }
        else
        {
            Msg = "Course not found.";
        }
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostDeleteAsync(long courseId)
    {
        if (!await GateAsync()) return Forbid();
        try
        {
            Msg = await courses.DeleteAsync(courseId)
                ? "Course deleted."
                : "Course not found.";
        }
        catch (InvalidOperationException ex)
        {
            Msg = ex.Message;
        }
        return RedirectToPage();
    }
}
