using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.Admin;


[Authorize(Roles = "admin")]
public class ContentModel(AuthorizationService authz, ICourseRepository courses, ICourseContentRepository content) : PageModel
{
    [BindProperty(SupportsGet = true)] public long? CourseId { get; set; }
    [BindProperty(SupportsGet = true)] public int? EditModuleId { get; set; }
    [BindProperty(SupportsGet = true)] public int? EditQuestionId { get; set; }
    [BindProperty] public string Title { get; set; } = "";
    [BindProperty] public string Kind { get; set; } = "Text";
    [BindProperty] public string Body { get; set; } = "";
    [BindProperty] public string QText { get; set; } = "";
    [TempData] public string? Msg { get; set; }

    public List<CourseRecord> Courses { get; private set; } = new();
    public List<SModule> Modules { get; private set; } = new();
    public List<SQuestion> Questions { get; private set; } = new();
    public string? Error { get; private set; }

    private async Task<bool> GateAsync()
    {
        var token = User.GetAaaToken();
        return token is not null && await authz.RequirePermissionAsync(token, "content.manage");
    }

    public async Task OnGetAsync()
    {
        if (!await GateAsync()) { Error = "Insufficient permissions"; return; }
        Courses = await courses.GetAllAsync();
        CourseId ??= Courses.FirstOrDefault()?.Id;
        if (CourseId is long c)
        {
            Modules = await content.GetLessonsAsync(c);
            Questions = await content.GetQuestionsAsync(c);
        }
        if (CourseId is long moduleCourseId && EditModuleId is int moduleId &&
            await content.GetLessonAsync(moduleCourseId, moduleId) is null)
            Error = "Lesson not found.";
        if (CourseId is long courseId && EditQuestionId is int questionId &&
            await content.GetQuestionAsync(courseId, questionId) is null)
            Error = "Question not found.";
    }

    public async Task<IActionResult> OnPostModuleAsync()
    {
        if (!await GateAsync()) return RedirectToPage(new { CourseId });
        if (CourseId is long c && Title.Trim().Length >= 3 && Body.Trim().Length >= 5 &&
            Kind is "Text" or "Video" or "PDF")
        { await content.AddLessonAsync(c, Title.Trim(), Kind, Body.Trim()); Msg = "Lesson added."; }
        else Msg = "Enter a title (3+ characters), choose a valid type, and provide lesson text (5+ characters).";
        return RedirectToPage(new { CourseId });
    }

    public async Task<IActionResult> OnPostDeleteModuleAsync(int id)
    {
        if (await GateAsync() && CourseId is long c)
            Msg = await content.DeleteLessonAsync(c, id) ? "Lesson deleted." : "Lesson not found.";
        return RedirectToPage(new { CourseId });
    }

    public async Task<IActionResult> OnPostUpdateModuleAsync(int id)
    {
        if (!await GateAsync()) return RedirectToPage(new { CourseId });
        var title = Title.Trim();
        var body = Body.Trim();
        if (CourseId is long c && await content.GetLessonAsync(c, id) is not null &&
            title.Length >= 3 && body.Length >= 5 &&
            Kind is "Text" or "Video" or "PDF")
        {
            Msg = await content.UpdateLessonAsync(c, id, title, Kind, body)
                ? "Lesson updated." : "Lesson not found.";
        }
        else Msg = "Enter a title (3+ characters), choose a valid type, and provide lesson text (5+ characters).";
        return RedirectToPage(new { CourseId });
    }

    public async Task<IActionResult> OnPostQuestionAsync(string[] opt, int answer)
    {
        if (!await GateAsync()) return RedirectToPage(new { CourseId });
        if (CourseId is long c && QText.Trim().Length >= 5 && opt.Length == 4 && opt.All(o => !string.IsNullOrWhiteSpace(o)))
        { await content.AddQuestionAsync(c, QText.Trim(), opt.Select(o => o.Trim()).ToArray(), Math.Clamp(answer, 0, 3)); Msg = "Question added."; }
        else Msg = "Please enter the question (5+ characters) and all four options.";
        return RedirectToPage(new { CourseId });
    }

    public async Task<IActionResult> OnPostDeleteQuestionAsync(int id)
    {
        if (await GateAsync() && CourseId is long c)
            Msg = await content.DeleteQuestionAsync(c, id) ? "Question deleted." : "Question not found.";
        return RedirectToPage(new { CourseId });
    }

    public async Task<IActionResult> OnPostUpdateQuestionAsync(int id, string[] opt, int answer)
    {
        if (!await GateAsync()) return RedirectToPage(new { CourseId });
        if (CourseId is long c && await content.GetQuestionAsync(c, id) is not null &&
            QText.Trim().Length >= 5 && opt.Length == 4 &&
            opt.All(o => !string.IsNullOrWhiteSpace(o)) && answer is >= 0 and <= 3)
        {
            Msg = await content.UpdateQuestionAsync(c, id, QText.Trim(), opt.Select(o => o.Trim()).ToArray(), answer)
                ? "Question updated." : "Question not found.";
        }
        else Msg = "Please enter the question (5+ characters), all four options, and a valid correct answer.";
        return RedirectToPage(new { CourseId });
    }
}
