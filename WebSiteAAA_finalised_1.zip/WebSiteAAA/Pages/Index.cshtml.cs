using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;

namespace WebSiteAAA.Pages;

public class IndexModel : PageModel
{
    private readonly AuthService _auth;
    private readonly RateLimiter _rateLimiter;

    public IndexModel(AuthService auth, RateLimiter rateLimiter)
    {
        _auth = auth;
        _rateLimiter = rateLimiter;
    }

    [BindProperty]
    public string Username { get; set; } = "";

    [BindProperty]
    public string Password { get; set; } = "";

    public string? Error { get; private set; }

    public void OnGet() { }

    public async Task<IActionResult> OnPostAsync()
    {
        if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrWhiteSpace(Password))
        {
            Error = "Enter a username and password";
            return Page();
        }

        var clientIp = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        if (_rateLimiter.IsRateLimited(clientIp))
        {
            Error = "Too many login attempts. Please wait a moment and try again.";
            return Page();
        }

        string token;
        try
        {
            token = await _auth.LoginAsync(Username, Password);
        }
        catch (AuthError e)
        {
            Error = e.Message;
            return Page();
        }

        var roles = await _auth.GetRolesAsync(Username);
        await SiteAuth.SignInAsync(HttpContext, Username, token, roles);

        var destination = roles.Contains("admin")
            ? "/Admin/Users"
            : roles.Contains("tutor")
                ? "/Tutor/Index"
                : "/User/Dashboard";
        return RedirectToPage(destination);
    }
}
