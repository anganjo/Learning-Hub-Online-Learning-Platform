using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.User;



[Authorize(Policy = "StudentOnly")]
public class ExamModel(ICourseRepository courses, ContentAccess access,
    ICourseContentRepository content, CertificateAwarder certificateAwarder,
    IExamResultRepository examResults, ICertificateRepository certificates,
    IExamAttemptRepository examAttempts,
    ILessonProgressRepository lessonProgress, IAssignmentSubmissionRepository assignments,
    ICourseResourceRepository resources,
    ICourseFeedbackRepository courseFeedback) : PageModel
{
    [BindProperty(SupportsGet = true)] public long CourseId { get; set; }
    public CourseRecord? Course { get; private set; }
    public bool Granted { get; private set; }
    public ExamSettings Settings { get; private set; } = new();
    public List<SQuestion> Questions { get; private set; } = new();
    public bool Running { get; private set; }
    public bool Passed { get; private set; }
    public int SecondsLeft { get; private set; }
    public int? Best { get; private set; }
    public ExamResult? Result { get; private set; }
    public int CompletedLessonCount { get; private set; }
    public int LessonCount { get; private set; }
    public int CompletedTutorialCount { get; private set; }
    public int TutorialCount { get; private set; }
    public bool CanSitForExam => CompletedLessonCount == LessonCount && CompletedTutorialCount == TutorialCount;
    public bool FeedbackDue { get; private set; }
    [BindProperty, Range(1, 5)] public int FeedbackRating { get; set; }
    [BindProperty, Required, StringLength(2000, MinimumLength = 5)] public string? FeedbackComments { get; set; }
    [TempData] public string? FeedbackMessage { get; set; }

    private async Task LoadAsync()
    {
        Course = await courses.GetAsync(CourseId);
        if (Course is null) return;
        var user = User.Identity!.Name!;
        Granted = await access.CanViewCourseAsync(user, CourseId);
        if (!Granted) return;
        Settings = await content.GetExamSettingsAsync(CourseId);
        Questions = await content.GetQuestionsAsync(CourseId);
        var lessons = await content.GetLessonsAsync(CourseId);
        var completedLessonKeys = await lessonProgress.GetCompletedKeysAsync(user, CourseId);
        LessonCount = lessons.Count;
        CompletedLessonCount = lessons.Count(lesson => completedLessonKeys.Contains(lesson.ProgressKey));

        var tutorials = await resources.GetForCourseAsync(CourseId, "Tutorial");
        var studentSubmissions = await assignments.GetForStudentAsync(user, CourseId);
        TutorialCount = tutorials.Count;
        CompletedTutorialCount = tutorials.Count(tutorial => studentSubmissions.Any(submission =>
            submission.ResourceId == tutorial.Id ||
            submission.TaskName.Equals(tutorial.Title, StringComparison.OrdinalIgnoreCase)));

        var outcome = await examResults.GetOutcomeAsync(user, CourseId);
        var certificate = (await certificates.GetForStudentAsync(user))
            .FirstOrDefault(c => c.CourseId == CourseId);
        Best = outcome.BestScore ?? certificate?.ExamScore;
        Passed = outcome.Passed || certificate is not null;
        var submittedFeedback = await courseFeedback.GetForStudentAsync(user);
        FeedbackDue = Passed && !submittedFeedback.Any(feedback => feedback.CourseId == CourseId);
        if (await examAttempts.GetStartedAsync(user, CourseId) is DateTimeOffset s)
        {
            var left = (int)(s.AddMinutes(Settings.DurationMinutes) - DateTimeOffset.UtcNow).TotalSeconds;
            if (left > 0 && !Passed) { Running = true; SecondsLeft = left; }
        }
    }

    public async Task OnGetAsync() => await LoadAsync();

    public async Task<IActionResult> OnPostStartAsync()
    {
        await LoadAsync();
        if (Granted && CanSitForExam && !Passed && Questions.Count > 0 && !Running)
            await examAttempts.StartAsync(User.Identity!.Name!, CourseId, Settings.DurationMinutes);
        return RedirectToPage(new { CourseId });
    }

    public async Task<IActionResult> OnPostSubmitAsync(Dictionary<int, int> a)
    {
        await LoadAsync();
        if (!Granted || Passed || !CanSitForExam) return Page();
        var user = User.Identity!.Name!;
        
        if (await examAttempts.GetStartedAsync(user, CourseId) is DateTimeOffset s &&
            DateTimeOffset.UtcNow <= s.AddMinutes(Settings.DurationMinutes).AddSeconds(30))
        {
            var ok = Questions.Count(q => a.TryGetValue(q.Id, out var v) && v == q.Answer);
            var score = Questions.Count == 0 ? 0 : ok * 100 / Questions.Count;
            Result = new ExamResult
            {
                Student = user,
                CourseId = CourseId,
                Score = score,
                Passed = score >= Settings.PassMark
            };
            await examResults.RecordAsync(user, CourseId, score, Result.Passed);
            await certificateAwarder.TryAwardAsync(user, CourseId);
        }
        await examAttempts.EndAsync(user, CourseId);
        Running = false;
        var outcome = await examResults.GetOutcomeAsync(user, CourseId);
        var certificate = (await certificates.GetForStudentAsync(user))
            .FirstOrDefault(c => c.CourseId == CourseId);
        Best = outcome.BestScore ?? certificate?.ExamScore;
        Passed = outcome.Passed || certificate is not null;
        var submittedFeedback = await courseFeedback.GetForStudentAsync(user);
        FeedbackDue = Passed && !submittedFeedback.Any(feedback => feedback.CourseId == CourseId);
        return Page();
    }

    public async Task<IActionResult> OnPostFeedbackAsync()
    {
        await LoadAsync();
        if (!Granted || !Passed || !FeedbackDue) return Forbid();
        if (!ModelState.IsValid)
        {
            ModelState.AddModelError(string.Empty, "Please choose a rating and enter at least 5 characters of feedback.");
            return Page();
        }

        var saved = await courseFeedback.SubmitAsync(
            User.Identity!.Name!, CourseId, FeedbackRating, FeedbackComments!.Trim());
        FeedbackMessage = saved
            ? "Thank you for sharing your feedback."
            : "Feedback for this course has already been submitted.";
        return RedirectToPage(new { CourseId });
    }
}
