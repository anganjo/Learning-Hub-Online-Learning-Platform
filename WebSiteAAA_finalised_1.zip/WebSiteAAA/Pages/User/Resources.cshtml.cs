using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.User;



[Authorize(Policy = "StudentOnly")]
public class ResourcesModel(
    ICourseRepository courses,
    ContentAccess access,
    ICourseResourceRepository resources,
    IAssignmentSubmissionRepository assignments,
    IWebHostEnvironment env) : PageModel
{
    private static readonly string[] AllowedExtensions =
        { ".pdf", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".txt", ".zip", ".png", ".jpg", ".jpeg", ".py", ".java", ".cs" };
    private const long MaxBytes = 10_000_000;

    [BindProperty(SupportsGet = true)] public long? CourseId { get; set; }
    [BindProperty(SupportsGet = true)] public string? Category { get; set; }
    [BindProperty(SupportsGet = true)] public string? Q { get; set; }
    [TempData] public string? Msg { get; set; }

    public List<CourseRecord> Courses { get; private set; } = new();
    public CourseRecord? Course { get; private set; }
    public bool Granted { get; private set; }
    public List<Resource> Items { get; private set; } = new();
    public Dictionary<int, Submission> Mine { get; private set; } = new();

    public async Task OnGetAsync()
    {
        Courses = await courses.GetAllAsync();
        Course = Courses.FirstOrDefault(c => c.Id == CourseId);
        if (Course is null) return;
        var user = User.Identity!.Name!;
        Granted = await access.CanViewCourseAsync(user, Course.Id);
        if (!Granted) return;
        Items = await resources.GetForCourseAsync(Course.Id, Category, Q);
        var submissions = await assignments.GetForStudentAsync(user, Course.Id);
        foreach (var resource in Items.Where(item => item.Category == "Tutorial"))
        {
            var latest = submissions
                .Where(submission => submission.ResourceId == resource.Id ||
                    submission.TaskName.Equals(resource.Title, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(submission => submission.SubmittedAt)
                .FirstOrDefault();
            if (latest is not null) Mine[resource.Id] = latest;
        }
    }

    [RequestSizeLimit(MaxBytes + 1_000_000)]
    public async Task<IActionResult> OnPostSubmitAsync(int resourceId, IFormFile? file)
    {
        var user = User.Identity!.Name!;
        var res = await resources.GetAsync(resourceId);
        if (res is null || res.Category != "Tutorial" || !await access.CanViewCourseAsync(user, res.CourseId))
            return RedirectToPage(new { CourseId });

        var ext = Path.GetExtension(file?.FileName ?? "").ToLowerInvariant();
        if (file is null || file.Length == 0) Msg = "Please choose a file first.";
        else if (file.Length > MaxBytes) Msg = "That file is too large (10 MB maximum).";
        else if (!AllowedExtensions.Contains(ext)) Msg = "This file type is not allowed.";
        else
        {
            
            var folder = Path.Combine(env.ContentRootPath, "App_Data", "assignments");
            Directory.CreateDirectory(folder);
            var stored = Guid.NewGuid().ToString("N") + ext;
            var path = Path.Combine(folder, stored);
            var saved = false;
            try
            {
                await using (var fs = System.IO.File.Create(path))
                    await file.CopyToAsync(fs);
                await assignments.SubmitAsync(
                    res.CourseId, res.Id, res.Title, user, Path.GetFileName(file.FileName), stored);
                saved = true;
            }
            finally
            {
                if (!saved && System.IO.File.Exists(path)) System.IO.File.Delete(path);
            }
            Msg = "Assignment submitted.";
        }
        return RedirectToPage(new { CourseId = res.CourseId, Category = "Tutorial" });
    }
}
