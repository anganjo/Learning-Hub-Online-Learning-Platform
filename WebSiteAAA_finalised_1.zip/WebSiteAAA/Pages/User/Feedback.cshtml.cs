using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;

namespace WebSiteAAA.Pages.User;

[Authorize(Policy = "StudentOnly")]
public class FeedbackModel(
    ICourseRepository courses,
    ICertificateRepository certificates,
    ICourseFeedbackRepository feedbackRepository) : PageModel
{
    public record CourseItem(CourseRecord Course);

    public List<CourseItem> PendingCourses { get; private set; } = new();
    public string? Error { get; private set; }
    [TempData] public string? Message { get; set; }

    public async Task OnGetAsync()
    {
        await LoadPendingCoursesAsync();
    }

    public async Task<IActionResult> OnPostSubmitAsync(
        long courseId,
        [Range(1, 5)] int rating,
        [Required, StringLength(2000, MinimumLength = 5)] string comments)
    {
        var username = User.Identity!.Name!;
        var completedCourseIds = (await certificates.GetForStudentAsync(username))
            .Select(certificate => certificate.CourseId)
            .ToHashSet();
        if (!completedCourseIds.Contains(courseId))
            return Forbid();

        if (!ModelState.IsValid)
        {
            Error = "Please choose a rating and enter at least 5 characters of feedback.";
            await LoadPendingCoursesAsync();
            return Page();
        }

        var saved = await feedbackRepository.SubmitAsync(username, courseId, rating, comments.Trim());
        Message = saved
            ? "Thank you for sharing your course feedback."
            : "Feedback for this course has already been submitted.";
        return RedirectToPage();
    }

    private async Task LoadPendingCoursesAsync()
    {
        var username = User.Identity!.Name!;
        var completedCourseIds = (await certificates.GetForStudentAsync(username))
            .Select(certificate => certificate.CourseId)
            .ToHashSet();
        var submittedCourseIds = (await feedbackRepository.GetForStudentAsync(username))
            .Select(feedback => feedback.CourseId)
            .ToHashSet();
        var coursesById = (await courses.GetAllAsync()).ToDictionary(course => course.Id);

        PendingCourses = completedCourseIds
            .Where(courseId => !submittedCourseIds.Contains(courseId) && coursesById.ContainsKey(courseId))
            .Select(courseId => new CourseItem(coursesById[courseId]))
            .OrderBy(item => item.Course.Name)
            .ToList();
    }
}
