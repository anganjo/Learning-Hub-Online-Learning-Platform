using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.User;

[Authorize(Policy = "StudentOnly")]
public class LearningHistoryModel(
    ICourseRepository courses,
    IEnrollmentRepository enrollments,
    ICertificateRepository certificates,
    ICourseContentRepository content,
    LessonProgressService progress) : PageModel
{
    public record CourseHistoryItem(
        CourseRecord Course,
        EnrollmentStatus? EnrollmentStatus,
        int CompletedLessons,
        int LessonCount,
        bool IsFinished);

    public List<CourseHistoryItem> Items { get; private set; } = new();

    public async Task OnGetAsync()
    {
        var username = User.Identity!.Name!;
        var allCourses = await courses.GetAllAsync();
        var enrollmentByCourse = (await enrollments.GetForStudentAsync(username))
            .GroupBy(enrollment => enrollment.CourseId)
            .ToDictionary(group => group.Key, group => group.First());
        var finishedCourseIds = (await certificates.GetForStudentAsync(username))
            .Select(certificate => certificate.CourseId)
            .ToHashSet();

        foreach (var course in allCourses.Where(course =>
                     enrollmentByCourse.ContainsKey(course.Id) || finishedCourseIds.Contains(course.Id)))
        {
            var status = enrollmentByCourse.TryGetValue(course.Id, out var enrollment)
                ? enrollment.Status
                : (EnrollmentStatus?)null;
            var isFinished = finishedCourseIds.Contains(course.Id);
            var lessons = await content.GetLessonsAsync(course.Id);
            var completedCount = isFinished
                ? lessons.Count
                : status == EnrollmentStatus.Approved
                    ? (await progress.GetCompletedIdsAsync(username, course.Id)).Count
                    : 0;

            Items.Add(new CourseHistoryItem(
                course, status, completedCount, lessons.Count, isFinished));
        }
    }
}
