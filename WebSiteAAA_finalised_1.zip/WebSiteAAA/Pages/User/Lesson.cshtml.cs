using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.User;



[Authorize(Policy = "StudentOnly")]
public class LessonModel(ICourseRepository courses, ContentAccess access, ICourseContentRepository content,
    ICourseResourceRepository resources, CertificateAwarder certificateAwarder, LessonProgressService progress) : PageModel
{
    [BindProperty(SupportsGet = true)] public long CourseId { get; set; }
    [BindProperty(SupportsGet = true)] public int? LessonId { get; set; }

    public CourseRecord? Course { get; private set; }
    public bool Granted { get; private set; }
    public List<SModule> Lessons { get; private set; } = new();
    public HashSet<int> DoneIds { get; private set; } = new();
    public SModule? Current { get; private set; }
    public int Index { get; private set; } = -1;
    public int Pct { get; private set; }
    public string? VideoUrl { get; private set; }     
    public Resource? Reading { get; private set; }    

    private static bool IsEmbed(string u) =>
        u.StartsWith("https://www.youtube.com/embed/") || u.StartsWith("https://www.youtube-nocookie.com/embed/");

    private async Task LoadAsync()
    {
        Course = await courses.GetAsync(CourseId);
        if (Course is null) return;
        var user = User.Identity!.Name!;
        Granted = await access.CanViewCourseAsync(user, CourseId);
        if (!Granted) return;

        Lessons = await content.GetLessonsAsync(CourseId);
        DoneIds = await progress.GetCompletedIdsAsync(user, CourseId);
        Pct = Lessons.Count == 0 ? 0 : DoneIds.Count * 100 / Lessons.Count;
        Current = Lessons.FirstOrDefault(l => l.Id == LessonId)
                  ?? Lessons.FirstOrDefault(l => !DoneIds.Contains(l.Id))
                  ?? Lessons.FirstOrDefault();
        if (Current is null) return;
        Index = Lessons.IndexOf(Current);

        var courseResources = await resources.GetForCourseAsync(CourseId);
        
        
        var videos = courseResources.Where(r => r.Category == "Video" && IsEmbed(r.Url)).ToList();
        if (videos.Count == Lessons.Count) VideoUrl = videos[Index].Url;
        Reading = courseResources.FirstOrDefault(r => r.Category == "Lesson" && r.Title == Current.Title);
    }

    public async Task OnGetAsync() => await LoadAsync();

    public async Task<IActionResult> OnPostCompleteAsync(int lessonId)
    {
        await LoadAsync();
        if (!Granted) return RedirectToPage(new { CourseId });
        var lesson = Lessons.FirstOrDefault(l => l.Id == lessonId);
        if (lesson is not null)
        {
            var user = User.Identity!.Name!;
            await progress.MarkCompleteAsync(user, lesson);
            await certificateAwarder.TryAwardAsync(user, CourseId);
        }
        var i = lesson is null ? -1 : Lessons.IndexOf(lesson);
        var nextId = i >= 0 && i < Lessons.Count - 1 ? Lessons[i + 1].Id : lessonId;
        return RedirectToPage(new { CourseId, LessonId = nextId });
    }
}
