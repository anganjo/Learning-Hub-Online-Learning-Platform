using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;

namespace WebSiteAAA.Pages.User;

[Authorize(Policy = "StudentOnly")]
public class CertificatesModel(ICourseRepository courses, ICertificateRepository certificates) : PageModel
{
    public record Item(CourseRecord Course, int? Score, CertificateRecord Certificate);
    public List<Item> Items { get; private set; } = new();

    public async Task OnGetAsync()
    {
        var user = User.Identity!.Name!;
        var byId = (await courses.GetAllAsync()).ToDictionary(c => c.Id);
        foreach (var certificate in await certificates.GetForStudentAsync(user))
        {
            if (byId.TryGetValue(certificate.CourseId, out var course))
                Items.Add(new Item(course, certificate.ExamScore, certificate));
        }
    }
}
