using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.User;




[Authorize(Policy = "StudentOnly")]
public class CourseMaterialsModel : PageModel
{
    private readonly ICourseRepository _courses;
    private readonly IEnrollmentRepository _enrollments;
    private readonly IPaymentRepository _payments;
    private readonly ContentAccess _access;
    private readonly ICourseContentRepository _content;
    private readonly IQuizScoreRepository _quizScores;
    private readonly CertificateAwarder _certificateAwarder;
    private readonly LessonProgressService _progress;
    private readonly IExamResultRepository _examResults;
    private readonly ICertificateRepository _certificates;

    public CourseMaterialsModel(ICourseRepository courses, IEnrollmentRepository enrollments,
        IPaymentRepository payments, ContentAccess access, ICourseContentRepository content,
        IQuizScoreRepository quizScores,
        CertificateAwarder certificateAwarder, LessonProgressService progress,
        IExamResultRepository examResults, ICertificateRepository certificates)
    {
        _courses = courses;
        _enrollments = enrollments;
        _payments = payments;
        _access = access;
        _content = content;
        _quizScores = quizScores;
        _certificateAwarder = certificateAwarder;
        _progress = progress;
        _examResults = examResults;
        _certificates = certificates;
    }

    public List<CourseRecord> Courses { get; private set; } = new();
    public List<CourseCatalogItem> CatalogItems { get; private set; } = new();
    public CourseRecord? SelectedCourse { get; private set; }
    public bool Approved { get; private set; }
    public bool Paid { get; private set; }
    public bool Granted { get; private set; }
    public decimal Price { get; private set; }

    public List<SModule> Modules { get; private set; } = new();
    public HashSet<int> DoneIds { get; private set; } = new();
    public int Pct { get; private set; }
    public int? QuizScore { get; private set; }
    public bool QuizPassed { get; private set; }
    public int? ExamBest { get; private set; }
    public bool ExamPassed { get; private set; }

    public async Task OnGetAsync(long? courseId)
    {
        Courses = await _courses.GetAllAsync();
        if (courseId is null)
        {
            var user = User.Identity!.Name!;
            var enrollments = await _enrollments.GetForStudentAsync(user);
            var enrollmentByCourse = enrollments
                .GroupBy(e => e.CourseId)
                .ToDictionary(g => g.Key, g => g.OrderByDescending(e => e.RequestedAt).ThenByDescending(e => e.Id).First());
            var payments = await _payments.GetForStudentAsync(user);
            var paidCourseIds = payments
                .Where(p => p.Status == PaymentStatus.Paid)
                .Select(p => p.CourseId)
                .ToHashSet();
            var refundedCourseIds = payments
                .Where(p => p.Status == PaymentStatus.Refunded)
                .Select(p => p.CourseId)
                .ToHashSet();
            var rejectedCountByCourse = enrollments
                .Where(e => e.Status == EnrollmentStatus.Rejected)
                .GroupBy(e => e.CourseId)
                .ToDictionary(group => group.Key, group => group.Count());
            var completedCourseIds = (await _certificates.GetForStudentAsync(user))
                .Select(certificate => certificate.CourseId)
                .ToHashSet();

            foreach (var course in Courses)
            {
                var lessons = await _content.GetLessonsAsync(course.Id);
                var isCompleted = completedCourseIds.Contains(course.Id);
                var completed = isCompleted
                    ? lessons.Count
                    : enrollmentByCourse.TryGetValue(course.Id, out var enrollment) &&
                                enrollment.Status == EnrollmentStatus.Approved
                    ? (await _progress.GetCompletedIdsAsync(user, course.Id)).Count
                    : 0;
                CatalogItems.Add(new CourseCatalogItem(
                    course, enrollmentByCourse.GetValueOrDefault(course.Id),
                    paidCourseIds.Contains(course.Id), lessons.Count, completed, isCompleted,
                    rejectedCountByCourse.GetValueOrDefault(course.Id), refundedCourseIds.Contains(course.Id)));
            }
            return;
        }

        SelectedCourse = Courses.FirstOrDefault(c => c.Id == courseId);
        if (SelectedCourse is null) return;

        var name = User.Identity!.Name!;
        Approved = await _enrollments.IsApprovedAsync(name, SelectedCourse.Id);
        Paid = await _payments.HasPaidAsync(name, SelectedCourse.Id);
        Price = await _payments.GetPriceAsync(SelectedCourse.Id);
        Granted = await _access.CanViewCourseAsync(name, SelectedCourse.Id);

        if (Granted)
        {
            Modules = await _content.GetLessonsAsync(SelectedCourse.Id);
            DoneIds = await _progress.GetCompletedIdsAsync(name, SelectedCourse.Id);
            Pct = Modules.Count == 0 ? 0 : DoneIds.Count * 100 / Modules.Count;
            QuizScore = await _quizScores.GetScoreAsync(name, SelectedCourse.Id);
            QuizPassed = QuizScore is >= 50;
            var outcome = await _examResults.GetOutcomeAsync(name, SelectedCourse.Id);
            var certificate = (await _certificates.GetForStudentAsync(name))
                .FirstOrDefault(c => c.CourseId == SelectedCourse.Id);
            ExamBest = outcome.BestScore ?? certificate?.ExamScore;
            ExamPassed = outcome.Passed || certificate is not null;
        }
    }

    public record CourseCatalogItem(
        CourseRecord Course,
        EnrollmentRecord? Enrollment,
        bool Paid,
        int LessonCount,
        int CompletedLessons,
        bool IsCompleted,
        int RejectedAttempts,
        bool Refunded);

    public async Task<IActionResult> OnPostCompleteAsync(long courseId, int moduleId)
    {
        var name = User.Identity!.Name!;
        if (await _access.CanViewCourseAsync(name, courseId))
        {
            var module = await _content.GetLessonAsync(courseId, moduleId);
            if (module is not null) await _progress.MarkCompleteAsync(name, module);
            await _certificateAwarder.TryAwardAsync(name, courseId);
        }
        return RedirectToPage(new { courseId });
    }
}
