using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.User;

[Authorize(Policy = "StudentOnly")]
public class QuizModel(ICourseRepository courses, ContentAccess access, ICourseContentRepository content,
    IQuizScoreRepository scores) : PageModel
{
    [BindProperty(SupportsGet = true)] public long CourseId { get; set; }
    public CourseRecord? Course { get; private set; }
    public List<SQuestion> Questions { get; private set; } = new();
    public bool Granted { get; private set; }
    public int? Result { get; private set; }

    private async Task LoadAsync()
    {
        Course = await courses.GetAsync(CourseId);
        if (Course is null) return;
        Granted = await access.CanViewCourseAsync(User.Identity!.Name!, CourseId);
        if (Granted) Questions = await content.GetQuestionsAsync(CourseId);
    }

    public async Task OnGetAsync()
    {
        await LoadAsync();
        if (Granted) Result = await scores.GetScoreAsync(User.Identity!.Name!, CourseId);
    }

    public async Task<IActionResult> OnPostAsync(Dictionary<int, int> a)
    {
        await LoadAsync();
        if (Granted)
        {
            var correct = Questions.Count(q => a.TryGetValue(q.Id, out var selected) && selected == q.Answer);
            Result = Questions.Count == 0 ? 0 : correct * 100 / Questions.Count;
            await scores.RecordScoreAsync(User.Identity!.Name!, CourseId, Result.Value);
        }
        return Page();
    }
}
