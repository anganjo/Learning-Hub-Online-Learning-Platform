using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.User;

[Authorize(Policy = "StudentOnly")]
public class DashboardModel : PageModel
{
    private readonly ICourseRepository _courses;
    private readonly IEnrollmentRepository _enrollments;
    private readonly IPaymentRepository _payments;
    private readonly LessonProgressService _progress;
    private readonly ICommentRepository _comments;

    public DashboardModel(ICourseRepository courses, IEnrollmentRepository enrollments,
        IPaymentRepository payments, LessonProgressService progress, ICommentRepository comments)
    {
        _comments = comments;
        _courses = courses;
        _enrollments = enrollments;
        _payments = payments;
        _progress = progress;
    }

    public List<CourseRecord> Courses { get; private set; } = new();
    public List<EnrollmentRecord> MyEnrollments { get; private set; } = new();
    public HashSet<long> PaidCourseIds { get; private set; } = new();
    public HashSet<long> RefundedCourseIds { get; private set; } = new();
    public Dictionary<long, int> RejectedCountByCourse { get; private set; } = new();
    public Dictionary<long, HashSet<int>> CompletedLessonIds { get; private set; } = new();
    public List<CommentRecord> TutorComments { get; private set; } = new();
    [TempData] public string? Msg { get; set; }

    public async Task OnGetAsync()
    {
        Courses = await _courses.GetAllAsync();
        var username = User.Identity!.Name!;
        TutorComments = (await _comments.GetForStudentAsync(username)).OrderByDescending(c => c.CreatedAt).ToList();
        var enrollmentHistory = await _enrollments.GetForStudentAsync(username);
        RejectedCountByCourse = enrollmentHistory
            .Where(e => e.Status == EnrollmentStatus.Rejected)
            .GroupBy(e => e.CourseId)
            .ToDictionary(group => group.Key, group => group.Count());
        MyEnrollments = enrollmentHistory
            .GroupBy(e => e.CourseId)
            .Select(group => group.OrderByDescending(e => e.RequestedAt).ThenByDescending(e => e.Id).First())
            .ToList();
        var payments = await _payments.GetForStudentAsync(username);
        PaidCourseIds = payments
            .Where(p => p.Status == PaymentStatus.Paid)
            .Select(p => p.CourseId)
            .ToHashSet();
        RefundedCourseIds = payments
            .Where(p => p.Status == PaymentStatus.Refunded)
            .Select(p => p.CourseId)
            .ToHashSet();
        foreach (var enrollment in MyEnrollments.Where(e => e.Status == EnrollmentStatus.Approved))
            CompletedLessonIds[enrollment.CourseId] = await _progress.GetCompletedIdsAsync(username, enrollment.CourseId);
    }

    public async Task<IActionResult> OnPostEnrollAsync(long courseId)
    {
        if (await _courses.GetAsync(courseId) is null) return NotFound();
        var username = User.Identity!.Name!;
        var history = (await _enrollments.GetForStudentAsync(username))
            .Where(e => e.CourseId == courseId).ToList();
        if (history.Any(e => e.Status != EnrollmentStatus.Rejected) ||
            history.Count(e => e.Status == EnrollmentStatus.Rejected) >= 2)
            return RedirectToPage();

        if (history.Count(e => e.Status == EnrollmentStatus.Rejected) == 1)
        {
            var alreadyPaid = (await _payments.GetForStudentAsync(username))
                .Any(payment => payment.CourseId == courseId && payment.Status == PaymentStatus.Paid);
            if (!alreadyPaid)
            {
                Msg = "A paid enrollment is required before you can request enrollment again.";
                return RedirectToPage();
            }

            await _enrollments.RequestAsync(username, courseId);
            Msg = "Your re-enrollment request has been submitted.";
            return RedirectToPage();
        }

        return RedirectToPage("/User/Checkout", new { courseId });
    }
}
