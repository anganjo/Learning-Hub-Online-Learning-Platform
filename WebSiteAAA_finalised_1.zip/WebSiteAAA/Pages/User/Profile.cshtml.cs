using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;

namespace WebSiteAAA.Pages.User;

[Authorize]
public class ProfileModel : PageModel
{
    private readonly IUserRepository _users;
    private readonly IRoleRepository _roles;
    private readonly AuthService _auth;

    public ProfileModel(IUserRepository users, IRoleRepository roles, AuthService auth)
    {
        _users = users; _roles = roles; _auth = auth;
    }

    public class EmailInput
    {
        [EmailAddress, StringLength(254)] public string? Email { get; set; }
    }

    public class PasswordInput
    {
        [Required, DataType(DataType.Password)] public string Current { get; set; } = "";
        [Required, DataType(DataType.Password), MinLength(12)] public string New { get; set; } = "";
        [Required, DataType(DataType.Password), Compare(nameof(New), ErrorMessage = "The two new passwords do not match.")]
        public string Confirm { get; set; } = "";
    }

    public List<string> Roles { get; private set; } = new();
    public DateTimeOffset? CreatedAt { get; private set; }
    public string? Notice { get; private set; }
    public string? Error { get; private set; }

    [BindProperty] public EmailInput EmailForm { get; set; } = new();
    [BindProperty] public PasswordInput PasswordForm { get; set; } = new();

    public async Task OnGetAsync()
    {
        await LoadAsync();
        Notice = TempData["Notice"] as string;
    }

    public async Task<IActionResult> OnPostEmailAsync()
    {
        await LoadAsync();
        if (!FormIsValid("EmailForm")) return Page();

        await _users.UpdateEmailAsync(User.Identity!.Name!, string.IsNullOrWhiteSpace(EmailForm.Email) ? null : EmailForm.Email.Trim());
        TempData["Notice"] = "Email updated.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostPasswordAsync()
    {
        await LoadAsync();
        if (!FormIsValid("PasswordForm")) return Page();

        try
        {
            await _auth.ChangePasswordAsync(User.Identity!.Name!, PasswordForm.Current, PasswordForm.New);
        }
        catch (AuthError e)
        {
            Error = e.Message;
            return Page();
        }

        TempData["Notice"] = "Password changed.";
        return RedirectToPage();
    }

    
    
    private bool FormIsValid(string prefix) =>
        ModelState.Where(kv => kv.Key.StartsWith(prefix + ".")).All(kv => kv.Value.Errors.Count == 0);

    private async Task LoadAsync()
    {
        var me = User.Identity!.Name!;
        var user = await _users.GetAsync(me);
        Roles = await _roles.GetRolesAsync(me);
        CreatedAt = user?.CreatedAt;
        if (Request.Method == "GET") EmailForm = new EmailInput { Email = user?.Email };
    }
}
