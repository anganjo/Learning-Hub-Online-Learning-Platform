using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;

namespace WebSiteAAA.Pages.User;

[Authorize(Policy = "StudentOnly")]
public class CheckoutModel(
    ICourseRepository courses,
    IEnrollmentRepository enrollments,
    IPaymentRepository payments) : PageModel
{
    [BindProperty(SupportsGet = true)] public long CourseId { get; set; }
    [TempData] public string? Msg { get; set; }

    public CourseRecord? Course { get; private set; }
    public decimal Price { get; private set; }
    public string? Error { get; private set; }
    public bool CanRequest { get; private set; }
    public bool NeedsPayment { get; private set; }

    public async Task<IActionResult> OnGetAsync()
    {
        if (!await LoadAsync()) return NotFound();
        if (!CanRequest)
            Error = "This course is not available for another enrollment request.";
        return Page();
    }

    public async Task<IActionResult> OnPostPayAsync()
    {
        if (!await LoadAsync()) return NotFound();
        if (!CanRequest)
        {
            Error = "This course is not available for another enrollment request.";
            return Page();
        }

        var username = User.Identity!.Name!;
        if (NeedsPayment)
        {
            var paymentId = await payments.CreateAsync(username, CourseId);
            if (!await payments.MarkPaidAsync(paymentId, "simulated", Guid.NewGuid().ToString("N")))
            {
                Error = "Payment could not be completed. Please try again.";
                return Page();
            }
        }

        await enrollments.RequestAsync(username, CourseId);

        Msg = "Your enrollment request is waiting for tutor approval.";
        return RedirectToPage("/User/Dashboard");
    }

    private async Task<bool> LoadAsync()
    {
        Course = await courses.GetAsync(CourseId);
        if (Course is null) return false;
        Price = await payments.GetPriceAsync(CourseId);
        var username = User.Identity!.Name!;
        var history = (await enrollments.GetForStudentAsync(username))
            .Where(e => e.CourseId == CourseId).ToList();
        CanRequest = !history.Any(e => e.Status != EnrollmentStatus.Rejected) &&
            history.Count(e => e.Status == EnrollmentStatus.Rejected) < 2;
        var studentPayments = await payments.GetForStudentAsync(username);
        var alreadyPaid = studentPayments
            .Any(payment => payment.CourseId == CourseId && payment.Status == PaymentStatus.Paid);
        NeedsPayment = !alreadyPaid;
        return true;
    }
}
