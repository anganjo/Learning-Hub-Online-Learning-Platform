using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;

namespace WebSiteAAA.Pages.Account;

public class RegisterModel : PageModel
{
    private readonly AuthService _auth;
    private readonly CaptchaService _captcha;

    public RegisterModel(AuthService auth, CaptchaService captcha)
    {
        _auth = auth;
        _captcha = captcha;
    }

    [BindProperty] public string Username { get; set; } = "";
    [BindProperty] public string Password { get; set; } = "";
    [BindProperty] public string? Email { get; set; }
    [BindProperty] public string CaptchaId { get; set; } = "";
    [BindProperty] public string CaptchaAnswer { get; set; } = "";

    public string CaptchaQuestion { get; private set; } = "";
    public string? Error { get; private set; }

    public void OnGet() => IssueNewChallenge();

    public async Task<IActionResult> OnPostAsync()
    {
        if (!_captcha.Validate(CaptchaId, CaptchaAnswer))
        {
            Error = "Incorrect answer to the verification question.";
            IssueNewChallenge();
            return Page();
        }

        try
        {
            await _auth.RegisterAsync(Username, Password, Email);
        }
        catch (AuthError e)
        {
            Error = e.Message;
            IssueNewChallenge();
            return Page();
        }

        var token = await _auth.LoginAsync(Username, Password);
        var roles = await _auth.GetRolesAsync(Username);
        await SiteAuth.SignInAsync(HttpContext, Username, token, roles);

        return RedirectToPage("/User/Dashboard");
    }

    private void IssueNewChallenge()
    {
        var challenge = _captcha.Generate();
        CaptchaId = challenge.Id;
        CaptchaQuestion = challenge.Question;
    }
}
