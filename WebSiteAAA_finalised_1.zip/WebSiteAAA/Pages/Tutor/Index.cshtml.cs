using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.Tutor;




[Authorize(Roles = "tutor")]
public class IndexModel : PageModel
{
    private readonly AuthorizationService _authz;
    private readonly IEnrollmentRepository _enrollments;
    private readonly ICourseRepository _courses;
    private readonly IPaymentRepository _payments;
    private readonly IAssignmentSubmissionRepository _assignments;
    private readonly IExamResultRepository _examResults;
    private readonly ITutorCourseRepository _tutorCourses;

    public IndexModel(
        AuthorizationService authz,
        IEnrollmentRepository enrollments,
        ICourseRepository courses,
        IPaymentRepository payments,
        IAssignmentSubmissionRepository assignments,
        IExamResultRepository examResults,
        ITutorCourseRepository tutorCourses)
    {
        _tutorCourses = tutorCourses;
        _authz = authz;
        _enrollments = enrollments;
        _courses = courses;
        _payments = payments;
        _assignments = assignments;
        _examResults = examResults;
    }

    public List<(EnrollmentRecord Enrollment, string CourseName)> Pending { get; private set; } = new();
    public List<(Submission Submission, string CourseName, string TaskName)> Assignments { get; private set; } = new();
    public List<(ExamAttemptRecord Result, string CourseName)> LatestResults { get; private set; } = new();
    public List<(string CourseName, int PendingCount, int AssignmentCount)> CourseActivity { get; private set; } = new();
    public int StudentCount { get; private set; }
    public double AverageExamScore { get; private set; }
    public bool CanReviewAssignments { get; private set; }
    public string? Error { get; private set; }

    public async Task OnGetAsync()
    {
        var token = User.GetAaaToken();
        if (token is null) { Error = "Session is invalid"; return; }

        if (!await _authz.RequirePermissionAsync(token, "enrollment.approve"))
        {
            Error = "Insufficient permissions";
            return;
        }

        var mine = await _tutorCourses.GetCourseIdsAsync(User.Identity!.Name!);
        StudentCount = (await _enrollments.GetForCoursesAsync(mine))
            .Where(enrollment => enrollment.Status == EnrollmentStatus.Approved)
            .Select(enrollment => enrollment.StudentUsername)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Count();
        var courses = (await _courses.GetAllAsync()).ToDictionary(c => c.Id, c => c.Name);
        foreach (var enrollment in await _enrollments.GetPendingAsync())
        {
            if (mine.Contains(enrollment.CourseId) && await HasPaidPaymentAsync(enrollment.StudentUsername, enrollment.CourseId))
                Pending.Add((enrollment, courses.GetValueOrDefault(enrollment.CourseId, $"Course #{enrollment.CourseId}")));
        }

        CanReviewAssignments = await _authz.RequirePermissionAsync(token, "results.read");
        var submissions = CanReviewAssignments
            ? (await _assignments.GetAllAsync()).Where(submission => submission.Score is null && mine.Contains(submission.CourseId))
                .OrderBy(submission => submission.SubmittedAt).ToList()
            : new List<Submission>();
        Assignments = submissions.Select(submission => (
            submission,
            courses.GetValueOrDefault(submission.CourseId, $"Course #{submission.CourseId}"),
            submission.TaskName)).ToList();

        if (CanReviewAssignments)
        {
            var results = (await _examResults.GetLatestResultsAsync()).Where(r => mine.Contains(r.CourseId)).ToList();
            LatestResults = results.OrderByDescending(result => result.SubmittedAt).Take(3)
                .Select(result => (result, courses.GetValueOrDefault(result.CourseId, $"Course #{result.CourseId}")))
                .ToList();
            AverageExamScore = results.Count == 0 ? 0 : results.Average(result => result.Score);

        }

        var courseIds = Pending.Select(item => item.Enrollment.CourseId)
            .Concat(submissions.Select(submission => submission.CourseId))
            .Distinct()
            .OrderBy(courseId => courses.GetValueOrDefault(courseId, $"Course #{courseId}"))
            .ToList();
        CourseActivity = courseIds.Select(courseId => (
            courses.GetValueOrDefault(courseId, $"Course #{courseId}"),
            Pending.Count(item => item.Enrollment.CourseId == courseId),
            submissions.Count(submission => submission.CourseId == courseId)))
            .ToList();
    }

    public async Task<IActionResult> OnPostDecideAsync(long enrollmentId, bool approve)
    {
        var token = User.GetAaaToken();
        if (token is not null && await _authz.RequirePermissionAsync(token, "enrollment.approve"))
        {
            var mine = await _tutorCourses.GetCourseIdsAsync(User.Identity!.Name!);
            var pending = (await _enrollments.GetPendingAsync())
                .FirstOrDefault(e => e.Id == enrollmentId && mine.Contains(e.CourseId));
            if (pending is not null && await HasPaidPaymentAsync(pending.StudentUsername, pending.CourseId) &&
                await _enrollments.DecideAsync(enrollmentId, approve, User.Identity!.Name!) && !approve)
            {
                var rejectedAttempts = (await _enrollments.GetForStudentAsync(pending.StudentUsername))
                    .Count(e => e.CourseId == pending.CourseId && e.Status == EnrollmentStatus.Rejected);
                if (rejectedAttempts >= 2)
                {
                    var paidPayments = (await _payments.GetForStudentAsync(pending.StudentUsername))
                        .Where(payment => payment.CourseId == pending.CourseId && payment.Status == PaymentStatus.Paid);
                    foreach (var payment in paidPayments)
                    {
                        if (!await _payments.RefundAsync(payment.Id))
                            throw new InvalidOperationException("Payment could not be refunded after the second enrollment rejection.");
                    }
                }
            }
        }

        return RedirectToPage();
    }

    private async Task<bool> HasPaidPaymentAsync(string username, long courseId) =>
        (await _payments.GetForStudentAsync(username))
        .Any(payment => payment.CourseId == courseId && payment.Status == PaymentStatus.Paid);
}
