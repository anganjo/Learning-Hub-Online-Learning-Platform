using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;

namespace WebSiteAAA.Pages.Tutor;


[Authorize(Roles = "tutor")]
public class ResultsModel(AuthorizationService authz, ICourseRepository courses, IExamResultRepository examResults,
    WebSiteAAA.Services.ITutorCourseRepository tutorCourses) : PageModel
{
    public List<ResultRow> Rows { get; private set; } = new();
    public string? Error { get; private set; }

    public record ResultRow(string Student, string Course, int AttemptNumber, int Score, bool Passed, DateTimeOffset SubmittedAt);

    public async Task OnGetAsync()
    {
        var token = User.GetAaaToken();
        if (token is null || !await authz.RequirePermissionAsync(token, "results.read")) { Error = "Insufficient permissions"; return; }
        var names = (await courses.GetAllAsync()).ToDictionary(c => c.Id, c => c.Name);
        var mine = await tutorCourses.GetCourseIdsAsync(User.Identity!.Name!);
        Rows = (await examResults.GetLatestResultsAsync())
            .Where(result => mine.Contains(result.CourseId))
            .Select(result => new ResultRow(
                result.StudentUsername,
                names.GetValueOrDefault(result.CourseId, "Course #" + result.CourseId),
                result.AttemptNumber,
                result.Score,
                result.Passed,
                result.SubmittedAt))
            .OrderBy(row => row.Course).ThenBy(row => row.Student).ToList();
    }
}
