using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.Tutor;




[Authorize(Roles = "tutor")]
public class GradingModel(
    AuthorizationService authz,
    ICourseRepository courses,
    IAssignmentSubmissionRepository assignments,
    ICourseContentRepository content,
    ILessonProgressRepository lessonProgress,
    IExamResultRepository examResults,
    ITutorCourseRepository tutorCourses,
    IWebHostEnvironment env) : PageModel
{
    public record Row(Submission S, string Course, string Task);
    public List<Row> Rows { get; private set; } = new();
    public Row? Selected { get; private set; }
    public List<Row> Ungraded { get; private set; } = new();
    public List<Row> Graded { get; private set; } = new();
    public int CompletedLessons { get; private set; }
    public int LessonCount { get; private set; }
    public int? BestExamScore { get; private set; }
    public int ProgressPercent => LessonCount == 0 ? 0 : CompletedLessons * 100 / LessonCount;
    [BindProperty(SupportsGet = true)] public int? SelectedId { get; set; }
    [BindProperty(SupportsGet = true)] public string Tab { get; set; } = "todo";
    public string? Error { get; private set; }
    [TempData] public string? Msg { get; set; }

    private async Task<bool> OwnsAsync(Submission? submission) =>
        submission is not null
        && (await tutorCourses.GetCourseIdsAsync(User.Identity!.Name!)).Contains(submission.CourseId);

    private async Task<bool> GateAsync()
    {
        var token = User.GetAaaToken();
        return token is not null && await authz.RequirePermissionAsync(token, "results.read");
    }

    public async Task OnGetAsync()
    {
        if (!await GateAsync()) { Error = "Insufficient permissions"; return; }
        await LoadAsync();
    }

    private async Task LoadAsync()
    {
        var names = (await courses.GetAllAsync()).ToDictionary(c => c.Id, c => c.Name);
        var mine = await tutorCourses.GetCourseIdsAsync(User.Identity!.Name!);
        Rows = (await assignments.GetAllAsync())
            .Where(s => mine.Contains(s.CourseId))
            .Select(s => new Row(s, names.GetValueOrDefault(s.CourseId, "Course #" + s.CourseId), s.TaskName))
            .OrderBy(row => row.S.SubmittedAt)
            .ToList();
        Ungraded = Rows.Where(row => row.S.Score is null).ToList();
        Graded = Rows.Where(row => row.S.Score is not null).OrderByDescending(row => row.S.SubmittedAt).ToList();
        Selected = Rows.FirstOrDefault(row => row.S.Id == SelectedId)
            ?? (Tab == "graded" ? Graded.FirstOrDefault() : Ungraded.FirstOrDefault())
            ?? Graded.FirstOrDefault();
        if (Selected is null) return;

        var lessons = await content.GetLessonsAsync(Selected.S.CourseId);
        var completed = await lessonProgress.GetCompletedKeysAsync(Selected.S.Student, Selected.S.CourseId);
        LessonCount = lessons.Count;
        CompletedLessons = lessons.Count(lesson => completed.Contains(lesson.ProgressKey));
        BestExamScore = (await examResults.GetLatestResultsAsync())
            .Where(result => result.StudentUsername.Equals(Selected.S.Student, StringComparison.OrdinalIgnoreCase)
                && result.CourseId == Selected.S.CourseId)
            .Select(result => (int?)result.Score)
            .FirstOrDefault();
    }

    public async Task<IActionResult> OnPostGradeAsync(int id, int score, string? feedback)
    {
        if (!await GateAsync()) return RedirectToPage();
        if (!await OwnsAsync(await assignments.GetAsync(id))) return Forbid();
        if (score is < 0 or > 100) Msg = "The score must be between 0 and 100.";
        else if (await assignments.GradeAsync(id, score, (feedback ?? "").Trim())) Msg = "Grade saved.";
        else Msg = "The submission could not be found.";
        return RedirectToPage(new { SelectedId = id, Tab = "graded" });
    }

    public async Task<IActionResult> OnPostGradeNextAsync(int id, int score, string? feedback)
    {
        if (!await GateAsync()) return RedirectToPage();
        if (!await OwnsAsync(await assignments.GetAsync(id))) return Forbid();
        if (score is < 0 or > 100)
        {
            Msg = "The score must be between 0 and 100.";
            return RedirectToPage(new { SelectedId = id, Tab = "todo" });
        }

        if (!await assignments.GradeAsync(id, score, (feedback ?? "").Trim()))
        {
            Msg = "The submission could not be found.";
            return RedirectToPage();
        }

        var mine = await tutorCourses.GetCourseIdsAsync(User.Identity!.Name!);
        var next = (await assignments.GetAllAsync())
            .Where(submission => submission.Score is null && submission.Id != id && mine.Contains(submission.CourseId))
            .OrderBy(submission => submission.SubmittedAt)
            .FirstOrDefault();
        Msg = "Grade saved.";
        return RedirectToPage(new { SelectedId = next?.Id, Tab = next is null ? "graded" : "todo" });
    }

    public async Task<IActionResult> OnGetDownloadAsync(int id)
    {
        if (!await GateAsync()) return Forbid();
        var s = await assignments.GetAsync(id);
        if (s is null) return NotFound();
        if (!await OwnsAsync(s)) return Forbid();
        var path = Path.Combine(env.ContentRootPath, "App_Data", "assignments", s.StoredName);
        if (!System.IO.File.Exists(path)) return NotFound();
        return PhysicalFile(path, "application/octet-stream", s.FileName);
    }
}
