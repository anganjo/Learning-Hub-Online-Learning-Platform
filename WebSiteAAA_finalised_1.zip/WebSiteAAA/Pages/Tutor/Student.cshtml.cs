using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebSiteAAA.Core;
using WebSiteAAA.Services;

namespace WebSiteAAA.Pages.Tutor;

[Authorize(Roles = "tutor")]
public class StudentModel : PageModel
{
    private readonly AuthorizationService _authz;
    private readonly ICommentRepository _comments;
    private readonly IUserRepository _users;
    private readonly IEnrollmentRepository _enrollments;
    private readonly ICourseRepository _courses;
    private readonly ICertificateRepository _certificates;
    private readonly ITutorCourseRepository _tutorCourses;

    public StudentModel(
        AuthorizationService authz,
        ICommentRepository comments, IUserRepository users,
        IEnrollmentRepository enrollments, ICourseRepository courses,
        ICertificateRepository certificates,
        ITutorCourseRepository tutorCourses)
    {
        _tutorCourses = tutorCourses;
        _authz = authz;
        _comments = comments;
        _users = users;
        _enrollments = enrollments;
        _courses = courses;
        _certificates = certificates;
    }

    public record CourseItem(string Name, EnrollmentStatus Status, DateTimeOffset RequestedAt);
    public record CertificateItem(string CourseName, CertificateRecord Certificate);

    [BindProperty(SupportsGet = true)] public string? Username { get; set; }
    [BindProperty] public string CommentText { get; set; } = "";

    public bool StudentExists { get; private set; }
    public List<CommentRecord> Comments { get; private set; } = new();
    public List<CourseItem> StudentCourses { get; private set; } = new();
    public List<CertificateItem> Certificates { get; private set; } = new();
    public bool CanReadAchievements { get; private set; }
    public bool CanReadEnrollments { get; private set; }
    public bool CanWriteComments { get; private set; }
    public string? Error { get; private set; }

    public async Task OnGetAsync()
    {
        var token = User.GetAaaToken();
        if (token is null) { Error = "Session is invalid"; return; }

        CanReadAchievements = await _authz.RequirePermissionAsync(token, "achievements.read");
        CanReadEnrollments = await _authz.RequirePermissionAsync(token, "enrollment.approve");
        CanWriteComments = await _authz.RequirePermissionAsync(token, "comments.write");

        if (!CanReadAchievements && !CanReadEnrollments && !CanWriteComments)
        {
            Error = "Insufficient permissions";
            return;
        }

        if (string.IsNullOrWhiteSpace(Username)) return;

        StudentExists = await _users.GetAsync(Username) is not null;
        if (!StudentExists) return;

        var mine = await _tutorCourses.GetCourseIdsAsync(User.Identity!.Name!);
        if (!await InScopeAsync(Username, mine))
        {
            StudentExists = false;
            Error = "This student is not enrolled in any of your courses.";
            return;
        }

        Comments = await _comments.GetForStudentAsync(Username);

        var courseNames = (await _courses.GetAllAsync()).ToDictionary(c => c.Id, c => c.Name);
        if (CanReadEnrollments)
        {
            StudentCourses = (await _enrollments.GetForStudentAsync(Username))
                .Where(enrollment => mine.Contains(enrollment.CourseId))
                .Select(enrollment => new CourseItem(
                    courseNames.GetValueOrDefault(enrollment.CourseId, $"Course #{enrollment.CourseId}"),
                    enrollment.Status,
                    enrollment.RequestedAt))
                .ToList();
        }

        if (CanReadAchievements)
        {
            Certificates = (await _certificates.GetForStudentAsync(Username))
                .Where(certificate => mine.Contains(certificate.CourseId))
                .Select(certificate => new CertificateItem(
                    courseNames.GetValueOrDefault(certificate.CourseId, $"Course #{certificate.CourseId}"),
                    certificate))
                .ToList();
        }
    }

    private async Task<bool> InScopeAsync(string student, HashSet<long> mine) =>
        (await _enrollments.GetForStudentAsync(student)).Any(enrollment => mine.Contains(enrollment.CourseId));

    public async Task<IActionResult> OnPostCommentAsync()
    {
        var token = User.GetAaaToken();
        if (token is not null && !string.IsNullOrWhiteSpace(Username) && !string.IsNullOrWhiteSpace(CommentText)
            && await _authz.RequirePermissionAsync(token, "comments.write")
            && await InScopeAsync(Username!, await _tutorCourses.GetCourseIdsAsync(User.Identity!.Name!)))
        {
            await _comments.AddAsync(Username!, User.Identity!.Name!, CommentText.Trim());
        }

        return RedirectToPage(new { Username });
    }
}
