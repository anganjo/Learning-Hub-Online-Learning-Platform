using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace WebSiteAAA;










public static class SiteAuth
{
    public const string TokenClaimType = "aaa_token";

    public static async Task SignInAsync(HttpContext httpContext, string username, string token, IEnumerable<string> roles)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.Name, username),
            new(TokenClaimType, token),
        };

        claims.AddRange(roles.Select(role => new Claim(ClaimTypes.Role, role)));

        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await httpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
    }

    public static string? GetAaaToken(this ClaimsPrincipal user) => user.FindFirstValue(TokenClaimType);
}
