using Microsoft.AspNetCore.Authentication.Cookies;
using WebSiteAAA.Core;

using WebSiteAAA.Providers.Argon2;
using WebSiteAAA.Providers.Postgres;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddHttpContextAccessor();

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/";
        options.AccessDeniedPath = "/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(25);
        options.SlidingExpiration = true;
        options.Cookie.Name = "websiteaaa_session";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest; 
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("StudentOnly", policy => policy
        .RequireAuthenticatedUser()
        .RequireAssertion(context =>
            context.User.IsInRole("user") &&
            !context.User.IsInRole("tutor") &&
            !context.User.IsInRole("admin")));
});

var authSettings = new AuthSettings(
    MaxFailedAttempts: builder.Configuration.GetValue("Auth:MaxFailedAttempts", 5),
    LockoutMinutes: builder.Configuration.GetValue("Auth:LockoutMinutes", 5),
    SessionTtlMinutes: builder.Configuration.GetValue("Auth:SessionTtlMinutes", 30),
    MinPasswordLength: builder.Configuration.GetValue("Auth:MinPasswordLength", 12));
builder.Services.AddSingleton(authSettings);

builder.Services.AddSingleton(new CaptchaService());
builder.Services.AddSingleton(new RateLimiter(windowSeconds: 60, maxRequests: 30));

var connectionString = builder.Configuration.GetConnectionString("Postgres");
if (string.IsNullOrWhiteSpace(connectionString))
    throw new InvalidOperationException(
        "PostgreSQL connection is missing. Set ConnectionStrings__Postgres in the process environment.");

await Db.ApplySchemaAsync(connectionString);
var dataSource = Db.CreateDataSource(connectionString);
builder.Services.AddSingleton(dataSource);

builder.Services.AddSingleton<IUserRepository, NpgsqlUserRepository>();
builder.Services.AddSingleton<ISessionRepository, NpgsqlSessionRepository>();
builder.Services.AddSingleton<IRoleRepository, NpgsqlRoleRepository>();
builder.Services.AddSingleton<IAuditSink, NpgsqlAuditSink>();
builder.Services.AddSingleton<IPasswordHasher, Argon2PasswordHasher>();
builder.Services.AddSingleton<ICourseRepository, NpgsqlCourseRepository>();
builder.Services.AddSingleton<IEnrollmentRepository, NpgsqlEnrollmentRepository>();
builder.Services.AddSingleton<IAchievementRepository, NpgsqlAchievementRepository>();
builder.Services.AddSingleton<ICommentRepository, NpgsqlCommentRepository>();
builder.Services.AddSingleton<ICertificateRepository, NpgsqlCertificateRepository>();
builder.Services.AddSingleton<ICourseFeedbackRepository, NpgsqlCourseFeedbackRepository>();
builder.Services.AddSingleton<ILessonProgressRepository, NpgsqlLessonProgressRepository>();
builder.Services.AddSingleton<IExamResultRepository, NpgsqlExamResultRepository>();
builder.Services.AddSingleton<IExamAttemptRepository, NpgsqlExamAttemptRepository>();
builder.Services.AddSingleton<IPaymentRepository, NpgsqlPaymentRepository>();
builder.Services.AddSingleton<WebSiteAAA.Services.IAssignmentSubmissionRepository, NpgsqlAssignmentSubmissionRepository>();
builder.Services.AddSingleton<WebSiteAAA.Services.ICourseResourceRepository, NpgsqlCourseResourceRepository>();
builder.Services.AddSingleton<WebSiteAAA.Services.ICourseContentRepository, NpgsqlCourseContentRepository>();
builder.Services.AddSingleton<WebSiteAAA.Services.IQuizScoreRepository, NpgsqlQuizScoreRepository>();
builder.Services.AddSingleton<WebSiteAAA.Services.ITutorCourseRepository, NpgsqlTutorCourseRepository>();

builder.Services.AddSingleton<AuthService>();
builder.Services.AddSingleton<AuthorizationService>();
builder.Services.AddSingleton<ContentAccess>();
builder.Services.AddSingleton<WebSiteAAA.Services.CertificateAwarder>();
builder.Services.AddSingleton<WebSiteAAA.Services.LessonProgressService>();

var app = builder.Build();

var bootstrapUsername = app.Configuration["Demo:BootstrapAdminUsername"];
var bootstrapPassword = app.Configuration["Demo:BootstrapAdminPassword"];

using (var contentScope = app.Services.CreateScope())
{
    await WebSiteAAA.Services.CourseContentSeeder.ApplyAsync(
        contentScope.ServiceProvider.GetRequiredService<ICourseRepository>(),
        app.Services.GetRequiredService<WebSiteAAA.Services.ICourseContentRepository>(),
        app.Services.GetRequiredService<WebSiteAAA.Services.ICourseResourceRepository>());
}

if (!string.IsNullOrEmpty(bootstrapUsername) && !string.IsNullOrEmpty(bootstrapPassword))
{
    using var scope = app.Services.CreateScope();
    var auth = scope.ServiceProvider.GetRequiredService<AuthService>();
    var roles = scope.ServiceProvider.GetRequiredService<IRoleRepository>();

    try
    {
        await auth.RegisterAsync(bootstrapUsername, bootstrapPassword, null);
        await roles.AssignRoleAsync(bootstrapUsername, "admin");
        app.Logger.LogInformation("Bootstrap admin account '{Username}' created.", bootstrapUsername);
    }
    catch (AuthError)
    {
        
    }
}

if (args.Contains("--seed-sample-accounts", StringComparer.Ordinal))
{
    var defaultCredentialsFile = Path.Combine("outputs", $"course-users-credentials-{DateTime.UtcNow:yyyyMMdd-HHmmss}.csv");
    var credentialsFile = app.Configuration["SampleAccounts:CredentialsFile"] ?? defaultCredentialsFile;
    using var scope = app.Services.CreateScope();
    var seeded = await CourseSampleAccountsSeeder.ApplyAsync(scope.ServiceProvider, credentialsFile);
    Console.WriteLine($"Seed complete: {seeded.students} student slots, {seeded.tutors} tutor slots; " +
                      $"{seeded.enrollments} new enrollments and {seeded.assignments} new tutor assignments.");
    Console.WriteLine($"New account credentials saved to: {Path.GetFullPath(credentialsFile)}");
    return;
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapRazorPages();

app.Run();
