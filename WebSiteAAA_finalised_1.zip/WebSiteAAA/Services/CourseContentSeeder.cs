namespace WebSiteAAA.Services;



public static class CourseContentSeeder
{
    public static async Task ApplyAsync(WebSiteAAA.Core.ICourseRepository courses,
        ICourseContentRepository content, ICourseResourceRepository resources)
    {
        var all = await courses.GetAllAsync();
        foreach (var seed in CourseContentSeed.All)
        {
            var course = all.FirstOrDefault(c => c.Name.Equals(seed.Name, StringComparison.OrdinalIgnoreCase));
            if (course is null) continue;

            await content.EnsureSeededAsync(course.Id, seed);
            await resources.EnsureSeededAsync(course.Id,
                seed.Resources.Select(resource => new Resource
                {
                    CourseId = course.Id,
                    Title = resource.Title,
                    Category = resource.Category,
                    Url = resource.Url,
                    Description = resource.Description,
                    Instructor = resource.Instructor
                }).ToList());
        }

        foreach (var course in all.Where(course =>
                     !CourseContentSeed.All.Any(seed =>
                         seed.Name.Equals(course.Name, StringComparison.OrdinalIgnoreCase))))
        {
            await content.EnsureSeededAsync(course.Id, new SeedCourse(
                course.Name, "Final exam", 30, 50,
                Array.Empty<SeedLesson>(),
                Array.Empty<SeedResource>(),
                Array.Empty<SeedQuestion>()));
        }
    }
}
