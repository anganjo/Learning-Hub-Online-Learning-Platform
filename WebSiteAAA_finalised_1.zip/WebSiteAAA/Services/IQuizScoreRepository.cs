namespace WebSiteAAA.Services;

/// <summary>Latest practice-quiz score per student and course, stored in PostgreSQL.</summary>
public interface IQuizScoreRepository
{
    Task<int?> GetScoreAsync(string studentUsername, long courseId);
    Task RecordScoreAsync(string studentUsername, long courseId, int score);
}
