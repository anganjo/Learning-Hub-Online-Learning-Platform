namespace WebSiteAAA.Services;

public interface ICourseResourceRepository
{
    Task EnsureSeededAsync(long courseId, IReadOnlyCollection<Resource> resources);
    Task<List<Resource>> GetForCourseAsync(long courseId, string? category = null, string? search = null);
    Task<Resource?> GetAsync(int id);
    Task<int> CreateAsync(Resource resource);
    Task<bool> UpdateAsync(Resource resource);
    Task<bool> DeleteAsync(long courseId, int id);
}
