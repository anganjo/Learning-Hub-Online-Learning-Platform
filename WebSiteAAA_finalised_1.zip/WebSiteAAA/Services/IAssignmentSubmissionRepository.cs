namespace WebSiteAAA.Services;

public interface IAssignmentSubmissionRepository
{
    Task<int> SubmitAsync(long courseId, int resourceId, string taskName, string student, string fileName, string storedName);
    Task<List<Submission>> GetForStudentAsync(string student, long courseId);
    Task<List<Submission>> GetAllAsync();
    Task<Submission?> GetAsync(int id);
    Task<bool> GradeAsync(int id, int score, string feedback);
}
