namespace WebSiteAAA.Services;




public static class CourseArt
{
    private static readonly (string Key, string File)[] Map =
    {
        ("math", "math"), ("program", "programming"), ("crypto", "cryptography"), ("database", "database"),
        ("machine learning", "ml"), ("deep learning", "deeplearning"), ("natural language", "nlp"), ("nlp", "nlp"),
        ("reinforcement", "rl"), ("computer vision", "vision"), ("hardware", "hardware")
    };

    public static string For(string? name, long id)
    {
        var n = (name ?? "").ToLowerInvariant();
        foreach (var (key, file) in Map)
            if (n.Contains(key)) return "/images/courses/" + file + ".svg";
        return "/images/courses/generic" + (id % 4) + ".svg";
    }
}
