namespace WebSiteAAA.Services;

/// <summary>Which courses a tutor is assigned to (table course_tutors). Tutors see only these courses.</summary>
public interface ITutorCourseRepository
{
    Task<HashSet<long>> GetCourseIdsAsync(string tutorUsername);
    Task<List<string>> GetTutorsAsync(long courseId);
    Task<bool> AssignAsync(long courseId, string tutorUsername);
    Task<bool> RemoveAsync(long courseId, string tutorUsername);
}
