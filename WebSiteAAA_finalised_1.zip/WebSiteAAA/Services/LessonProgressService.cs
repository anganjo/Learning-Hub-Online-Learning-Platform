using WebSiteAAA.Core;

namespace WebSiteAAA.Services;

public class LessonProgressService(ILessonProgressRepository progress, ICourseContentRepository content)
{
    public async Task<HashSet<int>> GetCompletedIdsAsync(string studentUsername, long courseId)
    {
        var modules = await content.GetLessonsAsync(courseId);
        var keys = await progress.GetCompletedKeysAsync(studentUsername, courseId);
        return modules.Where(m => keys.Contains(m.ProgressKey)).Select(m => m.Id).ToHashSet();
    }

    public async Task<int> GetPercentCompleteAsync(string studentUsername, long courseId)
    {
        var modules = await content.GetLessonsAsync(courseId);
        if (modules.Count == 0) return 0;
        var keys = await progress.GetCompletedKeysAsync(studentUsername, courseId);
        var done = modules.Count(m => keys.Contains(m.ProgressKey));
        return done * 100 / modules.Count;
    }

    public Task MarkCompleteAsync(string studentUsername, SModule module) =>
        progress.MarkCompleteAsync(studentUsername, module.CourseId, module.ProgressKey);
}
