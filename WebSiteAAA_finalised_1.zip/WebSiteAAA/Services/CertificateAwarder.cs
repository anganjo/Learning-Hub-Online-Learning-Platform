using WebSiteAAA.Core;

namespace WebSiteAAA.Services;

public class CertificateAwarder(
    ICertificateRepository certificates,
    ContentAccess access,
    LessonProgressService progress,
    IExamResultRepository examResults)
{
    public async Task<CertificateRecord?> TryAwardAsync(string studentUsername, long courseId)
    {
        if (await progress.GetPercentCompleteAsync(studentUsername, courseId) != 100 ||
            !await access.CanEarnCertificateAsync(studentUsername, courseId))
            return null;

        var outcome = await examResults.GetOutcomeAsync(studentUsername, courseId);
        if (!outcome.Passed || outcome.BestScore is not int score) return null;
        return await certificates.IssueAsync(studentUsername, courseId, score);
    }
}
