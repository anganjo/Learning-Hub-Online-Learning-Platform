namespace WebSiteAAA.Services;

public class Resource
{
    public int Id { get; set; }
    public long CourseId { get; set; }
    public string Title { get; set; } = "";
    public string Category { get; set; } = "Lesson";   
    public string Url { get; set; } = "";
    public string Description { get; set; } = "";
    public string Instructor { get; set; } = "";
}

public class Submission
{
    public int Id { get; set; }
    public long CourseId { get; set; }
    public int ResourceId { get; set; }
    public string TaskName { get; set; } = "Assignment";
    public string Student { get; set; } = "";
    public string FileName { get; set; } = "";     
    public string StoredName { get; set; } = "";   
    public DateTime SubmittedAt { get; set; } = DateTime.Now;
    public int? Score { get; set; }
    public string Feedback { get; set; } = "";
}

public class ExamSettings
{
    public string Title { get; set; } = "Final exam";
    public int DurationMinutes { get; set; } = 30;
    public int PassMark { get; set; } = 50;
}

public class ExamResult
{
    public string Student { get; set; } = "";
    public long CourseId { get; set; }
    public int Score { get; set; }
    public bool Passed { get; set; }
    public DateTime TakenAt { get; set; } = DateTime.Now;
}

public record SModule(int Id, long CourseId, string Title, string Kind, string Body, string ProgressKey);
public record SQuestion(int Id, long CourseId, string Text, string[] Options, int Answer);

public static class ResourceCategories
{
    public static readonly string[] All = { "Lesson", "Lecture Note", "Video", "Tutorial" };
}
