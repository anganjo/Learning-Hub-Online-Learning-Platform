namespace WebSiteAAA.Services;

public interface ICourseContentRepository
{
    Task EnsureSeededAsync(long courseId, SeedCourse seed);
    Task<List<SModule>> GetLessonsAsync(long courseId);
    Task<SModule?> GetLessonAsync(long courseId, int lessonId);
    Task<int> AddLessonAsync(long courseId, string title, string kind, string body);
    Task<bool> UpdateLessonAsync(long courseId, int lessonId, string title, string kind, string body);
    Task<bool> DeleteLessonAsync(long courseId, int lessonId);
    Task<List<SQuestion>> GetQuestionsAsync(long courseId);
    Task<SQuestion?> GetQuestionAsync(long courseId, int questionId);
    Task AddQuestionAsync(long courseId, string text, string[] options, int answer);
    Task<bool> UpdateQuestionAsync(long courseId, int questionId, string text, string[] options, int answer);
    Task<bool> DeleteQuestionAsync(long courseId, int questionId);
    Task<ExamSettings> GetExamSettingsAsync(long courseId);
    Task SaveExamSettingsAsync(long courseId, string title, int minutes, int passMark);
}
