-- Apply to websiteaaa_import_test after a backup. Safe to repeat.
BEGIN;
INSERT INTO courses (name) VALUES
    ('Mathematics 101'),
    ('Intro to Programming'),
    ('Cryptography'),
    ('Database Management'),
    ('Machine Learning'),
    ('Deep Learning'),
    ('Natural Language Processing'),
    ('Reinforcement Learning'),
    ('Computer Vision'),
    ('System Hardware')
ON CONFLICT DO NOTHING;
UPDATE courses SET price_amount = 25.00, currency = 'USD'
WHERE name IN (
    'Mathematics 101', 'Intro to Programming', 'Cryptography',
    'Database Management', 'Machine Learning', 'Deep Learning',
    'Natural Language Processing', 'Reinforcement Learning',
    'Computer Vision', 'System Hardware'
);
COMMIT;
SELECT count(*) AS courses, min(price_amount) AS min_price,
       max(price_amount) AS max_price
FROM courses;
