



BEGIN;

INSERT INTO courses (name, slug, description, is_published, price_amount, currency) VALUES
 ('Automata and Formal Grammars', 'automata-and-grammars',
  'Introduction to finite automata, regular languages and context-free grammars.', TRUE, 50.00, 'USD'),
 ('Computability Theory', 'advanced-computability', 'Draft course for future lessons.', FALSE, 50.00, 'USD')
ON CONFLICT (name) DO NOTHING;

INSERT INTO modules (course_id, title, position)
SELECT c.id, m.title, m.position FROM courses c
CROSS JOIN (VALUES ('Finite Automata', 1), ('Context-Free Grammars', 2)) AS m(title, position)
WHERE c.slug = 'automata-and-grammars'
ON CONFLICT DO NOTHING;

INSERT INTO materials (module_id, kind, title, body, position)
SELECT m.id, 'text', i.title, i.body, i.pos
FROM (VALUES
 (1, 1, 'What is a DFA?', 'A deterministic finite automaton has a finite set of states, an input alphabet, a transition function, a start state and accepting states.'),
 (1, 2, 'DFA acceptance', 'A string is accepted if processing every symbol ends in an accepting state.'),
 (2, 1, 'What is a CFG?', 'A context-free grammar consists of nonterminals, terminals, production rules and a start symbol.'),
 (2, 2, 'Derivations', 'A derivation applies production rules to generate a string of terminals from the start symbol.')
) AS i(mpos, pos, title, body)
JOIN courses c ON c.slug = 'automata-and-grammars'
JOIN modules m ON m.course_id = c.id AND m.position = i.mpos
ON CONFLICT DO NOTHING;

INSERT INTO quizzes (module_id, title, pass_score, max_attempts)
SELECT m.id, q.title, 70, 3
FROM (VALUES (1, 'Automata Basics Quiz'), (2, 'Grammar Basics Quiz')) AS q(mpos, title)
JOIN courses c ON c.slug = 'automata-and-grammars'
JOIN modules m ON m.course_id = c.id AND m.position = q.mpos
ON CONFLICT DO NOTHING;

INSERT INTO questions (quiz_id, text, kind, position)
SELECT q.id, i.text, i.kind, i.pos
FROM (VALUES
 (1, 1, 'Can a DFA have multiple possible transitions for the same state and input symbol?', 'single'),
 (1, 2, 'A DFA accepts a string when processing it ends in an accepting state.', 'true_false'),
 (2, 1, 'Which component determines where a CFG derivation starts?', 'single'),
 (2, 2, 'A context-free grammar uses production rules.', 'true_false')
) AS i(mpos, pos, text, kind)
JOIN courses c ON c.slug = 'automata-and-grammars'
JOIN modules m ON m.course_id = c.id AND m.position = i.mpos
JOIN quizzes q ON q.module_id = m.id
ON CONFLICT DO NOTHING;

INSERT INTO answer_options (question_id, text, is_correct, position)
SELECT qu.id, i.text, i.is_correct, i.opos
FROM (VALUES
 (1, 1, 1, 'Yes', FALSE), (1, 1, 2, 'No', TRUE),
 (1, 2, 1, 'True', TRUE), (1, 2, 2, 'False', FALSE),
 (2, 1, 1, 'Start symbol', TRUE), (2, 1, 2, 'Input alphabet', FALSE),
 (2, 2, 1, 'True', TRUE), (2, 2, 2, 'False', FALSE)
) AS i(mpos, qpos, opos, text, is_correct)
JOIN courses c ON c.slug = 'automata-and-grammars'
JOIN modules m ON m.course_id = c.id AND m.position = i.mpos
JOIN quizzes q ON q.module_id = m.id
JOIN questions qu ON qu.quiz_id = q.id AND qu.position = i.qpos
ON CONFLICT DO NOTHING;

COMMIT;
