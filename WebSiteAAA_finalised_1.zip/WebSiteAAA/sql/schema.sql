





CREATE TABLE IF NOT EXISTS users (
    id              BIGSERIAL PRIMARY KEY,
    username        CITEXT UNIQUE NOT NULL,
    email           CITEXT UNIQUE,
    password_hash   TEXT NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    locked_until    TIMESTAMPTZ,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT username_len CHECK (char_length(username) BETWEEN 3 AND 64)
);

CREATE TABLE IF NOT EXISTS sessions (
    id          BIGSERIAL PRIMARY KEY,
    username    CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    token_hash  BYTEA NOT NULL UNIQUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at  TIMESTAMPTZ NOT NULL,
    revoked     BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_sessions_username ON sessions(username);

CREATE TABLE IF NOT EXISTS roles (
    id   BIGSERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS permissions (
    id   BIGSERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS user_roles (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id BIGINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id       BIGINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS audit_log (
    id          BIGSERIAL PRIMARY KEY,
    "timestamp" TIMESTAMPTZ NOT NULL DEFAULT now(),
    event_type  TEXT NOT NULL,
    action      TEXT NOT NULL,
    result      TEXT NOT NULL,
    username    TEXT,
    resource    TEXT,
    details     TEXT,
    prev_hash   BYTEA NOT NULL,
    entry_hash  BYTEA NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_username ON audit_log(username);









CREATE TABLE IF NOT EXISTS courses (
    id   BIGSERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS enrollments (
    id                BIGSERIAL PRIMARY KEY,
    student_username  CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    course_id         BIGINT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    status            TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Approved', 'Rejected')),
    decided_by        CITEXT,
    requested_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    decided_at        TIMESTAMPTZ
);

ALTER TABLE enrollments
    DROP CONSTRAINT IF EXISTS enrollments_student_username_course_id_key;
CREATE UNIQUE INDEX IF NOT EXISTS uq_enrollments_one_active_per_course
    ON enrollments(student_username, course_id)
    WHERE status <> 'Rejected';

CREATE INDEX IF NOT EXISTS idx_enrollments_student ON enrollments(student_username);
CREATE INDEX IF NOT EXISTS idx_enrollments_status ON enrollments(status);

CREATE TABLE IF NOT EXISTS course_resources (
    id          SERIAL PRIMARY KEY,
    course_id   BIGINT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    title       TEXT NOT NULL,
    category    TEXT NOT NULL CHECK (category IN ('Lesson', 'Lecture Note', 'Video', 'Tutorial')),
    url         TEXT NOT NULL,
    description TEXT NOT NULL,
    instructor  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_course_resources_course ON course_resources(course_id, id);

CREATE TABLE IF NOT EXISTS course_resource_seed_state (
    course_id BIGINT PRIMARY KEY REFERENCES courses(id) ON DELETE CASCADE,
    seeded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assignment_submissions (
    id                SERIAL PRIMARY KEY,
    course_id         BIGINT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    resource_id       INTEGER NOT NULL,
    task_name         TEXT NOT NULL,
    student_username  CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    file_name         TEXT NOT NULL,
    stored_name       TEXT NOT NULL,
    submitted_at      TIMESTAMP NOT NULL DEFAULT now(),
    score             INTEGER CHECK (score BETWEEN 0 AND 100),
    feedback          TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_assignment_submissions_student_course
    ON assignment_submissions(student_username, course_id, submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_assignment_submissions_course_submitted
    ON assignment_submissions(course_id, submitted_at DESC);

CREATE TABLE IF NOT EXISTS course_lesson_progress (
    student_username CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    course_id        BIGINT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    progress_key     TEXT NOT NULL,
    completed_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (student_username, course_id, progress_key)
);

CREATE TABLE IF NOT EXISTS course_exam_results (
    id               BIGSERIAL PRIMARY KEY,
    student_username CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    course_id        BIGINT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    score            INTEGER NOT NULL CHECK (score BETWEEN 0 AND 100),
    passed           BOOLEAN NOT NULL,
    taken_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_course_exam_results_student_course
    ON course_exam_results(student_username, course_id, taken_at DESC);

CREATE TABLE IF NOT EXISTS course_exam_attempts (
    student_username CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    course_id        BIGINT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    started_at       TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (student_username, course_id)
);







CREATE TABLE IF NOT EXISTS achievements (
    id                BIGSERIAL PRIMARY KEY,
    student_username  CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    course_id         BIGINT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    title             TEXT NOT NULL,
    details           TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_achievements_student ON achievements(student_username);

CREATE TABLE IF NOT EXISTS comments (
    id                BIGSERIAL PRIMARY KEY,
    student_username  CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    author_username   CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    text              TEXT NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_comments_student ON comments(student_username);

INSERT INTO roles (name) VALUES ('user'), ('admin'), ('tutor') ON CONFLICT DO NOTHING;

INSERT INTO permissions (name) VALUES
    ('profile.read'), ('profile.write'), ('users.read'), ('users.create'), ('users.delete'), ('audit.read'),
    ('achievements.read'), ('comments.write'), ('enrollment.approve'), ('roles.assign'),
    ('content.manage'), ('courses.manage'), ('results.read')
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p
WHERE r.name = 'user' AND p.name IN ('profile.read', 'profile.write')
ON CONFLICT DO NOTHING;




INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p
WHERE r.name = 'admin' AND p.name IN ('profile.read', 'profile.write', 'users.read', 'users.create', 'users.delete', 'audit.read', 'roles.assign', 'content.manage', 'courses.manage', 'results.read')
ON CONFLICT DO NOTHING;






INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p
WHERE r.name = 'tutor' AND p.name IN ('profile.read', 'profile.write', 'achievements.read', 'comments.write', 'enrollment.approve', 'results.read')
ON CONFLICT DO NOTHING;

INSERT INTO courses (name) VALUES ('Mathematics 101'), ('Intro to Programming'), ('Cryptography'), ('Database Management'), ('Machine Learning'), ('Deep Learning'), ('Natural Language Processing'), ('Reinforcement Learning'), ('Computer Vision'), ('System Hardware') ON CONFLICT DO NOTHING;
















ALTER TABLE courses ADD COLUMN IF NOT EXISTS slug         TEXT;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS description  TEXT NOT NULL DEFAULT '';
ALTER TABLE courses ADD COLUMN IF NOT EXISTS cover_url    TEXT;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS is_published BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS price_amount NUMERIC(10,2) NOT NULL DEFAULT 25;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS currency     CHAR(3) NOT NULL DEFAULT 'USD';
ALTER TABLE courses ALTER COLUMN price_amount SET DEFAULT 25;
ALTER TABLE courses ALTER COLUMN currency SET DEFAULT 'USD';
ALTER TABLE courses ADD COLUMN IF NOT EXISTS created_at   TIMESTAMPTZ NOT NULL DEFAULT now();
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'courses_price_nonneg') THEN
        ALTER TABLE courses ADD CONSTRAINT courses_price_nonneg CHECK (price_amount >= 0);
    END IF;
END $$;
CREATE UNIQUE INDEX IF NOT EXISTS uq_courses_slug ON courses(slug) WHERE slug IS NOT NULL;


CREATE TABLE IF NOT EXISTS course_tutors (
    course_id       BIGINT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    tutor_username  CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    assigned_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (course_id, tutor_username)
);

CREATE TABLE IF NOT EXISTS modules (
    id        BIGSERIAL PRIMARY KEY,
    course_id BIGINT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    title     TEXT NOT NULL CHECK (length(btrim(title)) > 0),
    position  INTEGER NOT NULL CHECK (position > 0),
    UNIQUE (course_id, position)
);

CREATE TABLE IF NOT EXISTS materials (
    id            BIGSERIAL PRIMARY KEY,
    module_id     BIGINT NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
    kind          TEXT NOT NULL CHECK (kind IN ('text', 'video', 'audio', 'image', 'link')),
    title         TEXT NOT NULL CHECK (length(btrim(title)) > 0),
    body          TEXT,
    resource_url  TEXT,
    position      INTEGER NOT NULL CHECK (position > 0),
    created_by    CITEXT REFERENCES users(username) ON DELETE SET NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (module_id, position),
    CHECK ((kind = 'text' AND nullif(btrim(body), '') IS NOT NULL)
        OR (kind <> 'text' AND nullif(btrim(resource_url), '') IS NOT NULL))
);
ALTER TABLE materials DROP CONSTRAINT IF EXISTS materials_kind_check;
ALTER TABLE materials DROP CONSTRAINT IF EXISTS materials_check;
ALTER TABLE materials DROP CONSTRAINT IF EXISTS materials_content_check;
ALTER TABLE materials ADD CONSTRAINT materials_kind_check
    CHECK (kind IN ('text', 'video', 'audio', 'image', 'link', 'pdf'));
ALTER TABLE materials ADD CONSTRAINT materials_content_check
    CHECK (nullif(btrim(body), '') IS NOT NULL OR nullif(btrim(resource_url), '') IS NOT NULL);

CREATE TABLE IF NOT EXISTS course_content_seed_state (
    course_id BIGINT PRIMARY KEY REFERENCES courses(id) ON DELETE CASCADE,
    seeded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS material_progress (
    student_username CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    material_id      BIGINT NOT NULL REFERENCES materials(id) ON DELETE CASCADE,
    completed_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (student_username, material_id)
);

CREATE TABLE IF NOT EXISTS quizzes (
    id            BIGSERIAL PRIMARY KEY,
    module_id     BIGINT NOT NULL UNIQUE REFERENCES modules(id) ON DELETE CASCADE,
    title         TEXT NOT NULL CHECK (length(btrim(title)) > 0),
    pass_score    NUMERIC(5,2) NOT NULL DEFAULT 70 CHECK (pass_score BETWEEN 0 AND 100),
    max_attempts  INTEGER NOT NULL DEFAULT 3 CHECK (max_attempts > 0),
    duration_minutes INTEGER NOT NULL DEFAULT 30 CHECK (duration_minutes BETWEEN 5 AND 240),
    created_by    CITEXT REFERENCES users(username) ON DELETE SET NULL
);
ALTER TABLE quizzes ADD COLUMN IF NOT EXISTS is_final_exam BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE quizzes ADD COLUMN IF NOT EXISTS duration_minutes INTEGER NOT NULL DEFAULT 30;

CREATE TABLE IF NOT EXISTS questions (
    id        BIGSERIAL PRIMARY KEY,
    quiz_id   BIGINT NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
    text      TEXT NOT NULL CHECK (length(btrim(text)) > 0),
    kind      TEXT NOT NULL CHECK (kind IN ('single', 'multiple', 'true_false')),
    position  INTEGER NOT NULL CHECK (position > 0),
    UNIQUE (quiz_id, position),
    UNIQUE (id, quiz_id)
);

CREATE TABLE IF NOT EXISTS answer_options (
    id          BIGSERIAL PRIMARY KEY,
    question_id BIGINT NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
    text        TEXT NOT NULL CHECK (length(btrim(text)) > 0),
    is_correct  BOOLEAN NOT NULL DEFAULT FALSE,
    position    INTEGER NOT NULL CHECK (position > 0),
    UNIQUE (question_id, position),
    UNIQUE (id, question_id)
);

CREATE TABLE IF NOT EXISTS quiz_attempts (
    id               BIGSERIAL PRIMARY KEY,
    quiz_id          BIGINT NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
    student_username CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    attempt_no       INTEGER NOT NULL CHECK (attempt_no > 0),
    score            NUMERIC(5,2) NOT NULL CHECK (score BETWEEN 0 AND 100),
    passed           BOOLEAN NOT NULL,
    submitted_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (quiz_id, student_username, attempt_no),
    UNIQUE (id, quiz_id)
);
CREATE INDEX IF NOT EXISTS idx_quiz_attempts_student ON quiz_attempts(student_username, submitted_at DESC);



CREATE TABLE IF NOT EXISTS attempt_answers (
    attempt_id  BIGINT NOT NULL,
    quiz_id     BIGINT NOT NULL,
    question_id BIGINT NOT NULL,
    option_id   BIGINT NOT NULL,
    PRIMARY KEY (attempt_id, question_id, option_id),
    FOREIGN KEY (attempt_id, quiz_id)     REFERENCES quiz_attempts(id, quiz_id)   ON DELETE CASCADE,
    FOREIGN KEY (question_id, quiz_id)    REFERENCES questions(id, quiz_id)       ON DELETE CASCADE,
    FOREIGN KEY (option_id, question_id)  REFERENCES answer_options(id, question_id) ON DELETE CASCADE
);





CREATE TABLE IF NOT EXISTS payments (
    id               BIGSERIAL PRIMARY KEY,
    student_username CITEXT NOT NULL REFERENCES users(username) ON DELETE RESTRICT,
    course_id        BIGINT NOT NULL REFERENCES courses(id) ON DELETE RESTRICT,
    amount           NUMERIC(10,2) NOT NULL CHECK (amount >= 0),
    currency         CHAR(3) NOT NULL DEFAULT 'USD',
    status           TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Paid', 'Failed', 'Refunded')),
    provider         TEXT,
    provider_ref     TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    paid_at          TIMESTAMPTZ,
    CHECK ((status IN ('Paid', 'Refunded')) = (paid_at IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS idx_payments_student ON payments(student_username);
CREATE INDEX IF NOT EXISTS idx_payments_course ON payments(course_id);


CREATE UNIQUE INDEX IF NOT EXISTS uq_payments_one_paid ON payments(student_username, course_id) WHERE status = 'Paid';

CREATE UNIQUE INDEX IF NOT EXISTS uq_payments_provider_ref ON payments(provider, provider_ref) WHERE provider_ref IS NOT NULL;


CREATE SEQUENCE IF NOT EXISTS certificate_no_seq;
CREATE TABLE IF NOT EXISTS certificates (
    id               BIGSERIAL PRIMARY KEY,
    certificate_no   TEXT NOT NULL UNIQUE DEFAULT ('CERT-' || lpad(nextval('certificate_no_seq')::text, 8, '0')),
    student_username CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    course_id        BIGINT NOT NULL REFERENCES courses(id) ON DELETE RESTRICT,
    issued_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (student_username, course_id)
);
ALTER TABLE certificates ADD COLUMN IF NOT EXISTS exam_score INTEGER;

CREATE TABLE IF NOT EXISTS course_feedback (
    id               BIGSERIAL PRIMARY KEY,
    student_username CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    course_id        BIGINT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    rating           INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comments         TEXT NOT NULL DEFAULT '',
    submitted_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (student_username, course_id)
);



DROP TRIGGER IF EXISTS quiz_attempts_require_access ON quiz_attempts;

WITH exam_courses AS (
    SELECT course_id FROM course_exam_results
    UNION
    SELECT course_id FROM certificates WHERE exam_score IS NOT NULL
)
INSERT INTO modules (course_id, title, position)
SELECT ec.course_id, 'Final exam', COALESCE(MAX(m.position), 0) + 1
FROM exam_courses ec
LEFT JOIN modules m ON m.course_id = ec.course_id
WHERE NOT EXISTS (
    SELECT 1
    FROM modules fm
    JOIN quizzes fq ON fq.module_id = fm.id
    WHERE fm.course_id = ec.course_id AND fq.is_final_exam
)
AND NOT EXISTS (
    SELECT 1
    FROM modules fm
    LEFT JOIN quizzes fq ON fq.module_id = fm.id
    WHERE fm.course_id = ec.course_id
      AND lower(fm.title) = 'final exam'
      AND fq.id IS NULL
)
GROUP BY ec.course_id;

WITH exam_courses AS (
    SELECT course_id FROM course_exam_results
    UNION
    SELECT course_id FROM certificates WHERE exam_score IS NOT NULL
)
INSERT INTO quizzes (module_id, title, is_final_exam)
SELECT m.id, 'Final exam', TRUE
FROM modules m
JOIN exam_courses ec ON ec.course_id = m.course_id
WHERE lower(m.title) = 'final exam'
  AND NOT EXISTS (
      SELECT 1
      FROM modules fm
      JOIN quizzes fq ON fq.module_id = fm.id
      WHERE fm.course_id = m.course_id AND fq.is_final_exam
  )
  AND m.id = (
      SELECT MIN(fm.id)
      FROM modules fm
      LEFT JOIN quizzes fq ON fq.module_id = fm.id
      WHERE fm.course_id = m.course_id
        AND lower(fm.title) = 'final exam'
        AND fq.id IS NULL
  )
  AND NOT EXISTS (SELECT 1 FROM quizzes q WHERE q.module_id = m.id)
ON CONFLICT (module_id) DO NOTHING;

UPDATE quizzes q
SET is_final_exam = TRUE
FROM modules m
WHERE m.id = q.module_id
  AND lower(m.title) = 'final exam'
  AND q.id = (
      SELECT fq.id
      FROM modules fm
      JOIN quizzes fq ON fq.module_id = fm.id
      WHERE fm.course_id = m.course_id AND lower(fm.title) = 'final exam'
      ORDER BY fq.is_final_exam DESC, fq.id
      LIMIT 1
  )
  AND (
      EXISTS (SELECT 1 FROM course_exam_results r WHERE r.course_id = m.course_id)
      OR EXISTS (SELECT 1 FROM certificates c WHERE c.course_id = m.course_id AND c.exam_score IS NOT NULL)
  );

WITH legacy_attempts AS (
    SELECT student_username, course_id, score, passed, taken_at AS attempt_at, id AS source_id
    FROM course_exam_results
    UNION ALL
    SELECT c.student_username, c.course_id, c.exam_score, TRUE, c.issued_at, c.id
    FROM certificates c
    WHERE c.exam_score IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM course_exam_results r
          WHERE r.student_username = c.student_username AND r.course_id = c.course_id
      )
),
ranked_attempts AS (
    SELECT q.id AS quiz_id, la.student_username,
           row_number() OVER (
               PARTITION BY m.course_id, la.student_username
               ORDER BY la.attempt_at, la.source_id
           )::INTEGER AS attempt_no,
           la.score, la.passed, la.attempt_at
    FROM legacy_attempts la
    JOIN modules m ON m.course_id = la.course_id
    JOIN quizzes q ON q.module_id = m.id AND q.is_final_exam
)
INSERT INTO quiz_attempts (quiz_id, student_username, attempt_no, score, passed, submitted_at)
SELECT quiz_id, student_username, attempt_no, score, passed, attempt_at
FROM ranked_attempts
ON CONFLICT (quiz_id, student_username, attempt_no) DO NOTHING;



CREATE OR REPLACE FUNCTION has_paid_access(p_username CITEXT, p_course BIGINT) RETURNS BOOLEAN AS $$
    SELECT COALESCE((SELECT price_amount = 0 FROM courses WHERE id = p_course), FALSE)
        OR EXISTS (SELECT 1 FROM payments
                   WHERE student_username = p_username AND course_id = p_course AND status = 'Paid');
$$ LANGUAGE sql STABLE;


CREATE OR REPLACE FUNCTION has_course_access(p_username CITEXT, p_course BIGINT) RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM enrollments
                   WHERE student_username = p_username AND course_id = p_course AND status = 'Approved')
       AND has_paid_access(p_username, p_course);
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION trg_require_course_access() RETURNS TRIGGER AS $$
DECLARE
    v_course BIGINT;
BEGIN
    IF TG_TABLE_NAME = 'quiz_attempts' THEN
        SELECT m.course_id INTO v_course FROM quizzes q JOIN modules m ON m.id = q.module_id WHERE q.id = NEW.quiz_id;
        IF NOT has_course_access(NEW.student_username, v_course) THEN
            RAISE EXCEPTION 'Course access denied: enrollment not approved or course not paid'
                USING ERRCODE = 'P0001';
        END IF;
    ELSIF TG_TABLE_NAME = 'material_progress' THEN
        SELECT m.course_id INTO v_course FROM materials t JOIN modules m ON m.id = t.module_id WHERE t.id = NEW.material_id;
        IF NOT has_course_access(NEW.student_username, v_course) THEN
            RAISE EXCEPTION 'Course access denied: enrollment not approved or course not paid'
                USING ERRCODE = 'P0001';
        END IF;
    END IF;
    RETURN NEW;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS quiz_attempts_require_access ON quiz_attempts;
CREATE TRIGGER quiz_attempts_require_access BEFORE INSERT ON quiz_attempts
    FOR EACH ROW EXECUTE FUNCTION trg_require_course_access();
DROP TRIGGER IF EXISTS material_progress_require_access ON material_progress;
CREATE TRIGGER material_progress_require_access BEFORE INSERT ON material_progress
    FOR EACH ROW EXECUTE FUNCTION trg_require_course_access();




CREATE OR REPLACE FUNCTION trg_certificate_eligibility() RETURNS TRIGGER AS $$
BEGIN
    IF NOT has_course_access(NEW.student_username, NEW.course_id) THEN
        RAISE EXCEPTION 'Certificate refused: enrollment not approved or course not paid'
            USING ERRCODE = 'P0001';
    END IF;
    RETURN NEW;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS certificates_eligibility ON certificates;
CREATE TRIGGER certificates_eligibility BEFORE INSERT ON certificates
    FOR EACH ROW EXECUTE FUNCTION trg_certificate_eligibility();

INSERT INTO permissions (name) VALUES ('payments.read'), ('payments.manage') ON CONFLICT DO NOTHING;
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p
WHERE r.name = 'admin' AND p.name IN ('payments.read', 'payments.manage')
ON CONFLICT DO NOTHING;

-- Latest practice-quiz score per student and course (kept in the database, survives restarts).
CREATE TABLE IF NOT EXISTS course_quiz_scores (
    student_username CITEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    course_id        BIGINT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    score            INTEGER NOT NULL CHECK (score BETWEEN 0 AND 100),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (student_username, course_id)
);
