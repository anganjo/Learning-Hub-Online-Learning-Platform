#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$project_dir"

read -r -p "PostgreSQL database [websiteaaa_import_test]: " database
database="${database:-websiteaaa_import_test}"
read -r -p "PostgreSQL username [postgres]: " username
username="${username:-postgres}"
read -r -s -p "PostgreSQL password (input hidden): " pg_password
printf '\n'

export ConnectionStrings__Postgres="Host=localhost;Port=5432;Database=${database};Username=${username};Password=${pg_password}"
unset pg_password

dotnet run --no-launch-profile -- "$@"
