using System.Security.Cryptography;
using System.Text;

namespace WebSiteAAA.Core;














public static class AuditChain
{
    public static readonly byte[] GenesisHash = new byte[32];

    public static byte[] ComputeEntryHash(
        byte[] prevHash, DateTimeOffset timestamp, string eventType, string action,
        string result, string? username, string? resource, string? details)
    {
        using var sha256 = SHA256.Create();
        using var stream = new MemoryStream();

        stream.Write(prevHash);
        WriteUtf8(stream, timestamp.ToString("O"));
        WriteUtf8(stream, eventType);
        WriteUtf8(stream, action);
        WriteUtf8(stream, result);
        WriteUtf8(stream, username ?? "");
        WriteUtf8(stream, resource ?? "");
        WriteUtf8(stream, details ?? "");

        stream.Position = 0;
        return sha256.ComputeHash(stream);
    }

    private static void WriteUtf8(Stream stream, string value)
    {
        var bytes = Encoding.UTF8.GetBytes(value);
        stream.Write(bytes);
    }

    
    
    
    
    
    private static readonly SemaphoreSlim ChainGate = new(1, 1);

    
    
    
    
    
    
    private static DateTimeOffset NowMicroseconds()
    {
        var now = DateTimeOffset.UtcNow;
        return new DateTimeOffset(now.Ticks - now.Ticks % 10, TimeSpan.Zero);
    }

    public static async Task RecordAsync(IAuditSink sink, AuditEvent evt)
    {
        await ChainGate.WaitAsync();
        try
        {
            var prevHash = await sink.GetLastHashAsync() ?? GenesisHash;
            var timestamp = NowMicroseconds();

            var entryHash = ComputeEntryHash(
                prevHash, timestamp, evt.EventType, evt.Action, evt.Result,
                evt.Username, evt.Resource, evt.Details);

            var record = new AuditRecord(
                Id: 0, timestamp, evt.EventType, evt.Action, evt.Result,
                evt.Username, evt.Resource, evt.Details, prevHash, entryHash);

            await sink.AppendAsync(record);
        }
        finally
        {
            ChainGate.Release();
        }
    }

    
    
    
    
    
    public static async Task<(bool Valid, long? BrokenAtId)> VerifyAsync(IAuditSink sink)
    {
        var records = await sink.GetAllOrderedAsync();
        var expectedPrev = GenesisHash;

        foreach (var record in records)
        {
            if (!record.PrevHash.AsSpan().SequenceEqual(expectedPrev))
                return (false, record.Id);

            var recomputed = ComputeEntryHash(
                expectedPrev, record.Timestamp, record.EventType, record.Action,
                record.Result, record.Username, record.Resource, record.Details);

            if (!recomputed.AsSpan().SequenceEqual(record.EntryHash))
                return (false, record.Id);

            expectedPrev = record.EntryHash;
        }

        return (true, null);
    }
}
