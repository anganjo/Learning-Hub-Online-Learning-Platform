using System.Collections.Concurrent;

namespace WebSiteAAA.Core;

public record CaptchaChallenge(string Id, string Question);








public class CaptchaService
{
    private readonly ConcurrentDictionary<string, (int Answer, DateTimeOffset Expires)> _challenges = new();
    private static readonly Random _random = new();
    private static readonly TimeSpan Ttl = TimeSpan.FromMinutes(5);

    public CaptchaChallenge Generate()
    {
        var a = _random.Next(1, 10);
        var b = _random.Next(1, 10);
        var id = Guid.NewGuid().ToString("N");

        _challenges[id] = (a + b, DateTimeOffset.UtcNow.Add(Ttl));

        return new CaptchaChallenge(id, $"What is {a} + {b}?");
    }

    
    public bool Validate(string? id, string? answer)
    {
        if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(answer))
            return false;

        if (!_challenges.TryRemove(id, out var entry))
            return false;

        if (DateTimeOffset.UtcNow > entry.Expires)
            return false;

        return int.TryParse(answer.Trim(), out var submitted) && submitted == entry.Answer;
    }
}
