using System.Collections.Concurrent;

namespace WebSiteAAA.Core;








public class RateLimiter
{
    private readonly int _windowSeconds;
    private readonly int _maxRequests;
    private readonly ConcurrentDictionary<string, Queue<DateTimeOffset>> _hits = new();
    private readonly object _lock = new();

    public RateLimiter(int windowSeconds = 60, int maxRequests = 30)
    {
        _windowSeconds = windowSeconds;
        _maxRequests = maxRequests;
    }

    public bool IsRateLimited(string clientIp)
    {
        var now = DateTimeOffset.UtcNow;

        lock (_lock)
        {
            var hits = _hits.GetOrAdd(clientIp, _ => new Queue<DateTimeOffset>());

            while (hits.Count > 0 && (now - hits.Peek()).TotalSeconds > _windowSeconds)
                hits.Dequeue();

            if (hits.Count >= _maxRequests)
                return true;

            hits.Enqueue(now);
            return false;
        }
    }
}
