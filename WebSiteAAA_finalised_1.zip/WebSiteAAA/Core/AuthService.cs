using System.Security.Cryptography;

namespace WebSiteAAA.Core;

public record AuthSettings(
    int MaxFailedAttempts = 5,
    int LockoutMinutes = 5,
    int SessionTtlMinutes = 30,
    int MinPasswordLength = 12
);

public class AuthError : Exception
{
    public AuthError(string message) : base(message) { }
}








public class AuthService
{
    private readonly IUserRepository _users;
    private readonly ISessionRepository _sessions;
    private readonly IRoleRepository _roles;
    private readonly IPasswordHasher _hasher;
    private readonly IAuditSink _audit;
    private readonly AuthSettings _settings;

    public AuthService(
        IUserRepository users, ISessionRepository sessions, IRoleRepository roles,
        IPasswordHasher hasher, IAuditSink audit, AuthSettings settings)
    {
        _users = users;
        _sessions = sessions;
        _roles = roles;
        _hasher = hasher;
        _audit = audit;
        _settings = settings;
    }

    private static byte[] HashToken(string token) =>
        SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(token));

    private async Task RegisterFailureAsync(string username, string resource, string details)
    {
        var user = await _users.GetAsync(username);

        if (user is null)
        {
            await AuditChain.RecordAsync(_audit, new AuditEvent(
                "AUTHENTICATION", "LOGIN", "FAILURE", username, resource, "Unknown user"));
            return;
        }

        var failedAttempts = await _users.RecordFailedAttemptAsync(username);

        if (failedAttempts >= _settings.MaxFailedAttempts)
        {
            var lockUntil = DateTimeOffset.UtcNow.AddMinutes(_settings.LockoutMinutes);
            await _users.LockAsync(username, lockUntil);
            await AuditChain.RecordAsync(_audit, new AuditEvent(
                "AUTHENTICATION", "ACCOUNT_LOCKED", "FAILURE", username, "account",
                "Account locked after maximum failed authentication attempts"));
        }

        await AuditChain.RecordAsync(_audit, new AuditEvent(
            "AUTHENTICATION", "LOGIN", "FAILURE", username, resource, details));
    }

    private async Task<string> IssueSessionAsync(string username)
    {
        var token = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
        var expiresAt = DateTimeOffset.UtcNow.AddMinutes(_settings.SessionTtlMinutes);

        await _sessions.CreateAsync(username, HashToken(token), expiresAt);

        await AuditChain.RecordAsync(_audit, new AuditEvent(
            "ACCOUNTING", "SESSION_CREATED", "SUCCESS", username, "sessions", "Session created via password"));

        return token;
    }

    public async Task<string> RegisterAsync(string username, string password, string? email)
    {
        if (string.IsNullOrWhiteSpace(username) || username.Length < 3)
            throw new AuthError("Invalid username");

        if (password.Length < _settings.MinPasswordLength)
            throw new AuthError($"Password must be at least {_settings.MinPasswordLength} characters");

        if (await _users.GetAsync(username) is not null)
            throw new AuthError("Username already exists");

        var passwordHash = _hasher.Hash(password);
        await _users.CreateAsync(username, passwordHash, email);
        await _roles.AssignRoleAsync(username, "user");

        await AuditChain.RecordAsync(_audit, new AuditEvent(
            "AUTHENTICATION", "REGISTER", "SUCCESS", username, "users", "User registered"));

        return username;
    }

    public async Task<string> LoginAsync(string username, string password)
    {
        var user = await _users.GetAsync(username);

        if (user is null || !user.IsActive)
        {
            await AuditChain.RecordAsync(_audit, new AuditEvent(
                "AUTHENTICATION", "LOGIN", "FAILURE", username, "auth/password", "Unknown or inactive user"));
            throw new AuthError("Authentication failed");
        }

        if (user.IsLocked(DateTimeOffset.UtcNow))
        {
            await AuditChain.RecordAsync(_audit, new AuditEvent(
                "AUTHENTICATION", "LOGIN", "FAILURE", username, "auth/password", "Account locked"));
            throw new AuthError("Account temporarily locked");
        }

        if (!_hasher.Verify(password, user.PasswordHash))
        {
            await RegisterFailureAsync(username, "auth/password", "Invalid password");
            throw new AuthError("Authentication failed");
        }

        await _users.ResetFailedAttemptsAsync(username);
        await AuditChain.RecordAsync(_audit, new AuditEvent(
            "AUTHENTICATION", "LOGIN", "SUCCESS", username, "auth/password", null));

        return await IssueSessionAsync(username);
    }

    public async Task<string?> ValidateSessionAsync(string token)
    {
        if (string.IsNullOrEmpty(token)) return null;

        var session = await _sessions.GetAsync(HashToken(token));

        if (session is null || session.Revoked) return null;
        if (DateTimeOffset.UtcNow >= session.ExpiresAt) return null;

        return session.Username;
    }

    public async Task<bool> LogoutAsync(string token)
    {
        if (string.IsNullOrEmpty(token)) return false;

        var tokenHash = HashToken(token);
        var session = await _sessions.GetAsync(tokenHash);

        if (session is null || session.Revoked) return false;

        var result = await _sessions.RevokeAsync(tokenHash);

        await AuditChain.RecordAsync(_audit, new AuditEvent(
            "ACCOUNTING", "LOGOUT", result ? "SUCCESS" : "FAILURE", session.Username, "logout", "Session revoked"));

        return result;
    }

    public async Task<int> LogoutAllAsync(string username)
    {
        var count = await _sessions.RevokeAllAsync(username);
        await AuditChain.RecordAsync(_audit, new AuditEvent(
            "ACCOUNTING", "LOGOUT_ALL", "SUCCESS", username, "sessions", $"{count} session(s) revoked"));
        return count;
    }

    public Task<List<string>> GetRolesAsync(string username) => _roles.GetRolesAsync(username);

    
    public async Task ChangePasswordAsync(string username, string currentPassword, string newPassword)
    {
        var user = await _users.GetAsync(username);
        if (user is null || !_hasher.Verify(currentPassword, user.PasswordHash))
        {
            await AuditChain.RecordAsync(_audit, new AuditEvent(
                "AUTHENTICATION", "PASSWORD_CHANGE", "FAILURE", username, "users", "Wrong current password"));
            throw new AuthError("Current password is incorrect");
        }

        if (newPassword.Length < _settings.MinPasswordLength)
            throw new AuthError($"Password must be at least {_settings.MinPasswordLength} characters");

        await _users.UpdatePasswordHashAsync(username, _hasher.Hash(newPassword));
        await AuditChain.RecordAsync(_audit, new AuditEvent(
            "AUTHENTICATION", "PASSWORD_CHANGE", "SUCCESS", username, "users", null));
    }
}
