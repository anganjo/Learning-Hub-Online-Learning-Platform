namespace WebSiteAAA.Core;









public class ContentAccess
{
    private readonly IEnrollmentRepository _enrollments;
    private readonly IRoleRepository _roles;
    private readonly IPaymentRepository _payments;

    public ContentAccess(IEnrollmentRepository enrollments, IRoleRepository roles, IPaymentRepository payments)
    {
        _enrollments = enrollments;
        _roles = roles;
        _payments = payments;
    }

    public async Task<bool> CanViewCourseAsync(string username, long courseId)
    {
        var roles = await _roles.GetRolesAsync(username);
        if (roles.Contains("admin") || roles.Contains("tutor")) return true;
        return await _enrollments.IsApprovedAsync(username, courseId)
            && await _payments.HasPaidAsync(username, courseId);
    }

    
    
    
    
    
    public async Task<bool> CanEarnCertificateAsync(string username, long courseId) =>
        await _enrollments.IsApprovedAsync(username, courseId)
        && await _payments.HasPaidAsync(username, courseId);
}
