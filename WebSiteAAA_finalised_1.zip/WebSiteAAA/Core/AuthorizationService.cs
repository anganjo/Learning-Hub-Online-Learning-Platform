namespace WebSiteAAA.Core;


public class AuthorizationService
{
    private readonly AuthService _auth;
    private readonly IRoleRepository _roles;
    private readonly IAuditSink _audit;

    public AuthorizationService(AuthService auth, IRoleRepository roles, IAuditSink audit)
    {
        _auth = auth;
        _roles = roles;
        _audit = audit;
    }

    public Task<string?> RequireAuthAsync(string token) => _auth.ValidateSessionAsync(token);

    public async Task<bool> RequirePermissionAsync(string token, string permission)
    {
        var username = await RequireAuthAsync(token);

        if (username is null)
        {
            await AuditChain.RecordAsync(_audit, new AuditEvent(
                "AUTHORIZATION", "ACCESS_CHECK", "DENIED", null, permission, "Authentication required"));
            return false;
        }

        var allowed = await _roles.UserHasPermissionAsync(username, permission);

        await AuditChain.RecordAsync(_audit, new AuditEvent(
            "AUTHORIZATION",
            allowed ? "ACCESS_GRANTED" : "ACCESS_DENIED",
            allowed ? "SUCCESS" : "FAILURE",
            username, permission,
            allowed ? "Permission granted" : "Permission denied"));

        return allowed;
    }
}
