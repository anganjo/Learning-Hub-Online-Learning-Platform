namespace WebSiteAAA.Core;









public interface IPasswordHasher
{
    string Hash(string password);
    bool Verify(string password, string hash);
}

public interface IUserRepository
{
    Task<long> CreateAsync(string username, string passwordHash, string? email);
    Task<UserRecord?> GetAsync(string username);
    Task<int> RecordFailedAttemptAsync(string username);
    Task ResetFailedAttemptsAsync(string username);
    Task LockAsync(string username, DateTimeOffset lockedUntil);
    Task<List<UserSummary>> GetAllAsync(int limit, int offset);
    Task<bool> DeleteAsync(string username);
    Task UpdateEmailAsync(string username, string? email);
    Task UpdatePasswordHashAsync(string username, string passwordHash);
}

public interface ISessionRepository
{
    Task CreateAsync(string username, byte[] tokenHash, DateTimeOffset expiresAt);
    Task<SessionRecord?> GetAsync(byte[] tokenHash);
    Task<bool> RevokeAsync(byte[] tokenHash);
    Task<int> RevokeAllAsync(string username);
}

public interface IRoleRepository
{
    Task AssignRoleAsync(string username, string role);

    
    Task<bool> RevokeRoleAsync(string username, string role);
    Task<List<string>> GetRolesAsync(string username);
    Task<bool> UserHasPermissionAsync(string username, string permission);

    
    
    
    
    
    
    
    Task<List<string>> GetAllRolesAsync();
}

public interface IAuditSink
{
    
    
    
    
    
    
    
    Task AppendAsync(AuditRecord record);
    Task<byte[]?> GetLastHashAsync();
    Task<List<AuditRecord>> GetAllOrderedAsync();
}









public interface ICourseRepository
{
    Task<long> CreateAsync(string name);
    Task<bool> UpdateAsync(long courseId, string name);
    Task<bool> DeleteAsync(long courseId);
    Task<List<CourseRecord>> GetAllAsync();
    Task<CourseRecord?> GetAsync(long courseId);
}

public interface IEnrollmentRepository
{
    
    Task<long> RequestAsync(string studentUsername, long courseId);

    
    Task<bool> DecideAsync(long enrollmentId, bool approve, string decidedBy);

    Task<List<EnrollmentRecord>> GetForStudentAsync(string studentUsername);
    Task<List<EnrollmentRecord>> GetForCoursesAsync(IReadOnlyCollection<long> courseIds);
    Task<List<EnrollmentRecord>> GetPendingAsync();

    
    
    
    
    
    
    
    Task<bool> IsApprovedAsync(string studentUsername, long courseId);
}

public interface IAchievementRepository
{
    Task<long> AddAsync(string studentUsername, long courseId, string title, string? details);
    Task<List<AchievementRecord>> GetForStudentAsync(string studentUsername);
}

public interface ICommentRepository
{
    Task<long> AddAsync(string studentUsername, string authorUsername, string text);
    Task<List<CommentRecord>> GetForStudentAsync(string studentUsername);
}

public interface ICertificateRepository
{
    Task<CertificateRecord> IssueAsync(string studentUsername, long courseId, int examScore);
    Task<List<CertificateRecord>> GetForStudentAsync(string studentUsername);
}

public interface ICourseFeedbackRepository
{
    Task<List<CourseFeedbackRecord>> GetForStudentAsync(string studentUsername);
    Task<bool> SubmitAsync(string studentUsername, long courseId, int rating, string comments);
}

public interface ILessonProgressRepository
{
    Task<HashSet<string>> GetCompletedKeysAsync(string studentUsername, long courseId);
    Task MarkCompleteAsync(string studentUsername, long courseId, string progressKey);
}

public interface IExamResultRepository
{
    Task RecordAsync(string studentUsername, long courseId, int score, bool passed);
    Task<ExamOutcome> GetOutcomeAsync(string studentUsername, long courseId);
    Task<List<ExamAttemptRecord>> GetLatestResultsAsync();
}

public interface IExamAttemptRepository
{
    Task<DateTimeOffset?> GetStartedAsync(string studentUsername, long courseId);
    Task StartAsync(string studentUsername, long courseId, int durationMinutes);
    Task EndAsync(string studentUsername, long courseId);
}







public interface IPaymentRepository
{
    Task<decimal> GetPriceAsync(long courseId);
    Task SetPriceAsync(long courseId, decimal amount, string currency = "USD");

    
    Task<long> CreateAsync(string studentUsername, long courseId);

    
    Task<bool> MarkPaidAsync(long paymentId, string provider, string providerRef);

    
    Task<bool> MarkFailedAsync(long paymentId);

    
    Task<bool> RefundAsync(long paymentId);

    
    Task<bool> HasPaidAsync(string studentUsername, long courseId);

    Task<List<PaymentRecord>> GetForStudentAsync(string studentUsername);
    Task<List<PaymentRecord>> GetAllAsync();
}
