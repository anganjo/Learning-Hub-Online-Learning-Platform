namespace WebSiteAAA.Core;

public record UserRecord(
    long Id,
    string Username,
    string? Email,
    string PasswordHash,
    DateTimeOffset CreatedAt,
    int FailedAttempts,
    DateTimeOffset? LockedUntil,
    bool IsActive
)
{
    public bool IsLocked(DateTimeOffset now) => LockedUntil is not null && now < LockedUntil;
}

public record SessionRecord(
    long Id,
    string Username,
    byte[] TokenHash,
    DateTimeOffset CreatedAt,
    DateTimeOffset ExpiresAt,
    bool Revoked
);

public record AuditEvent(
    string EventType,   
    string Action,
    string Result,      
    string? Username,
    string? Resource,
    string? Details
);

public record AuditRecord(
    long Id,
    DateTimeOffset Timestamp,
    string EventType,
    string Action,
    string Result,
    string? Username,
    string? Resource,
    string? Details,
    byte[] PrevHash,
    byte[] EntryHash
);

public record UserSummary(
    long Id, string Username, string? Email, DateTimeOffset CreatedAt,
    int FailedAttempts, DateTimeOffset? LockedUntil, bool IsActive
);









public record CourseRecord(long Id, string Name);

public enum EnrollmentStatus
{
    Pending,
    Approved,
    Rejected,
}

public record EnrollmentRecord(
    long Id,
    string StudentUsername,
    long CourseId,
    EnrollmentStatus Status,
    string? DecidedBy,
    DateTimeOffset RequestedAt,
    DateTimeOffset? DecidedAt
);

public record AchievementRecord(
    long Id,
    string StudentUsername,
    long CourseId,
    string Title,
    string? Details,
    DateTimeOffset CreatedAt
);

public record CommentRecord(
    long Id,
    string StudentUsername,
    string AuthorUsername,
    string Text,
    DateTimeOffset CreatedAt
);

public record CertificateRecord(
    long Id,
    string CertificateNumber,
    string StudentUsername,
    long CourseId,
    int? ExamScore,
    DateTimeOffset IssuedAt
);

public record CourseFeedbackRecord(
    long Id,
    string StudentUsername,
    long CourseId,
    int Rating,
    string Comments,
    DateTimeOffset SubmittedAt
);

public record ExamOutcome(int? BestScore, bool Passed);
public record ExamAttemptRecord(
    string StudentUsername,
    long CourseId,
    int AttemptNumber,
    int Score,
    bool Passed,
    DateTimeOffset SubmittedAt);

public enum PaymentStatus { Pending, Paid, Failed, Refunded }

public record PaymentRecord(
    long Id, string StudentUsername, long CourseId, decimal Amount, string Currency,
    PaymentStatus Status, string? Provider, string? ProviderRef,
    DateTimeOffset CreatedAt, DateTimeOffset? PaidAt);
